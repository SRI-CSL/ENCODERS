/*
 * CORE API
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE API definitions.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#include <signal.h>		/* signal() */
#include <inttypes.h>		/* uint8_t */
#include <sys/types.h>		/* sockaddr */
#include <sys/socket.h>		/* sockaddr */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* htonl() */

#include <coreapi/coreapi.h>

static char core_api_msg_names[CORE_API_MSG_MAX+1][5] = {
	"UNDF", "NODE", "LINK", "EXEC", "REG", "CONF", "FILE", "MAX"
};

int 
core_api_create_message(uint8_t *buf, uint8_t type, uint8_t flags, uint16_t length, uint8_t *data)
{
	struct core_api_msg *msg = (struct core_api_msg *)buf;
	if (!buf)
		return(-1);

	msg->type = type;
	msg->flags = flags;
	msg->length = htons(length);
	if (data) {
		memcpy(msg->value, data, length);
		return(sizeof(struct core_api_msg) + length);
	}
	
	return(sizeof(struct core_api_msg));
}

void
core_api_message_set_length(uint8_t *buf, uint16_t length)
{
	struct core_api_msg *msg = (struct core_api_msg *)buf;
	if (!buf) return;
	msg->length = htons(length);
}

uint8_t
core_api_message_get_flags(uint8_t *buf)
{
	struct core_api_msg *msg = (struct core_api_msg *)buf;
	if (!buf) return 0;
	return (msg->flags);
}

/* adds post padding to data if necessary */
int 
core_api_create_tlv(uint8_t *buf, uint8_t type, uint8_t length, uint8_t *data)
{
	struct core_api_tlv *tlv = (struct core_api_tlv *)buf;
	int pad;

	if (!buf)
		return(-1);
	tlv->type = type;
	tlv->length = length;
	if (data) {
		memcpy(tlv->value, data, length);
		pad = TLV_PAD(length);
		if (pad)
			bzero(&tlv->value[length], pad);
		return(sizeof(struct core_api_tlv) + length + pad);
	}
	return(sizeof(struct core_api_tlv));
}

int
core_api_create_tlv16(uint8_t *buf, uint8_t type, uint16_t data)
{
	uint16_t v = htons(data);
	return(core_api_create_tlv(buf, type, sizeof(uint16_t),	(uint8_t *)&v));
}

int
core_api_create_tlv32(uint8_t *buf, uint8_t type, uint32_t data)
{
	struct core_api_tlv *tlv = (struct core_api_tlv *)buf;
	uint32_t *val32;
	if (!buf)
		return(-1);
	tlv->type = type;
	tlv->length = sizeof(uint32_t); 	/* doesn't include padding */
	tlv->value[0] = tlv->value[1] = 0; /* prepend 32-bit val w/padding */
	val32 = (uint32_t *)&tlv->value[2];
	*val32 = htonl(data);
	return(sizeof(struct core_api_tlv) + 2 + sizeof(uint32_t));
}

int
core_api_create_tlv64(uint8_t *buf, uint8_t type, uint64_t data)
{
	struct core_api_tlv *tlv = (struct core_api_tlv *)buf;
	uint64_t *p64;
	if (!buf)
		return(-1);
	tlv->type = type;
	tlv->length = sizeof(uint64_t); 	/* doesn't include padding */
	tlv->value[0] = tlv->value[1] = 0; /* prepend 64-bit val w/padding */
	p64 = (uint64_t *)&tlv->value[2];
	*p64 = hton64(data);
	return(sizeof(struct core_api_tlv) + 2 + sizeof(uint64_t));
}


int
core_api_parse_message(uint8_t *buf, uint16_t *length)
{
	struct core_api_msg *msg = (struct core_api_msg *)buf;
#ifdef VERBOSE_DEBUG
	int err=0;
#endif
	if (!buf)
		return(-1);
	if (*length < sizeof(struct core_api_msg))
#ifdef VERBOSE_DEBUG
	{ printf("message too short (%d)\n", *length);
	  err = -3;
	  goto core_api_parse_message_hexdump; }
#else
		return(-3);
#endif
	if ((msg->type == 0) || (msg->type > CORE_API_MSG_MAX))
#ifdef VERBOSE_DEBUG
	{ printf("invalid message type (%d)\n", msg->type);
	  err = -2;
	  goto core_api_parse_message_hexdump; }
#else
		return(-2);
#endif
	if (*length < (sizeof(struct core_api_msg) + ntohs(msg->length)))
#ifdef VERBOSE_DEBUG
	{ printf("not enough message data (%d < %d)\n",
		 *length, sizeof(struct core_api_msg) + ntohs(msg->length));
	  err = -3;
	  goto core_api_parse_message_hexdump; }
#else
		return(-3);
#endif
	*length = ntohs(msg->length);
	return((int)msg->type);
#ifdef VERBOSE_DEBUG
core_api_parse_message_hexdump:
	printf("DEBUG msg(%d): type=%d flags=%d length=%d  \n", 
		*length, msg->type, msg->flags, ntohs(msg->length));
	{ int i; printf("DEBUG Message dump:");
	  for ( i = 0; i < *length; i++ ) { 
		printf("%c%.2x", (i%16) ? ' ': '\n' ,buf[i] & 0xFF); }
		printf("\n"); }
	return(err);
#endif
}

struct core_api_tlv *
core_api_get_tlv(uint8_t *buf, uint8_t type)
{
	struct core_api_msg *msg = (struct core_api_msg *)buf;
	struct core_api_tlv *tlv;
	int length, tlv_length;
	uint8_t *bufp;

	if (!buf)
		return(NULL);

	length = (int) ntohs(msg->length);
	bufp = msg->value;
	while (length > 0) {
		tlv = (struct core_api_tlv *)bufp;
		if (tlv->type == type)
			return(tlv); /* found */
		tlv_length = (int)core_api_get_tlv_length(tlv);
		tlv_length += sizeof(struct core_api_tlv) + TLV_PAD(tlv_length);
		bufp += tlv_length;
		length -= tlv_length;
		if (tlv_length <= 0) /* problem that would cause looping */
			break;
	}
	return(NULL);
}

/* buf is ptr to start of message buffer; prev (optional) ptr to previous TLV */
struct core_api_tlv *
core_api_get_next_tlv(uint8_t *buf, struct core_api_tlv *prev)
{
	struct core_api_msg *msg = (struct core_api_msg *)buf;
	int length, tlv_length;
	uint8_t *cp;

	if (!buf)
		return(NULL);

	length = (int) ntohs(msg->length);

	if (prev) {	/* ptr to the next TLV that follows prev */
		cp = (uint8_t *)prev;
		tlv_length = (int)core_api_get_tlv_length(prev);
		tlv_length += sizeof(struct core_api_tlv) + TLV_PAD(tlv_length);
		cp += tlv_length;
	} else {	/* ptr to the first TLV in the message */
		cp = msg->value;
	}

	if (cp >= (buf + length)) {
		return NULL;	/* end of message - no more TLVs */
	}

	/* cp will be advanced beyond buf/prev, safe to use in while loops */
	return ( (struct core_api_tlv *)cp );
}

int 
core_api_get_tlv_val16(struct core_api_tlv *tlv, uint16_t *value)
{
	uint16_t *val;
	*value = 0;
	if (!tlv)
		return(-1);
	if (tlv->length != sizeof(uint16_t)) {
		return(-1);
	}

	val = (uint16_t *)tlv->value;
	*value = ntohs(*val);
	return(0);
}

int
core_api_get_tlv_val32(struct core_api_tlv *tlv, uint32_t *value)
{
	uint32_t *val;
	*value = 0;
	if (!tlv)
		return(-1);
	if (tlv->length != sizeof(uint32_t)) {
		return(-1);
	}

	val = (uint32_t *)&tlv->value[2];
	*value = ntohl(*val);
	return(0);
}

int
core_api_get_tlv_val64(struct core_api_tlv *tlv, uint64_t *value)
{
	uint64_t *val;
	*value = 0;
	if (!tlv)
		return(-1);
	if (tlv->length != sizeof(uint64_t)) {
		return(-1);
	}

	val = (uint64_t *)&tlv->value[2];
	*value = ntoh64(*val);
	return(0);
}

int
core_api_get_tlv_string(struct core_api_tlv *tlv, uint8_t *value, int max)
{
	int len;
	uint8_t *str;

	if (!tlv || !value)
		return(-1);
	len = (int)core_api_get_tlv_length(tlv);
	str = &tlv->value[ (tlv->length==0) ? 2 : 0 ];
	if (len >= max)
		return(-1);

	/* NULL-terminate the result */
	memset(value, 0, max);
	/* string might not be NULL-terminated, so use TLV-specified length */
	strncpy((char*)value, (char*)str, len);
	return(0);
}

/* padding not included */
uint16_t
core_api_get_tlv_length(struct core_api_tlv *tlv)
{
	uint16_t r, *rp;
	if (!tlv)
		return(0);
	r = tlv->length; /* 8-bit value */
	if (r == 0) { /* special case for length > 255 */
		rp = (uint16_t*)tlv->value;
		r = ntohs(*rp);
	}
	return(r);
}

/* parse address from TLV to struct sockaddr, optionally store a mask in
 * the port field, return 1 if address was found, 0 otherwise
 */
int
core_api_get_tlv_address(uint8_t *buf, uint16_t tlvn, uint16_t tlvn_mask,
	int family, struct sockaddr *addr)
{
	struct core_api_tlv *tlv, *tlvm = NULL;
	struct sockaddr_in *inp;
	struct sockaddr_in6 *in6p;

	if (!addr) return(0);
	tlv = core_api_get_tlv(buf, tlvn);
	if (!tlv) return(0); /* TLV may not exist */

	if (tlvn_mask > 0) /* mask is optional, may not exist */
		tlvm = core_api_get_tlv(buf, tlvn_mask);

	memset(addr, 0, sizeof(struct sockaddr_storage));
	addr->sa_family = family;

	switch (family) {
	case AF_INET:
		inp = (struct sockaddr_in*)addr; 
		/* keep IPv4 address  in network byte order */
		core_api_get_tlv_val32(tlv, &inp->sin_addr.s_addr);
		inp->sin_addr.s_addr = htonl(inp->sin_addr.s_addr);
		inp->sin_port = 0;
		if (tlvm)
			core_api_get_tlv_val16(tlvm, &inp->sin_port);
		return 1;
	case AF_INET6:
		in6p = (struct sockaddr_in6*)addr;
		memcpy(&in6p->sin6_addr, tlv->value, sizeof(struct in6_addr));
		in6p->sin6_port = 0;
		if (tlvm)
			core_api_get_tlv_val16(tlvm, &in6p->sin6_port);
		return 1;	
	case AF_LOCAL: /* MAC address */
		core_api_get_tlv_val64(tlv, (uint64_t *)addr->sa_data );
		return 1;
	default:
		return 0;
	}
}


int
core_api_print_message(uint8_t *buf, uint16_t *length, FILE *stream)
{
	int type, err, len, tlv_len;
	struct core_api_msg *msg = (struct core_api_msg *)buf;
	struct core_api_tlv *tlv;
	uint8_t *bufp;
	uint16_t *p16;
	char tmp[255];
	
	err = core_api_parse_message(buf, length);
	if (err < 0) return err;

	type = err;
	len = *length;

	if (type > CORE_API_MSG_MAX)
		type = CORE_API_MSG_MAX;
	fprintf(stream, "%s(", core_api_msg_names[type]);

	bufp = msg->value;
	while (len > 0) {
		tlv = (struct core_api_tlv *)bufp;
		tlv_len = sizeof(struct core_api_tlv) + tlv->length;
		if (tlv->length == 0) {
			if (len <= tlv_len) /* don't read past the end */
				break;
			p16 = (uint16_t*)tlv->value;
			tlv_len += ntohs(*p16);		
			tlv_len += TLV_PAD(ntohs(*p16));
		} else {
			tlv_len += TLV_PAD(tlv->length);
		}
		bufp += tlv_len;
		len -= tlv_len;
		if (tlv_len <= 0) /* problem that would cause looping */
			break;
		if (tlv_len > sizeof(tmp)) { /* strings may be too large */
			fprintf(stream, "type=%d (len=%d),", 
				tlv->type, tlv_len);
			continue;
		}

		switch (type) {
		case CORE_API_NODE_MSG:
			core_api_node_tlv_to_str(tlv, tmp);
			fprintf(stream, "%s,", tmp);
			break;
		case CORE_API_LINK_MSG:
			core_api_link_tlv_to_str(tlv, tmp);
			fprintf(stream, "%s,", tmp);
			break;
		case CORE_API_EXEC_MSG:
			core_api_exec_tlv_to_str(tlv, tmp);
			fprintf(stream, "%s,", tmp);
			break;
		case CORE_API_REG_MSG:
			break;
		case CORE_API_CONF_MSG:
			break;
		case CORE_API_IFACE_MSG:
			core_api_iface_tlv_to_str(tlv, tmp);
			fprintf(stream, "%s,", tmp);
			break;
		default:
			fprintf(stream, "typ=%d,", tlv->type);
			break;
		}
	}

	fprintf(stream, ")\n");
	return(0);
}

void core_api_node_tlv_to_str(struct core_api_tlv *tlv, char *dst)
{
	int length = core_api_get_tlv_length(tlv);
	uint32_t *val32;

	if (length == 0)
		return;
	switch (tlv->type) {
	case CORE_TLV_NODE_NUMBER:
		val32 = (uint32_t *)tlv->value;
		sprintf(dst, "node=%u", ntohl(*val32));
		break;
	case CORE_TLV_NODE_TYPE:
		val32 = (uint32_t *)tlv->value;
		sprintf(dst, "ntype=%u", ntohl(*val32));
		break;
	case CORE_TLV_NODE_NAME:
		dst += sprintf(dst, "name=");
		strncpy(dst, (char *)tlv->value, length);
		dst[length] = '\0';
		break;
	default:
		sprintf(dst, "typ=%d", tlv->type);
		break;
	}
}

void core_api_link_tlv_to_str(struct core_api_tlv *tlv, char *dst)
{
	uint32_t *val32;

	switch (tlv->type) {
	case CORE_TLV_LINK_N1NUMBER:
		val32 = (uint32_t*)tlv->value;
		sprintf(dst, "node1=%u", ntohl(*val32));
		break;
	case CORE_TLV_LINK_N2NUMBER:
		val32 = (uint32_t*)tlv->value;
		sprintf(dst, "node2=%u", ntohl(*val32));
		break;
	default:
		sprintf(dst, "typ=%d", tlv->type);
		break;
	}
}

void core_api_exec_tlv_to_str(struct core_api_tlv *tlv, char *dst)
{
	int length = core_api_get_tlv_length(tlv);
	if (length == 0)
		return;

	switch (tlv->type) {
	case CORE_TLV_EXEC_NODE:
		sprintf(dst, "node=%u", ntohl(*((uint32_t *)&tlv->value[2])));
		break;
	case CORE_TLV_EXEC_NUM:
		sprintf(dst, "num=%u", ntohl(*((uint32_t *)&tlv->value[2])));
		break;
	case CORE_TLV_EXEC_TIME:
		sprintf(dst, "time=0x%x", ntohl(*((uint32_t *)&tlv->value[2])));
		break;
	case CORE_TLV_EXEC_CMD:
		dst += sprintf(dst, "cmd='");
		strncpy(dst, (char *)tlv->value, length);
		dst[length] = '\'';
		dst[++length] = '\0';
		break;
	case CORE_TLV_EXEC_RESULT:
		/* results can be large - avoid exceeding dst buffer length */
		sprintf(dst, "result=(%d bytes)", length);
		break;
	case CORE_TLV_EXEC_STATUS:
		sprintf(dst, "status=%u", ntohl(*((uint32_t *)&tlv->value[2])));
		break;
	default:
		sprintf(dst, "typ=%d", tlv->type);
		break;
	}
}

void core_api_iface_tlv_to_str(struct core_api_tlv *tlv, char *dst)
{
	int length = core_api_get_tlv_length(tlv);
	uint32_t *val32;
	uint16_t *val16;

	if (length == 0)
		return;
	switch (tlv->type) {
	case CORE_TLV_IFACE_NODE:
		val32 = (uint32_t *)tlv->value;
		sprintf(dst, "node=%u", ntohl(*val32));
		break;
	case CORE_TLV_IFACE_NUMBER:
		val16 = (uint16_t *)tlv->value;
		sprintf(dst, "ifnum=%u", ntohs(*val16));
		break;
	case CORE_TLV_IFACE_NAME:
		dst += sprintf(dst, "name=");
		strncpy(dst, (char *)tlv->value, length);
		dst[length] = '\0';
		break;
	case CORE_TLV_IFACE_TYPE:
		val16 = (uint16_t *)tlv->value;
		sprintf(dst, "itype=%u", ntohs(*val16));
		break;
	case CORE_TLV_IFACE_STATE:
		val16 = (uint16_t *)tlv->value;
		sprintf(dst, "istate=%u", ntohs(*val16));
		break;
	default:
		sprintf(dst, "typ=%d", tlv->type);
		break;
	}
}
