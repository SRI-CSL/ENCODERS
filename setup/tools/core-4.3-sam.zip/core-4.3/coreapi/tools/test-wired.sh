#!/bin/sh
coreapisend=../coreapisend

#
# stop the sample network
#
if [ a$1 = astop ]; then
  $coreapisend link flags=del num=0 num2=1
  $coreapisend node flags=del num=1
  $coreapisend node flags=del num=0
  exit 0
fi

#
# start a sample network of two wired nodes linked together
#
$coreapisend node flags=add num=0 x=150 y=150 model=1
$coreapisend node flags=add num=1 x=450 y=300 model=1
$coreapisend link flags=add num=0 num2=1 delay=75000 bw=512000 type=1 mac=000a01 mac2=000a02 if1num=0 if2num=0 ip=192.168.9.1 ip2=192.168.9.2
