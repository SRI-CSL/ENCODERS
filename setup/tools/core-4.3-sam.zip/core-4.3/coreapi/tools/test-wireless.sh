#!/bin/sh
coreapisend=../coreapisend
num_nodes=6

#
# stop the sample network
#
if [ a$1 = astop ]; then
  # remove nodes
  n=0
  while [ $n -lt $num_nodes ]; do
    $coreapisend node flags=del num=$n
    n=`expr $n + 1`
  done
  # remove WLAN node
  $coreapisend node flags=del num=$num_nodes
  exit 0
fi

# wireless router nodes
$coreapisend flags=add num=0 x=380 y=150
$coreapisend flags=add num=1 x=230 y=350
$coreapisend flags=add num=2 x=350 y=550
$coreapisend flags=add num=3 x=500 y=350
$coreapisend flags=add num=4 x=760 y=300
$coreapisend flags=add num=5 x=178 y=510

# WLAN node
$coreapisend flags=add num=6 type=6 x=850 y=75 name=wlan6 
# join nodes to WLAN
n=0
while [ $n -lt $num_nodes ]; do
  n1=`expr $n + 1`
  $coreapisend link flags=add num=6 num2=$n ip2=10.0.0.$n1 mac2=000a0$n if2num=0
  n=$n1
done

echo waiting...
sleep 4
$coreapisend link flags=add num=0 num2=1 delay=75000 bw=100000 dup=0 per=0
$coreapisend link flags=add num=1 num2=5 delay=27000 bw=100000 dup=0 per=0
$coreapisend link flags=add num=1 num2=2 delay=19300 bw=100000 dup=0 per=0
$coreapisend link flags=add num=2 num2=5 delay=25000 bw=100000 dup=0 per=0
$coreapisend link flags=add num=3 num2=4 delay=15000 bw=100000 dup=0 per=0
