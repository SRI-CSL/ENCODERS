/*
 * CORE API
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE API tester.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#include <inttypes.h>

#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select() */
#include <time.h>		/* ctime() */

#include <coreapi/coreapi.h>

/* forward declarations */
void receive_exec_response(int core_sock);
void hex_dump(uint8_t *buf, int len);

void print_usage()
{
	printf("usage: coreapisend [server=<ip>] [node|link|exec] [flags] "
		"[parameters]\n");
	printf("\tserver=<ip[:port]> of CORE daemon, default localhost:%d\n",
		CORE_API_PORT);
	printf("\tflags=<add|del>\n");
	printf("\trepeat=<n>  (repeat the message n times)\n");

	printf("\tnode parameters:\n");
	printf("\t\tnum=<node number>\n");
	printf("\t\ttype=<node type>\n");
	printf("\t\tname=<node name>\n");
	printf("\t\tip=<ipv4 address string>\n");
	printf("\t\tmac=<hex MAC address>\n");
	printf("\t\tip6=<ipv6 address string>\n");
	printf("\t\tmodel=<model type>\n");
	printf("\t\tx=<x pos>\n");
	printf("\t\ty=<y pos>\n");
	printf("\t\tcanv=<canvas>\n");
	printf("\t\temuid=<emulation ID>\n");
	printf("\t\tnetid=<network ID>\n");
	printf("\t\ticon=<icon path>\n");

	printf("\tlink parameters:\n");
	printf("\t\tnum=<node1 number>\n");
	printf("\t\tnum2=<node2 number>\n");
	printf("\t\tdelay=<millisecond delay>\n");
	printf("\t\tbw=<bits/sec bandwidth>\n");
	printf("\t\tper=<percent packet error rate>\n");
	printf("\t\tdup=<percent duplicates>\n");
	printf("\t\tjitter=<millisecond jitter>\n");
	printf("\t\tmer=<percent multicast error rate>\n");
	printf("\t\tburst=<percent burst errors>\n");
	printf("\t\tmburst=<percent multicast burst errors>\n");
	printf("\t\ttype=<link type>\n");
	printf("\t\tif[1|2]num=<interface 1 or 2 number>\n");
	printf("\t\tip[2]=<interface 1 or 2 address string>\n");
	printf("\t\tipmask[2]=<interface 1 or 2 network mask bits>\n");
	printf("\t\tmac[2]=<interface 1 or 2 hex MAC address>\n");
	printf("\t\tip6[2]=<interface 1 or 2 ipv6 address string>\n");
	printf("\t\tip6mask[2]=<interface 1 or 2 ipv6 network mask bits>\n");

	printf("\texec parameters:\n");
	printf("\t\tnum=<node number>\n");
	printf("\t\texecnum=<execution number>\n");
	printf("\t\texeccmd=\"execution command\"\n");
	printf("\t\n");

}

int main(int argc, char **argv)
{
	uint32_t node_num=0, node2_num=0, node_type=router_quagga, ip=0, srv=0;
	uint32_t emuid=0, netid=0, execn=0, repeat=1, ip2=0;
	uint16_t type = CORE_API_NODE_MSG, flags=0, len16, srvport=0;
	uint16_t model_type=wireless, x=0, y=0, per=0, dup=0, canv=0;
	uint16_t mer=0, burst=0, mburst=0;
	uint16_t ipmask=0, ipmask2=0, ip6mask=0, ip6mask2=0;
	uint16_t if1num=0, if2num=0;
	uint64_t delay=0, bw=0, jitter=0, mac=0, mac2=0;
	int have_type=0, have_per=0, have_mer=0, have_if1num=0, have_if2num=0;
	struct sockaddr_in addr;
	struct in6_addr ip6, ip62;
	int core_sock, hdr_len, len, err; /*, start;*/
	uint8_t buf[1024];
	char name[255], execcmd[255], icon[255], ipstr[INET6_ADDRSTRLEN], *cp;

	memset(buf, 0, sizeof(buf));
	memset(name, 0, sizeof(name));
	memset(execcmd, 0, sizeof(execcmd));
	memset(icon, 0, sizeof(icon));
	memset(&ip6, 0, sizeof(ip6));
	memset(&ip62, 0, sizeof(ip62));

	/* XXX is there a way to cleanup this parsing using some
 	 *     string library or methods? 
         */
	argv++, argc--;
	while (argc > 0) {
		if (strcmp(*argv, "node") == 0) {
			type = CORE_API_NODE_MSG;
		} else if (strcmp(*argv, "link") == 0) {
			type = CORE_API_LINK_MSG;
		} else if (strcmp(*argv, "exec") == 0) {
			type = CORE_API_EXEC_MSG;
		} else if (strncmp(*argv, "server=", 7) == 0) {
			if ((cp = strchr(&(*argv)[7], ':'))) {
				*cp='\0';
				cp++;
				if (sscanf(cp, "%hu", &srvport) != 1) {
					printf("invalid server port!\n");
					return(-1);
				}
			}
			if (inet_pton(AF_INET, &(*argv)[7], &srv) <= 0) {
				printf("invalid server IP address!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "flags=", 6) == 0) {
			if (strncmp( &(*argv)[6], "add", 3)==0) {
				flags |= CORE_API_ADD_FLAG;
			} else if (strncmp( &(*argv)[6], "del", 3)==0) {
				flags |= CORE_API_DEL_FLAG;
			} else {
				printf("invalid flags!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "repeat=", 7) == 0) {
			if (sscanf( &(*argv)[7], "%u", &repeat) != 1) {
				printf("invalid repeat count!\n");
				return(-1);
			}
		/* node TLVs */
		} else if (strncmp(*argv, "num=", 4) == 0) {
			if (sscanf( &(*argv)[4], "%u", &node_num) != 1) {
				printf("invalid node number!\n");
				return(-1);
			}
			snprintf(name, sizeof(name),  "n%u", node_num);
		} else if (strncmp(*argv, "num2=", 5) == 0) {
			if (sscanf( &(*argv)[5], "%u", &node2_num) != 1) {
				printf("invalid node2 number!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "type=", 5) == 0) {
			if (sscanf( &(*argv)[5], "%u", &node_type) != 1) {
				printf("invalid node type!\n");
				return(-1);
			}
			have_type = 1;
		} else if (strncmp(*argv, "name=", 5) == 0) { 
			/* XXX name < 255 ! */
			if (sscanf( &(*argv)[5], "%s ", name) != 1) {
				printf("invalid node name!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "ip=", 3) == 0) {
			if (inet_pton(AF_INET, &(*argv)[3], &ip) <= 0) {
				printf("invalid IP address!\n");
				return(-1);
			}
			ip = ntohl(ip);
		} else if (strncmp(*argv, "ip6=", 4) == 0) {
			if (inet_pton(AF_INET6, &(*argv)[4], &ip6) <= 0) {
				printf("invalid IPv6 address!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "mac=", 4) == 0) {
			if (sscanf( &(*argv)[4], "%" PRIx64, &mac) != 1) {
				printf("invalid MAC address!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "mac2=", 5) == 0) {
			if (sscanf( &(*argv)[5], "%" PRIx64, &mac2) != 1) {
				printf("invalid MAC address!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "model=", 6) == 0) {
			if (sscanf( &(*argv)[6], "%hu", &model_type) != 1) {
				printf("invalid model type!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "x=", 2) == 0) {
			if (sscanf( &(*argv)[2], "%hu", &x) != 1) {
				printf("invalid x value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "y=", 2) == 0) {
			if (sscanf( &(*argv)[2], "%hu", &y) != 1) {
				printf("invalid y value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "canv=", 5) == 0) {
			if (sscanf( &(*argv)[5], "%hu", &canv) != 1) {
				printf("invalid canvas value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "emuid=", 6) == 0) {
			if (sscanf( &(*argv)[6], "%u", &emuid) != 1) {
				printf("invalid emulation ID!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "netid=", 6) == 0) {
			if (sscanf( &(*argv)[6], "%u", &netid) != 1) {
				printf("invalid network ID!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "icon=", 5) == 0) {
			strncpy(icon, &(*argv)[5], 255);
		/* link TLVs */
		} else if (strncmp(*argv, "delay=", 6) == 0) {
			if (sscanf( &(*argv)[6], "%" PRIu64, &delay) != 1) {
				printf("invalid delay value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "bw=", 3) == 0) {
			if (sscanf( &(*argv)[3], "%" PRIu64, &bw) != 1) {
				printf("invalid bw value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "per=", 4) == 0) {
			if (sscanf( &(*argv)[4], "%hu", &per) != 1) {
				printf("invalid PER value!\n");
				return(-1);
			}
			have_per = 1;
		} else if (strncmp(*argv, "dup=", 4) == 0) {
			if (sscanf( &(*argv)[4], "%hu", &dup) != 1) {
				printf("invalid duplicates value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "jitter=", 7) == 0) {
			if (sscanf( &(*argv)[7], "%" PRIu64, &jitter) != 1) {
				printf("invalid jitter value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "mer=", 4) == 0) {
			if (sscanf( &(*argv)[4], "%hu", &mer) != 1) {
				printf("invalid MER value!\n");
				return(-1);
			}
			have_mer = 1;
		} else if (strncmp(*argv, "burst=", 6) == 0) {
			if (sscanf( &(*argv)[6], "%hu", &burst) != 1) {
				printf("invalid burst value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "mburst=", 7) == 0) {
			if (sscanf( &(*argv)[7], "%hu", &mburst) != 1) {
				printf("invalid multicast burst value!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "if1num=", 7) == 0) {
			if (sscanf( &(*argv)[7], "%hu", &if1num) != 1) {
				printf("invalid interface 1 number!\n");
				return(-1);
			}
			have_if1num = 1;
		} else if (strncmp(*argv, "if2num=", 7) == 0) {
			if (sscanf( &(*argv)[7], "%hu", &if2num) != 1) {
				printf("invalid interface 2 number!\n");
				return(-1);
			}
			have_if2num = 1;
		} else if (strncmp(*argv, "ipmask=", 7) == 0) {
			if (sscanf( &(*argv)[7], "%hu", &ipmask) != 1) {
				printf("invalid IPv4 mask bits!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "ipmask2=", 8) == 0) {
			if (sscanf( &(*argv)[8], "%hu", &ipmask2) != 1) {
				printf("invalid IPv4 2 mask bits!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "ip6mask=", 8) == 0) {
			if (sscanf( &(*argv)[8], "%hu", &ip6mask) != 1) {
				printf("invalid IPv6 mask bits!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "ip6mask2=", 9) == 0) {
			if (sscanf( &(*argv)[9], "%hu", &ip6mask2) != 1) {
				printf("invalid IPv6 2 mask bits!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "ip2=", 4) == 0) {
			if (inet_pton(AF_INET, &(*argv)[4], &ip2) <= 0) {
				printf("invalid IP 2 address!\n");
				return(-1);
			}
			ip2 = ntohl(ip2);
		} else if (strncmp(*argv, "ip62=", 5) == 0) {
			if (inet_pton(AF_INET6, &(*argv)[5], &ip62) <= 0) {
				printf("invalid IPv6 2 address!\n");
				return(-1);
			}
		/* exec TLVs */
		} else if (strncmp(*argv, "execnum=", 8) == 0) {
			if (sscanf( &(*argv)[8], "%u", &execn) != 1) {
				printf("invalid execution number!\n");
				return(-1);
			}
		} else if (strncmp(*argv, "execcmd=", 8) == 0) {
			strncpy(execcmd, &(*argv)[8], 255);
		} else {
			printf("unknown option: %s\n", *argv);
			print_usage();
			return(-1);
		}

		argv++, argc--;
	}


/* Message building */
	hdr_len = len = core_api_create_message(buf, type, flags, 0, NULL);

	switch (type) { 
	case CORE_API_NODE_MSG:
/*	printf("NODE(type=%d, flags=0x%x node_num=%d node_type=%d ",
		type, flags, node_num, node_type);
	printf(" model=%d ip=%x x=%d y=%d)\n", model_type, ip, x, y);*/
	len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_NUMBER,
			node_num);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_TYPE,
			node_type);
	if (strlen(name) > 0)
		len += core_api_create_tlv(&buf[len], CORE_TLV_NODE_NAME, 
					   strlen(name), (uint8_t*)name);
	if (ip > 0)
		len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_IPADDR,
					     ip);
	if (mac > 0) {
		len += core_api_create_tlv64(&buf[len], CORE_TLV_NODE_MACADDR,
						mac);
	}
	if (!IN6_ARE_ADDR_EQUAL(&ip6, &in6addr_any)) {
		len += core_api_create_tlv(&buf[len], CORE_TLV_NODE_IP6ADDR,
				sizeof(struct in6_addr), (uint8_t*)&ip6);
	}
	len += core_api_create_tlv16(&buf[len], CORE_TLV_NODE_MODEL,
			model_type);
	len += core_api_create_tlv16(&buf[len], CORE_TLV_NODE_XPOS, x);
	len += core_api_create_tlv16(&buf[len], CORE_TLV_NODE_YPOS, y);
	if (emuid > 0) {
		len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_EMUID,
					     emuid);
	}
	if (netid > 0) {
		len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_NETID,
					     netid);
	}
	if (strlen(icon) > 0) {
		len += core_api_create_tlv(&buf[len], CORE_TLV_NODE_ICON,
					   strlen(icon), (uint8_t*)icon);
	}
	break;

	case CORE_API_LINK_MSG:
/*	printf("LINK(type=%d, flags=0x%x, node1=%d, node2=%d, delay=%" PRIu64,
		type, flags, node_num, node2_num, delay);
	printf("bw=%" PRIu64 ", per=%u, dup=%u)\n", bw, per, dup);*/
	len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_N1NUMBER,
			node_num);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_N2NUMBER,
			node2_num);
	if (delay > 0)
	    len += core_api_create_tlv64(&buf[len], CORE_TLV_LINK_DELAY, delay);
	if (bw > 0)
	    len += core_api_create_tlv64(&buf[len], CORE_TLV_LINK_BW, bw);
	if (have_per)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_PER, per);
	if (dup > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_DUP, dup);
	if (jitter > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_JITTER,
					 jitter);
	if (have_mer)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_MER, mer);
	if (burst > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_BURST, burst);
	if (mburst > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_MBURST,
					 mburst);
	if (have_type)
	    len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_TYPE,
					 node_type);
	if (have_if1num)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_IF1NUM,
					 if1num);
	if (ip > 0)
	    len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_IF1IP4, ip);
	if (ipmask > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_IF1IP4MASK,
					 ipmask);
	if (mac > 0)
	     len += core_api_create_tlv64(&buf[len], CORE_TLV_LINK_IF1MAC, mac);
	if (!IN6_IS_ADDR_UNSPECIFIED(&ip6))
	    len += core_api_create_tlv(&buf[len], CORE_TLV_LINK_IF1IP6,
				       sizeof(struct in6_addr), (uint8_t*)&ip6);
	if (ip6mask > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_IF1IP6MASK,
					 ip6mask);
	if (have_if2num)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_IF2NUM,
					 if2num);
	if (ip2 > 0)
	    len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_IF2IP4, ip2);
	if (ipmask2 > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_IF2IP4MASK,
					 ipmask2);
	if (mac2 > 0)
	    len += core_api_create_tlv64(&buf[len], CORE_TLV_LINK_IF2MAC, mac2);
	if (!IN6_IS_ADDR_UNSPECIFIED(&ip62))	
	    len += core_api_create_tlv(&buf[len], CORE_TLV_LINK_IF2IP6,
				       sizeof(struct in6_addr),
				       (uint8_t*)&ip62);
	if (ip6mask2 > 0)
	    len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_IF2IP6MASK,
					 ip6mask2);
	break;

	case CORE_API_EXEC_MSG:
/*	printf("EXEC(type=%d, flags=0x%x, node=%d, execnum=%d, execcmd=\"%s\"",
		type, flags, node_num, execn, execcmd);*/
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NODE, node_num);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NUM, execn);
	len += core_api_create_tlv(&buf[len], CORE_TLV_EXEC_CMD, 
		strlen(execcmd), (uint8_t*)execcmd);
/*	printf(")\n");*/

	default:
	break;
	}
	
	core_api_message_set_length(buf, len - hdr_len);

	len16 = len;
	core_api_print_message(buf, &len16, stdout);
/* end message building */
#if 0
/* begin hack for multiple messages */
	start = len;

	node_num++;
	
	hdr_len = core_api_create_message(&buf[start], type, flags, 0, 0);
	len += hdr_len;
	
	printf("EXEC(type=%d, flags=0x%x, node=%d, execnum=%d, execcmd=\"%s\"",
		type, flags, node_num, execn, execcmd);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NODE, node_num);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NUM, execn);
	len += core_api_create_tlv(&buf[len], CORE_TLV_EXEC_CMD, 
		strlen(execcmd), (uint8_t*)execcmd);
	printf(")\n");

	core_api_message_set_length(&buf[start], len - (start + hdr_len));

/* end hack for multiple messages */
#endif	

	core_sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = (srv > 0) ? srv : htonl(INADDR_LOOPBACK);
	addr.sin_port = (srvport > 0) ? htons(srvport) : htons(CORE_API_PORT);
	inet_ntop(AF_INET, &addr.sin_addr, ipstr, sizeof(ipstr));
	printf("connecting to %s:%d...\n", ipstr, ntohs(addr.sin_port));
	err = connect(core_sock, (struct sockaddr *)&addr, 
			sizeof(struct sockaddr_in));
	printf("connect returned %d\n", err);

	while(repeat > 0) {
		/* hex_dump(buf, len); */
		err = send(core_sock, buf, len, 0);
		/* buf[11]++; */ /* hack to increment node number */
		printf("send returned %d\n", err);
		if (type == CORE_API_EXEC_MSG) {
			receive_exec_response(core_sock);
		}
		repeat--;
	}


	close(core_sock);
	return 0;
}

void receive_exec_response(int core_sock)
{
	int err, len, flags, result_len;
	fd_set read_fdset;
	struct timeval to;
	uint8_t buf[2048];
	uint16_t length;
	char *result;
	struct core_api_tlv *tlv;

	printf("waiting for exec response...");
	FD_ZERO(&read_fdset);
	FD_SET((unsigned int)core_sock, &read_fdset);
	to.tv_sec = 10;
	to.tv_usec = 0;
	err = select(core_sock+1, &read_fdset, NULL, NULL, &to);
	printf("select returned %d\n", err);
	if (err == 0) {
		printf("Timeout waiting for response.\n");
		return;
	}

	len = sizeof(buf);
	flags = 0;
	len = recv(core_sock, (char *)buf, len, flags);
	length = (uint16_t)len;
/*	printf("received %d bytes:\n", len);
	hex_dump(buf, length); */
	err = core_api_parse_message(buf, &length);
	if (err < 0) {
		printf("Error parsing response message.\n");
		return;
	} else if (err != CORE_API_EXEC_MSG) {
		printf("Looking for Execute response, received type=%d.\n", 
			err);
		return;
	}
	core_api_print_message(buf, &length, stdout);
	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_RESULT);
	printf("result:\n");
	result_len = core_api_get_tlv_length(tlv);
	if (!tlv || result_len == 0) {
		printf("<no result>\n");
		return;
	}
	result = (char *)malloc(result_len + 1);
	if (!result)
		return;
	memset(result, 0, result_len + 1);
	if (result_len < 255)
		memcpy(result, tlv->value, result_len);
	else
		memcpy(result, &tlv->value[2], result_len);
	printf("%s\n", result);
	free(result);
}

void hex_dump(uint8_t *buf, int len)
{
	int i;
	for (i=0;i<len;i++) {
		printf("%.2x ", buf[i]&0xFF);
		if (i && i%16==0) printf("\n");
	}
	printf("\n");
}
