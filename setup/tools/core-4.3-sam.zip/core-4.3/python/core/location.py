#
# CORE
# Copyright (c)2010-2012 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
location.py: definition of CoreLocation class that is part of the
session object. Depends on the LatLongUTMconversion contributed module, from
http://pygps.org/ (version 1.2).
'''

from core.api import coreapi
from core.misc import LatLongUTMconversion

# This is the UTM zone we are using when performing conversions.
WGS84 = 23

class CoreLocation():
    ''' Member of session class for handling global location data. This keeps
        track of a latitude/longitude/altitude reference point and scale in
        order to convert between X,Y and geo coordinates.
    '''
    def __init__(self, session):
        self.session = session
        # (x, y, z) coordinates of the point given by self.refgeo
        self.refxyz = (0.0, 0.0, 0.0)
        # decimal latitude, longitude, and altitude at the point (x, y, z)
        self.refgeo = (0.0, 0.0, 0.0)
        self.refutm = ("", 0.0, 0.0, 0.0)
        # 100 pixels equals this many meters
        self.refscale = 1.0
        self.register()

    def reset(self):
        ''' Reset to initial state.
        '''
        self.refxyz = (0.0, 0.0, 0.0)
        self.setrefgeo(0.0, 0.0, 0.0)
        self.refscale = 1.0

    def register(self):
        ''' Register as a configurable object with the Session object.
        '''
        self.session.addconfobj("location", coreapi.CORE_TLV_REG_UTILITY,
                                self.configure)

    def configure(self, session, msg):
        ''' Receive configuration message for setting the reference point
            and scale.
        '''
        objname = msg.gettlv(coreapi.CORE_TLV_CONF_OBJ)
        conftype = msg.gettlv(coreapi.CORE_TLV_CONF_TYPE)
        if conftype == coreapi.CONF_TYPE_FLAGS_REQUEST:
            # ignore configuration requests?
            pass
        elif conftype == coreapi.CONF_TYPE_FLAGS_RESET:
            if objname == "all":
                self.reset()
        else:
            values_str = msg.gettlv(coreapi.CORE_TLV_CONF_VALUES)
            if values_str is None:
                self.session.info("location data missing")
                return None
            values = values_str.split('|')
            # Cartesian coordinate reference point
            refx = float(values[0])
            refy = float(values[1])
            refz = 0.0
            self.refxyz = (refx, refy, refz)
            # Geographic reference point
            lat = float(values[2])
            long = float(values[3])
            alt = float(values[4])
            self.setrefgeo(lat, long, alt)

            self.refscale = float(values[5])
            self.session.info("location configured: (%.2f,%.2f,%.2f) = "
                "(%.5f,%.5f,%.5f) scale=%.2f" %
                (self.refxyz[0], self.refxyz[1], self.refxyz[2], self.refgeo[0],
                 self.refgeo[1], self.refgeo[2], self.refscale))
            self.session.info("location configured: UTM(%.5f,%.5f,%.5f)" %
                              (self.refutm[1], self.refutm[2], self.refutm[3]))

    def px2m(self, val):
        ''' Convert the specified value in pixels to meters using the
            configured scale. The scale is given as s, where
            100 pixels = s meters.
        '''
        return (val / 100.0) * self.refscale

    def m2px(self, val):
        ''' Convert the specified value in meters to pixels using the
            configured scale. The scale is given as s, where
            100 pixels = s meters.
        '''
        if self.refscale == 0.0:
            return 0.0
        return 100.0 * (val / self.refscale)

    def setrefgeo(self, lat, long, alt):
        ''' Record the geographical reference point decimal (lat, long, alt)
            and convert and store its UTM equivalent for later use.
        '''
        self.refgeo = (lat, long, alt)
        # zone, easting, northing
        (z, e, n) = LatLongUTMconversion.LLtoUTM(WGS84, lat, long)
        self.refutm = (z, e, n, alt)

    def getgeo(self, x, y, z):
        ''' Given (x, y, z) Cartesian coordinates, convert them to latitude,
            longitude, and altitude based on the configured reference point
            and scale.
        '''
        # shift (x,y,z) over to reference point (x,y,z)
        x = x - self.refxyz[0]
        y = -(y - self.refxyz[1])
        if z is None:
            z = self.refxyz[2]
        else:
            z = z - self.refxyz[2]
        # use UTM coordinates since unit is meters
        zone = self.refutm[0]
        if zone == "":
            raise ValueError, "reference point not configured"
        e = self.refutm[1] + self.px2m(x)
        n = self.refutm[2] + self.px2m(y)
        alt = self.refutm[3] + self.px2m(z)
        (lat, long) = LatLongUTMconversion.UTMtoLL(WGS84, n, e, zone)
        return (lat, long, alt)

    def getxyz(self, lat, long, alt):
        ''' Given latitude, longitude, and altitude location data, convert them
            to (x, y, z) Cartesian coordinates based on the configured
            reference point and scale.
        '''
        # convert lat/long to UTM coordinates
        (zone, e, n) = LatLongUTMconversion.LLtoUTM(WGS84, lat, long)
        # calculate the distance in meters from reference point origin
        xm = e - self.refutm[1]
        ym = n - self.refutm[2]
        zm = alt - self.refutm[3]
        # shift (x,y,z) over to reference point (x,y,z)
        x = self.m2px(xm) + self.refxyz[0]
        y = self.m2px(ym) + self.refxyz[1]
        z = self.m2px(zm) + self.refxyz[2]
        return (x, y, z)

