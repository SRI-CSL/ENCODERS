#
# CORE
# Copyright (c)2010-2012 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
service.py: definition of CoreService class that is subclassed to define
startup services and routing for nodes. A service is typically a daemon
program launched when a node starts that provides some sort of
service.
'''

import sys, os, shlex

from itertools import repeat
from core.api import coreapi
from core.misc.utils import maketuplefromstr

servicelist = []

def addservice(service):
    global servicelist
    servicelist.append(service)

class CoreServices(object):
    ''' Class for interacting with a list of available startup services for
        nodes. Mostly used to convert a CoreService into a Config API
        message. This class lives in the Session object and remembers
        the default services configured for each node type, and any
        custom service configuration.
    '''
    _objname = "services"
    
    def __init__(self, session):
        self.session = session
        # dict of default services tuples, key is node type
        self.defaultservices = {}
        # dict of tuple of service objects, key is node number
        self.customservices = {}
        self.register()
        importcmd = "from core.services import *"
        exec(importcmd)
        custom = self.session.getcfgitem('custom_services_dir')
        if custom and len(custom) > 0:
            if not os.path.isdir(custom):
                self.session.warn("invalid custom service directory specified" \
                                  ": %s" % custom)
                return
            try:
                parentdir, childdir = os.path.split(custom)
                sys.path.append(parentdir)
                exec("from %s import *" % childdir)
            except Exception, e:
                self.session.warn("error importing custom services from " \
                    "%s:\n%s" % (custom, e))

    def register(self):
        ''' Register as a configurable object with the Session object.
        '''
        self.session.addconfobj(self._objname, coreapi.CORE_TLV_REG_UTILITY,
                                            self.configure)

    def reset(self):
        ''' Called when config message with reset flag is received
        '''
        self.defaultservices.clear()
        self.customservices.clear()
        
    def get(self):
        ''' Get the list of available services.
        '''
        global servicelist
        return servicelist
    
    def getservicebyname(self, name):
        ''' Get a service class from the global servicelist given its name.
            Returns None when the name is not found.
        '''
        global servicelist
        for s in servicelist:
            if s._name == name:
                return s
        return None
        
    def getdefaultservices(self, type):
        ''' Get the list of default services that should be enabled for a
            node for the given node type.
        '''
        r = []
        if type in self.defaultservices:
            defaults = self.defaultservices[type]
            for name in defaults:
                s = self.getservicebyname(name)
                if s is None:
                    self.session.warn("default service %s is unknown" % name)
                else:
                    r.append(s)
        return r
    
    def getcustomservice(self, objid, service):
        ''' Get any custom service configured for the given node that
            matches the specified service name. If no custom service
            is found, return the specified service.
        '''
        if objid in self.customservices:
            for s in self.customservices[objid]:
                if s._name == service._name:
                    return s
        return service

    def setcustomservice(self, objid, service, values):
        ''' Store service customizations in an instantiated service object
            using a list of values that came from a config message.
        '''
        if service._custom:
            s = service
        else:
            # instantiate the class, for storing config customization
            s = service()
        
        if values[0] != '':
            s._dirs = maketuplefromstr(values[0], str)
        if values[1] != '':
            s._configs = maketuplefromstr(values[1], str)
        if values[2] != '':
            s._startindex = int(values[2])
        if values[3] != '':
            s._startup = maketuplefromstr(values[3], str)
        if values[4] != '':
            s._shutdown = maketuplefromstr(values[4], str)
        if values[5] != '':
            s._validate = maketuplefromstr(values[5], str)
        if values[6] != '':
            s._meta = values[6]
        # assume custom service already in dict
        if service._custom:
            return
        # add the custom service to dict
        if objid in self.customservices:
            self.customservices[objid] += (s, )
        else:
            self.customservices[objid] = (s, )

    def addservicestonode(self, node, nodetype, services_str, verbose):
        ''' Populate the node.serivcelist using (1) the list of services 
            requested from the services TLV, (2) using any custom service
            configuration, or (3) using the default services for this node type.
        '''
        if services_str is not None:
            services = services_str.split('|')
            for name in services:
                s = self.session.services.getservicebyname(name)
                if s is None:
                    self.session.warn("configured service %s for node %s is " \
                                                "unknown" % (name,  node.name))
                    continue
                if verbose:
                    self.session.info("adding configured service %s to " \
                                            "node %s" % (s._name,  node.name))
                s = self.getcustomservice(node.objid, s)
                node.addservice(s)
        else:
            services = self.getdefaultservices(nodetype)
            for s in services:
                if verbose:
                    self.session.info("adding default service %s to node %s" % \
                                        (s._name,  node.name))
                s = self.getcustomservice(node.objid, s)
                node.addservice(s)
                
    def bootnodeservices(self, node):
        ''' Start all services on a node.
        '''
        services = sorted(node.services,
                                    key=lambda service: service._startindex)
        for s in services:
            self.bootnodeservice(node, s, services)
    
    def bootnodeservice(self, node, s, services):
        ''' Start a service on a node. Create private dirs, generate config
            files, and execute startup commands.
        '''
        if s._custom:
            self.bootnodecustomservice(node, s, services)
            return
        if node.verbose:
            node.info("starting service %s (%s)" % (s._name, s._startindex))
        for d in s._dirs:
            try:
                node.privatedir(d)
            except Exception,  e:
                node.warn("Error making node %s dir %s: %s" % \
                          (node.name,  d,  e))
        for filename in s.getconfigfilenames(node.objid, services): 
            cfg = s.generateconfig(node,  filename, services)
            node.nodefile(filename,  cfg)
        for cmd in s.getstartup(node, services):
            try:
                # NOTE: this wait=False can be problematic!
                node.cmd(shlex.split(cmd),  wait = False)
            except:
                node.warn("error starting command %s" % cmd)

    def bootnodecustomservice(self, node, s, services):
        ''' Start a custom service on a node. Create private dirs, use supplied
            config files, and execute  supplied startup commands.
        '''
        if node.verbose:
            node.info("starting service %s (%s)(custom)" % (s._name, s._startindex))
        for d in s._dirs:
            try:
                node.privatedir(d)
            except Exception,  e:
                node.warn("Error making node %s dir %s: %s" % \
                          (node.name,  d,  e))
        for filename in s._configs: 
            if len(filename) == 0:
                continue
            cfg = ""
            if len(s._configtxt) > 0:
                i = s._configs.index(filename)
                if i <= len(s._configtxt) - 1:
                    cfg = s._configtxt[i]
                else:
                    cfg = s.generateconfig(node,  filename, services)
            node.nodefile(filename,  cfg)
            
        for cmd in s._startup:
            try:
                # NOTE: this wait=False can be problematic!
                node.cmd(shlex.split(cmd),  wait = False)
            except:
                node.warn("error starting command %s" % cmd)

    def validatenodeservices(self, node):
        ''' Run validation commands for all services on a node.
        '''
        services = sorted(node.services,
                                    key=lambda service: service._startindex)
        for s in services:
            self.validatenodeservice(node, s, services)

    def validatenodeservice(self, node, s, services):
        ''' Run the validation command(s) for a service.
        '''
        if node.verbose:
            node.info("validating service %s (%s)" % (s._name, s._startindex))
        if s._custom:
            validate_cmds = s._validate
        else:
            validate_cmds = s.getvalidate(node, services)
        for cmd in validate_cmds:
            if node.verbose:
                node.info("validating service %s using: %s" % (s._name, cmd))
            try:
                (status, result) = node.cmdresult(shlex.split(cmd))
                if status != 0:
                    raise ValueError, "non-zero exit status"
            except:
                node.warn("validation command '%s' failed" % cmd)
                node.exception(coreapi.CORE_EXCP_LEVEL_ERROR,
                    "service:%s" % s._name, 
                    "validate command failed: %s" % cmd)
        
    def stopnodeservices(self, node):
        ''' Stop all services on a node.
        '''
        services = sorted(node.services,
                                    key=lambda service: service._startindex)
        for s in services:
            self.stopnodeservice(node, s)
    
    def stopnodeservice(self, node, s):
        ''' Stop a service on a node.
        '''
        for cmd in s._shutdown:
            try:
                # NOTE: this wait=False can be problematic!
                node.cmd(shlex.split(cmd),  wait = False)
            except:
                node.warn("error starting command %s" % cmd)


    def configure(self, session, msg):
        ''' Receive configuration message for configuring services.
            With a request flag set, a list of services has been requested.
            When the opaque field is present, a specific service is being
            configured or requested.
        '''
        reply = None
        flags = 0
        objname = msg.gettlv(coreapi.CORE_TLV_CONF_OBJ)
        conftype = msg.gettlv(coreapi.CORE_TLV_CONF_TYPE)
        nodenum = msg.gettlv(coreapi.CORE_TLV_CONF_NODE)
        sessionnum = msg.gettlv(coreapi.CORE_TLV_CONF_SESSION)
        opaque = msg.gettlv(coreapi.CORE_TLV_CONF_OPAQUE)
        tlvdata = ""
        
        if conftype == coreapi.CONF_TYPE_FLAGS_RESET:
            self.reset()
            return reply
        if objname == "all":
            return reply

        
        # send back the properties for this service
        if conftype == coreapi.CONF_TYPE_FLAGS_REQUEST and \
            opaque is not None:
            if nodenum is None:
                return None
            n = self.session.obj(nodenum)
            if n is None:
                self.session.warn("Request to configure service %s for " \
                    "unknown node %s" % (svc._name,  nodenum))
                return None
            servicesstring = opaque.split(':')
            services = self.servicesfromopaque(opaque, n.objid)
            if len(services) < 1:
                return None
            if len(servicesstring) == 3:
                # a file request: e.g. "service:zebra:quagga.conf"
                return self.getservicefile(services, n, servicesstring[2])
            
            # the first service in the list is the one being configured
            svc = services[0]
            # send back:
            # dirs, configs, startindex, startup, shutdown, metadata, config
            tf = coreapi.CONF_TYPE_FLAGS_UPDATE
            datatypes = tuple(repeat(coreapi.CONF_DATA_TYPE_STRING,  6))
            vals = "%s|" % str(svc._dirs)
            if svc._custom:
                cfgfiles = svc._configs
            else:
                cfgfiles = svc.getconfigfilenames(nodenum,  services)
            vals += "%s|" % str(cfgfiles)
            vals += "%s|" % (svc._startindex)
            if svc._custom:
                vals += "%s|" % str(svc._startup)
            else:
                vals += "%s|" % str(svc.getstartup(n,  services))
            vals += "%s|" % str(svc._shutdown)
            vals += "%s|" % str(svc._validate)
            vals += "%s" % str(svc._meta)
            
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_NODE,
                                                nodenum)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_OBJ,
                                                self._objname)            
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_TYPE, tf)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_DATA_TYPES,
                                                datatypes)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_VALUES,
                                                vals)
            if sessionnum is not None:
                tlvdata += coreapi.CoreConfTlv.pack(
                                coreapi.CORE_TLV_CONF_SESSION, sessionnum)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_OPAQUE,
                                                opaque)
            reply = coreapi.CoreConfMessage.pack(flags, tlvdata)
        elif conftype == coreapi.CONF_TYPE_FLAGS_REQUEST:
            # send back a list of available services
            global servicelist
            tf = coreapi.CONF_TYPE_FLAGS_NONE
            datatypes = tuple(repeat(coreapi.CONF_DATA_TYPE_BOOL,
                                            len(servicelist)))
            vals = "|".join(repeat('0', len(servicelist)))
            names = map(lambda x: x._name,  servicelist)
            captions = "|".join(names)
            possiblevals = ""
            for s in servicelist:
                if s._custom_needed:
                    possiblevals += '1'
                possiblevals += '|'
            groups = self.buildgroups(servicelist)

            if nodenum is not None:
                tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_NODE,
                                                    nodenum)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_OBJ,
                                                self._objname)            
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_TYPE, tf)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_DATA_TYPES,
                                                datatypes)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_VALUES,
                                                vals)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_CAPTIONS,
                                                captions)
            tlvdata += coreapi.CoreConfTlv.pack(
                coreapi.CORE_TLV_CONF_POSSIBLE_VALUES, possiblevals)
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_GROUPS,
                                                groups)
            if sessionnum is not None:
                tlvdata += coreapi.CoreConfTlv.pack(
                                coreapi.CORE_TLV_CONF_SESSION, sessionnum)
            reply = coreapi.CoreConfMessage.pack(flags, tlvdata)
        elif opaque is not None:
            # store service customized config in self.customservices[]
            if nodenum is None:
                return None
            services = self.servicesfromopaque(opaque, nodenum)
            if len(services) < 1:
                return None
            svc = services[0]
            values_str = msg.gettlv(coreapi.CORE_TLV_CONF_VALUES)
            if values_str is None:
                self.session.info("services config message that I don't know how to handle")
                return None
            values = values_str.split('|')
            self.setcustomservice(nodenum, svc, values)
        else:
            # store default services for a node type in self.defaultservices[]
            values_str = msg.gettlv(coreapi.CORE_TLV_CONF_VALUES)
            if values_str is None:
                self.session.info("services config message that I don't know how to handle")
                return reply
            values = values_str.split('|')
            data_types = msg.gettlv(coreapi.CORE_TLV_CONF_DATA_TYPES)
            if data_types[0] != coreapi.CONF_DATA_TYPE_STRING:
                self.session.info("services config message that I don't know how to handle")
                return reply
            key = values.pop(0)
            self.defaultservices[key] = values
            self.session.info("default services for type %s set to %s" % (key, values))
        return reply
    
    def servicesfromopaque(self,  opaque, objid):
        ''' Build a list of services from an opaque data string.
        '''
        services = []
        servicesstring = opaque.split(':')
        if servicesstring[0] != "service":
            return []
        servicenames = servicesstring[1].split(',')
        for name in servicenames:
            s = self.getservicebyname(name)
            s = self.getcustomservice(objid, s)
            if s is None:
                self.session.warn("Request for unknown service '%s'" % name)
                return []
            services.append(s)
        return services

        
    def buildgroups(self,  servicelist):
        ''' Build a string of groups for use in a configuration message given
            a list of services. The group list string has the format 
            "title1:1-5|title2:6-9|10-12", where title is an optional group title
            and i-j is a numeric range of value indices; groups are
            separated by commas.
        '''
        i = 0
        r = ""
        lastgroup = "<undefined>"
        for service in servicelist:
            i += 1
            group = service._group
            if group != lastgroup:
                lastgroup = group
                # finish previous group
                if i > 1:
                    r += "-%d|" % (i -1)                
                # optionally include group title
                if group == "":
                    r += "%d" % i
                else:
                    r += "%s:%d" % (group,  i)
        # finish the last group list
        if i > 0:
            r += "-%d" % i
        return r
        
    def getservicefile(self, services, node, filename):
        ''' Send a File Message when the GUI has requested a service file.
        The file data is either auto-generated or comes from an existing config.
        '''
        svc = services[0]
        # get the filename and determine the config file index
        if svc._custom:
            cfgfiles = svc._configs
        else:
            cfgfiles = svc.getconfigfilenames(node.objid,  services)
        if filename not in cfgfiles:
            self.session.warn("Request for unknown file '%s' for service '%s'" \
                             % (filename, services[0]))
            return None
            
        # get the file data
        if svc._custom:
            i = cfgfiles.index(filename)
            if len(svc._configtxt) > 0:
                data = "%s" % svc._configtxt[i]
        else:
            data = "%s" % (svc.generateconfig(node, filename, services))
            
        # send a file message
        flags = coreapi.CORE_API_ADD_FLAG
        tlvdata = coreapi.CoreFileTlv.pack(coreapi.CORE_TLV_FILE_NODE, node.objid)
        tlvdata += coreapi.CoreFileTlv.pack(coreapi.CORE_TLV_FILE_NAME, filename)
        tlvdata += coreapi.CoreFileTlv.pack(coreapi.CORE_TLV_FILE_DATA, data)
        reply = coreapi.CoreFileMessage.pack(flags, tlvdata)
        return reply
    
    def setservicefile(self, nodenum, type, filename, srcname, data):
        ''' Receive a File Message from the GUI and store the customized file
        in the service config. The filename must match one from the list of
        config files in the service.
        '''
        if len(type.split(':')) < 2:
            self.session.warn("Received file type did not contain service info.")
            return
        if srcname is not None:
            raise NotImplementedError
        (svcid, svcname) = type.split(':')[:2]
        svc = self.getservicebyname(svcname)
        svc = self.getcustomservice(nodenum, svc)
        if svc is None:
            self.session.warn("Received filename for unknown service '%s'" % \
                              svcname)
            return
        cfgfiles = svc._configs
        if filename not in cfgfiles:
            self.session.warn("Received unknown file '%s' for service '%s'" \
                             % (filename, svcname))
            return
        i = cfgfiles.index(filename)
        configtxtlist = list(svc._configtxt)
        numitems = len(configtxtlist)
        if numitems < i+1:
            # add empty elements to list to support index assignment
            for j in range(1, (i + 2) - numitems):
                configtxtlist += '',
        configtxtlist[i] = data
        svc._configtxt = configtxtlist
        

class CoreService(object):
    ''' Parent class used for defining services.
    '''
    # service name should not include spaces
    _name = ""
    # group string allows grouping services together
    _group = ""
    # list name(s) of services that this service depends upon
    _depends = ()
    # private, per-node directories required by this service
    _dirs = ()
    # config files written by this service
    _configs = ()
    # index used to determine start order with other services
    _startindex = 0
    # list of startup commands
    _startup = ()
    # list of shutdown commands
    _shutdown = ()
    # list of validate commands
    _validate = ()
    # metadata associated with this service
    _meta = ""
    # custom configuration text
    _configtxt = ()
    _custom = False
    _custom_needed = False

    def __init__(self):
        ''' Services are not necessarily instantiated. Classmethods may be used
            against their config. Services are instantiated when a custom
            configuration is used to override their default parameters.
        '''
        self._custom = True
    
    @classmethod
    def getconfigfilenames(cls,  nodenum,  services):
        ''' Return the tuple of configuration file filenames. This default method
            returns the cls._configs tuple, but this method may be overriden to
            provide node-specific filenames that may be based on other services.
        '''
        return cls._configs
        
    @classmethod
    def generateconfig(cls, node,  filename,  services):
        ''' Generate configuration file given a node object. The filename is
            provided to allow for multiple config files. The other services are
            provided to allow interdependencies (e.g. zebra and OSPF).
            Return the configuration string to be written to a file or sent 
            to the GUI for customization.
        '''
        raise NotImplementedError
        
    @classmethod
    def getstartup(cls,  node,  services):
        ''' Return the tuple of startup commands. This default method
            returns the cls._startup tuple, but this method may be
            overriden to provide node-specific commands that may be
            based on other services.
        '''
        return cls._startup

    @classmethod
    def getvalidate(cls,  node,  services):
        ''' Return the tuple of validate commands. This default method
            returns the cls._validate tuple, but this method may be
            overriden to provide node-specific commands that may be
            based on other services.
        '''
        return cls._validate

