/*
 * CORE
 * Copyright (c)2012 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * version.h
 *
 */
#ifndef _VERSION_H_
#define _VERSION_H_

#define CORE_VERSION "4.3"

#endif /* _VERSION_H_ */
