/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * coreconn.c
 *
 * Functions for managing Span connections.
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#ifdef WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select() */
#endif

#include "cored.h"
#include "coreconn.h"

/*
 * Add a new connection to the global linked list.
 */
struct core_conn*
add_core_conn(sock, type)
int sock;
int type;
{
	struct core_conn *conn;

	if (conns==NULL) {
		conns = conn = malloc(sizeof(struct core_conn));
	} else {
		for (conn = conns; conn->next; conn = conn->next) { }
		conn->next = malloc(sizeof(struct core_conn));
		conn = conn->next;
	}
	if (!conn) {
/*		wl_log("add_core_conn: malloc() error\n");  */
		return NULL;
	}

	bzero(conn, sizeof(struct core_conn));
	conn->sock = sock;
	conn->type = type;
	conn->recv_buff = NULL;
	conn->recv_buff_len = 0;
	conn->recv_len = 0;
	bzero(conn->subscriptions, sizeof(conn->subscriptions));
	conn->next = NULL;
	return(conn);
}

/*
 * Returns a pointer to the current index in the receive buffer. Allocates a
 * new recieve buffer if none exists. Returns NULL upon malloc error.
 */
uint8_t *
get_core_conn_recv_buff(conn, size)
struct core_conn *conn;
int size;
{
	/* receive buffer already allocated, some bytes already received */
	if ((conn->recv_buff_len > 0) && (conn->recv_len > 0))
		return(&conn->recv_buff[conn->recv_len]);

	/* allocate a new receive buffer */
	conn->recv_len = 0;
	conn->recv_buff_len = size;
	conn->recv_buff = malloc(size);
	if (!conn->recv_buff) return(NULL);
	bzero(conn->recv_buff, conn->recv_buff_len);
	return(conn->recv_buff);
}

/*
 * Reset the receive buffer by moving any existing data to the start of the
 * buffer.
 */
void
core_conn_reset_recv_buff(conn, buffp)
struct core_conn* conn;
uint8_t * buffp;
{
	if (!conn) return;
	if (!conn->recv_buff) return;

	/* data exists in the buffer that should be saved */
	if (buffp > conn->recv_buff) {
		/* move from current ptr buffp to start of buffer */
		memmove(conn->recv_buff, buffp, conn->recv_len);
	/* buffer data has been used up, free it for reuse 
	 * (we don't actually free it here, to avoid often malloc/free-ing)
	 */
	} else {
		bzero(conn->recv_buff, conn->recv_buff_len);
		conn->recv_len = 0;
	}
}

/*
 * Close a core connection
 * This closes a socket a frees the state. In the future, we may want to
 * leave the state and attempt to reconnect or later garbage collect.
 */
int
free_core_conn(conn)
struct core_conn *conn;
{
	struct core_conn *c, *prev;
	if (!conn)
		return(-1);

	closesocket(conn->sock);
	conn->sock = 0;
	prev = NULL;

	/* locate conn in the global conns list */
	for (c = conns; c; prev = c, c = c->next)
		if (conn == c) break;

	/* free and unlink conn */
	if (!c)
		return(-1);
	if (prev)
		prev->next = conn->next;
	else
		conns = conns->next;
	if (conn->recv_buff)
		free(conn->recv_buff);
	free(conn);

	return(0);
}

/*
 * Empty the connection list.
 */
void 
free_core_conns(void)
{
	struct core_conn *conn, *next;

	for (conn = conns; conn; ) {
		next = conn->next;
		closesocket(conn->sock);
		if (conn->recv_buff)
			free(conn->recv_buff);
		free(conn);
		conn = next;
	}
}

struct core_conn*
find_core_conn(sock, type)
int sock;
int type; /* optional */
{
	struct core_conn *conn;
	for (conn = conns; conn; conn = conn->next) {
		if ((sock > 0) && (conn->sock == sock)) {
			if ((type > 0) && (conn->type == type)) {
				return(conn);
			/* match only on sock, not type  */
			} else if (type <= 0) { 
				return(conn);
			}
		}
	}
	return NULL; /* not found */
}
