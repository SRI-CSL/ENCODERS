/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE execution server for FreeBSD vimages.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#include <signal.h>		/* signal() */
#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <sys/wait.h>		/* waitpid() */
#include <sys/stat.h>		/* file modes */
#include <sys/ioctl.h>		/* ioctl() */
#ifdef FREEBSD411
#include <sys/param.h>
#endif
#if 0
#include <sys/vimage.h>		/* vimage ioctls */
#endif
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select(), execlp() */
#include <time.h>		/* ctime() */
#include <stdarg.h>		/* va_start() */
#include <fcntl.h>		/* open() */

#include <coreapi/coreapi.h>
#include <cored.h> 
#include <coreconn.h>
#include "core_bsd_exec.h"

/*
 * Globals.
 */
struct core_conn *conns=NULL;		/* linked-list of connections */
struct exec_queue_entry *exec_queue=NULL; /* storted queue of exec jobs */
int exec_sock=0;
int verbose_debug=0;

/*
 * Main routine.
 */
int 
main(argc, argv)
int argc;
char **argv;
{
	char log_filename[255];
	pid_t pid;
	int log_opts, i;

	/*
	 * Initializations
	 */
	int do_daemon = 0, do_log = 0; /* options */
	struct sockaddr_in connect_addr;
	int core_sock;
	bzero(&connect_addr, sizeof(connect_addr));
	signal(SIGINT, exec_terminate);
	signal(SIGTERM, exec_terminate);
	signal(SIGPIPE, exec_signal_ignore);
	signal(SIGSEGV, exec_terminate);
	sprintf(log_filename, "%s", EXEC_DEFAULT_LOG);
	core_sock = 0;

	/*
	 * Parse command-line arguments.
	 */
	argv++, argc--;
	while (argc > 0) {
		if (strcmp(*argv, "-d") == 0) {
			do_daemon = 1;
			do_log = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-l") == 0) {
			argv++, argc--;
			do_log = 1;
			if (argc==0 || !argv) {
				ex_log("Error: please specify log file.\n");
				print_usage();
				exit(1);
			} else {
				strncpy(log_filename, *argv, 255);
				ex_log("Using the log file: %s\n",log_filename);
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-k") == 0) {
			ex_log("Preserving the log file.\n");
			log_opts = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-v") == 0) {
			verbose_debug = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-h") == 0) {
			print_usage();
			exit(0);
		}

		/* unknown arguments */
		print_usage();
		exit(1);
	}

	/*
         * Run as daemon.
         */	
	if (do_daemon) {
		/* check for PID file */
		if (ex_write_pid(EXEC_DEFAULT_PID, 0) < 0)
			exit(1);
		if ((pid = fork()) < 0) {
			ex_log("fork() error: %s\n", strerror(errno));
			exit(1);
		} else if (pid > 0) {
			i = ex_write_pid(EXEC_DEFAULT_PID, pid);
			if (i < 0) { /* PID file already exists, kill child */
				kill(pid, SIGTRAP);
				exit(1);
			}
			exit(0);
		}
		umask(0); /* change file mode mask */
		if (setsid() < 0) /* obtain a new process group */
			exit(1);
		if (chdir("/") < 0)
			exit(1);
	}
	if (do_log) { /* replace stdout/stderr/stdin */
		if (ex_open_log(log_filename, log_opts) < 0) {
			fprintf(stderr,
				"Error opening log file '%s' - %s, quitting.\n",
				log_filename, strerror(errno));
			exit(1);
		}
	}

	signal(SIGINT, exec_terminate);
	signal(SIGTERM, exec_terminate);
	signal(SIGPIPE, exec_signal_ignore);
	signal(SIGSEGV, exec_terminate);
	signal(SIGHUP, exec_signal_debug);

	print_banner();

	select_loop();
	return (0);
}

/*
 * Print or log a title message.
 */
void
print_banner()
{
	struct timeval t;
	gettimeofday(&t, NULL);
	ex_log("CORE Execution Server v.%.1f - %s",
		CORED_VER, ctime(&t.tv_sec));
}

/*
 * Prints command-line options.
 */
void
print_usage()
{
	print_banner();
	printf("Execution server for CORE emulations.");
	printf("\n");
	printf("usage: coreexecd [-d] [-l <log-file>] [-k] [-v]\n");
	printf("\t-d\t\tdaemonize:\trun in the background and output to\n");
	printf("\t\t\t\t\tlog file\n");
	printf("\t-l <log-file>\tlog output to specified file\n");
	printf("\t-k keep the log file, don't truncate if it exists\n");
	printf("\t-v enable verbose debugging\n");
}

/*
 * This is where the program spends all of its time.
 */
int
select_loop()
{
	int max, err, control_sock;
	fd_set read_fdset;
	struct timeval to, now, control_retry = {0, 0};
	struct core_conn *conn;

	/*
	 * Loop forever. A separate signal handler will 
         * catch CTRL+C or KILL signals.
	 */
	for (;;) {
		/* Set up for select() call */
		max = 0;
		control_sock = -1;
		FD_ZERO(&read_fdset);
		for (conn = conns; conn; conn = conn->next) {
			if (conn->sock == 0)
				continue;
			if (conn->type == CORE_CONNTYPE_CONTROL)
				control_sock = conn->sock;
			FD_SET((unsigned int)conn->sock, &read_fdset);
			if (conn->sock > max)
				max = conn->sock;
		}
		to.tv_sec = 0;
		to.tv_usec = 333400;

		/* Perform select() and dispatch to separate receive functions
		 * if there is any data. 
                 */
		if ((err = select(max+1, &read_fdset, NULL,NULL, &to)) < 0) {
			ex_log("select() error(%d): %s\n", 
				errno, strerror(errno));
			if (errno != EINTR)
				return(-errno);
		} else if (err == 0) {
			/* timeout */
			gettimeofday(&now, NULL);
			if ((control_sock < 0) &&
			    (now.tv_sec > control_retry.tv_sec))
				control_retry.tv_sec = now.tv_sec + 
						connect_core_daemon(&now);
			process_exec_queue(&now, control_sock);
		} else  {
			/* Check for data on all our sockets. */
			for (conn = conns; conn; conn = conn->next) {
				if (conn->sock == 0)
					continue;
				if (!FD_ISSET(conn->sock, &read_fdset))
					continue;
				/* FIFO containing exec output */
				if (conn->type == CORE_CONNTYPE_FIFO) {
					if (receive_exec_output(conn->sock)<0) {
						free_core_conn(conn);
						break;
					}
				/* CORE API socket */
				} else if (receive_core(conn) < 0) {
					free_core_conn(conn);
					break; /* exit loop: conn now invalid!*/
				}
			} /* end for each conn */

		/* end if select() */
		}
	/* end for (;;) */
	}

	return(0);
}


/* 
 * Perform socket(), bind(), and listen() calls in one function.
 */
#define MAX_INCOMING 200
int
socket_bind(protocol, addr, msg)
int protocol;
struct sockaddr *addr;
char *msg;
{
	int s, addrlen, err;
	int type = (protocol == IPPROTO_TCP) ? SOCK_STREAM : SOCK_DGRAM;

	/* open socket */
	if ((s = socket(addr->sa_family, type, protocol)) < 0) {
		ex_log("%s socket() error %d: %s\n", 
			msg, errno, strerror(errno));
		return(-1);
	}

	/* bind socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	if ((err = bind(s, addr, addrlen)) < 0) {
		ex_log("%s bind() error %d: %s\n", msg, errno, strerror(errno));
		closesocket(s);
		return(-1);
	}
	
	/* put socket into listening state if TCP */
	if (type == SOCK_STREAM) {
		if ((err = listen(s, MAX_INCOMING)) < 0) {
			ex_log("%s listen() error %d: %s\n ", 
				msg, errno, strerror(errno));
			closesocket(s);
			return(-1);
		}
	}

	return(s);
}


/* 
 * Perform socket() and connect() calls in one function.
 */
int
socket_connect(protocol, addr, flags)
int protocol;
struct sockaddr *addr;
int flags;
{
	int s, addrlen;
	char name[255];

	sprintf(name, "%u.%u.%u.%u:%u", 
		NIPQUAD(((struct sockaddr_in*)addr)->sin_addr.s_addr),
		ntohs(((struct sockaddr_in*)addr)->sin_port));

	ex_log("Connecting to %s using %s...\n", name,
		(protocol == IPPROTO_TCP) ? "TCP" : "UDP");

	/* open socket */	
	if ((s = socket(addr->sa_family, (protocol == IPPROTO_TCP) ? 
			SOCK_STREAM : SOCK_DGRAM, protocol)) < 0) {
		ex_log("socket() error %d: %s\n", errno, strerror(errno));
		return(-1);
	}

	/* connect socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	/* else IPv6 set sin6_port */
	if (connect(s, addr, addrlen) < 0) {
		ex_log("connect() error %d: %s\n", errno, strerror(errno));
		closesocket(s);
		return(-1);
	}

	return(s);
}

/*
 * Connect to the CORE daemon, then register with it. Print messages on success
 * or failure. Returns the number of seconds until connect retry.
 */
int
connect_core_daemon(now)
struct timeval *now;
{
	struct sockaddr_in connect_addr;
	int core_sock;
	bzero(&connect_addr, sizeof(connect_addr));

	/*
	 * Connect to CORE daemon.
	 */
	connect_addr.sin_family = AF_INET;
	connect_addr.sin_port = htons(CORE_API_PORT);
	core_sock = socket_connect(IPPROTO_TCP, SA(&connect_addr), 0);
	if (core_sock < 0) {
		ex_log("Couldn't connect to CORE daemon on port %d, retry in %d"
			" seconds - %s", CORE_API_PORT, CORE_CONTROL_RETRY,
			ctime(&now->tv_sec));
		return(CORE_CONTROL_RETRY);
	}
	ex_log("Connected to CORE daemon on port %d - %s",
		CORE_API_PORT, ctime(&now->tv_sec));
	add_core_conn(core_sock, CORE_CONNTYPE_CONTROL);
	send_exec_register(core_sock);
	return(0);
}

/*
 * Register this Execution Server with the CORE daemon.
 */
int
send_exec_register(s)
int s;
{
	uint8_t buf[255];
	const uint8_t name[] = "coreexecd\0";
	int len, hdr_len, flags = 0;

	hdr_len = len = core_api_create_message(buf, CORE_API_REG_MSG, flags,
						0, NULL);
	len += core_api_create_tlv(&buf[len], CORE_TLV_REG_EXECSRV,
				   sizeof(name), (uint8_t *)name);
	core_api_message_set_length(buf, len - hdr_len);

	return send(s, buf, len, 0);
}


/*
 * Handle FIFO execution output activity
 */
int
receive_exec_output(fd)
int fd;
{
	int len, buf_len, flags;
	uint8_t buf[2048], *tmp;
	struct exec_queue_entry *e, *prev;

	len = sizeof(buf);
	flags = 0;
	bzero(buf, len);

	/* get exec queue entry based on descriptor */
	e = find_exec_queue(fd, &prev);
	if (!e)
		return(-1); /* what job is this? */

	len = read(fd, (char *)buf, len); /* this should be non-blocking */
	if (len < 0) {
		ex_log("recvfrom() error(%d): %s\n", errno, strerror(errno));
		del_exec_queue(e, prev);
		return(-1);
	} else if (len == 0) { /* socket closed */
		del_exec_queue(e, prev);
		return(-1);
	}
	
	buf_len = len + e->exec_result_len;
	tmp = malloc(buf_len);
	if (!tmp) {
		ex_log("malloc() error\n");
		return(-1);
	}

	if (e->exec_result_len > 0) { /* concat existing output */
		memcpy(tmp, e->exec_result, e->exec_result_len);
		free(e->exec_result);
		memcpy(&tmp[e->exec_result_len], buf, len);
	} else {
		memcpy(tmp, buf, len);
	}
	e->exec_result_len = buf_len;
	e->exec_result = tmp;

	ex_log("got %d bytes from pid %u, job: ", len, e->exec_pid);;
	log_queue_entry(e);
	ex_log("\n");

	queue_entry_check_status(e);
	return(0);
}

/*
 * Check the status of the child process. Update exec_status if the process
 * is done.
 */
void
queue_entry_check_status(e)
struct exec_queue_entry *e;
{
	int status;
	if (!e)
		return;
	if (e->exec_pid <= 0)
		return;
	waitpid(e->exec_pid, &status, WNOHANG);
	if (WIFEXITED(status)) { /* this causes the results to be sent back */
		e->exec_status = CORE_EXEC_STATUS_RESULTS;
		e->exec_pid = -1; /* done with this pid */
	}
}

/*
 * Handle CORE API socket activity
 */
int
receive_core(conn)
struct core_conn *conn;
{
	int len, flags, type, err=0;
	socklen_t addrlen;
	uint8_t buf[2048], *bufp;
	struct sockaddr_in addr;
	uint16_t msg_len;
	int s;

	len = sizeof(buf);
	flags = 0;
	bzero(buf, len);

	if (!conn)
		return(-1);
	s = conn->sock;

	len = recvfrom(s, (char *)buf, len, flags, SA(&addr), &addrlen);
	if (len < 0) {
		ex_log("recvfrom() error(%d): %s\n", errno, strerror(errno));
		return(-1);
	} else if (len == 0) { /* socket closed */
		return(-1);
	}
	/* ex_log("receive_core(): %d bytes\n", len); */

	bufp = buf;
	while (len > 0) {
		/* parse CORE API message header */
		err = 0;
		msg_len = len;
		type = core_api_parse_message(bufp, &msg_len);
		if (type < 0) {
			ex_log("receive_core(): bad message, %d bytes "
				"discarded\n", len);
			break;
		}
		/* handle only CORE API Execute messages */
		switch (type) {
		case CORE_API_EXEC_MSG:
			err = receive_exec_msg(s, bufp, msg_len);
			break;
		default:
			err = -1;
			ex_log("warning: CORE API message type %d ignored "
				"by execution server.\n", type);
		}
		/* advance ptr */
		msg_len += sizeof(struct core_api_msg);
		bufp += msg_len;
		len -= msg_len;
		if (len < 0) {
			ex_log("receive_core(): overflow %d %d\n", 
				len, msg_len);
			break;
		} else if (err < 0) {
			ex_log("receive_core(): message type %d error\n", type);
			break;
		}
	}
	
	return(err);
}

/*
 * Parse a CORE API Execute message and put it into the execution queue.
 */
int
receive_exec_msg(core_sock, buf, length)
int core_sock;
uint8_t *buf;
uint16_t length;
{
	struct core_api_tlv *tlv;
	uint32_t node_id, exec_id, exec_time;
	uint16_t flags;
	uint8_t cmd_str[255];
	memset(cmd_str, 0, sizeof(cmd_str));

	flags = (uint16_t) core_api_message_get_flags(buf);

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_NODE);
	if (core_api_get_tlv_val32(tlv, &node_id) < 0)
		return(-1); /* node number is required */

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_NUM);
	if (core_api_get_tlv_val32(tlv, &exec_id) < 0)
		return(-1);

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_TIME);
	core_api_get_tlv_val32(tlv, &exec_time); /* default time is zero */ 

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_CMD);
	if (!tlv)
		return(-1);
	if (core_api_get_tlv_string(tlv, cmd_str, sizeof(cmd_str)) < 0)
		return(-1);

	return(add_exec_queue(node_id, exec_id, exec_time, cmd_str));

	return(0);
}


/*
 * Send a CORE API Execute message with results from the execution queue.
 */
int
send_exec_msg(s, e)
int s;
struct exec_queue_entry *e;
{
	int buf_len, len, hdr_len, err;
	uint8_t *buf;

	if (!e)
		return(-1);
	/* ex_log("send_exec_msg(): result_len=%d\n", e->exec_result_len); */
	e->exec_status = CORE_EXEC_STATUS_DONE;
	/* allocate a little extra buffer space for padding */
	buf_len = sizeof(struct core_api_msg) + 4*sizeof(struct core_api_tlv) + 
			6*sizeof(uint32_t) + e->exec_result_len + 8;
	buf = malloc(buf_len);
	if (!buf)
		return(-1); /* malloc error */

	hdr_len = len = core_api_create_message(buf, CORE_API_EXEC_MSG, 0, 0,
						NULL);

	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NODE,
				     e->exec_node_id);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NUM,
				     e->exec_id);
	/* assume result time has already been updated... */
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_TIME,
				     e->exec_time);
	/* TODO: does e->exec_result_len exceed max? */
	len += core_api_create_tlv(&buf[len], CORE_TLV_EXEC_RESULT,
				   e->exec_result_len, e->exec_result);

	core_api_message_set_length(buf, len - hdr_len);
	err = send(s, buf, len, 0);
	free(buf);
	return(err);
}

int
add_exec_queue(node_id, exec_id, exec_time, cmd_str)
uint32_t node_id;
uint32_t exec_id;
uint32_t exec_time;
uint8_t *cmd_str;
{
	struct exec_queue_entry *e, *prev=NULL;
	int cmd_len;

	/* locate previous queue entry, if any */
	for (e = exec_queue; e; e = e->next) {
		if (e->exec_id == exec_id)
			return(-1); /* duplicate IDs not allowed! */
		if (e->exec_time > exec_time)
			break;
		prev = e;
	}

	/* allocate a new queue item */
	cmd_len = strlen((char *)cmd_str) + 1; /* include NULL byte */
	e = (struct exec_queue_entry*) malloc(sizeof(struct exec_queue_entry));
	if (!e) return(-1); /* ENOMEM */
	e->exec_cmd = malloc(cmd_len);
	if (!e->exec_cmd) return(-1); /* ENOMEM */
	e->exec_time = exec_time;
	e->exec_node_id = node_id;
	e->exec_id = exec_id;
	strcpy((char *)e->exec_cmd, (char *)cmd_str);
	e->exec_result = NULL;
	e->exec_result_len = 0;
	e->exec_status = CORE_EXEC_STATUS_NONE;
	e->exec_pid = 0;
	e->exec_fd = -1;
	e->next = NULL;

	/* link it into the queue */
	if (!prev) {
		exec_queue = e;
	} else {
		e->next = prev->next;
		prev->next = e;
	}
	return(0);
}

/*
 * Remove an entry from the execution queue. If the previous entry is supplied,
 * this prevents scanning the entire queue.
 */
int
del_exec_queue(e, prev)
struct exec_queue_entry *e;
struct exec_queue_entry *prev;
{
	struct exec_queue_entry *tmp, *start;
	int status;
	char filename[30];

	if (!e)
		return(-1);
	if (prev)
		start = prev;
	else
		start = exec_queue;

	/* exec_fd is closed when conn freed */
	/* search the entire queue when prev not specified */
	prev = NULL;
	for (tmp = start; tmp; tmp = tmp->next) {
		if (tmp->exec_id == e->exec_id)
			break;
		prev = tmp;
	}
	if (!tmp)
		return(-1); /* not found in queue */

	/* delete from queue */
	if (prev)
		prev->next = tmp->next;
	else
		exec_queue = tmp->next;

	/* cleanup, destroy */
	/* XXX any data left to send? */
	sprintf(filename, "/tmp/coreexecd.%u", e->exec_id);
	unlink(filename);
	if (tmp->exec_cmd)
		free(tmp->exec_cmd);
	if (tmp->exec_result)
		free(tmp->exec_result);
	/* should we send KILL? */
	if (tmp->exec_pid > 0)
		waitpid(tmp->exec_pid, &status, WNOHANG);
	ex_log("cleaning up job number %u\n", tmp->exec_id);
	bzero(tmp, sizeof(tmp));
	free(tmp);
	return(0);
}

/*
 * Locate an execution queue entry given its file descriptor. Optionally return
 * the previous queue entry.
 */
struct exec_queue_entry *
find_exec_queue(fd, prev)
int fd;
struct exec_queue_entry **prev;
{
	struct exec_queue_entry *e;

	if (prev)
		*prev = NULL;
	for (e = exec_queue; e; e = e->next) {
		if (e->exec_fd == fd)
			break; /* found */
		if (prev)
			*prev = e;
	}
	return(e); /* may be NULL, not found */
}

void
log_queue_entry(e)
struct exec_queue_entry *e;
{
	if (!e) {
		ex_log("<null>");
		return;
	}
	ex_log("(time: %u, node: %u, execid: %u, cmd='%s', result=(%d bytes), "
		"status=%d, pid=%u, fd=%d)", e->exec_time, e->exec_node_id,
		e->exec_id, e->exec_cmd, e->exec_result_len, e->exec_status,
		e->exec_pid, e->exec_fd);
}

/*
 * Run jobs on the queue. This function may modify the queue and/or the
 * connection list.
 */
void
process_exec_queue(now, control_sock)
struct timeval *now;
int control_sock;
{
	struct exec_queue_entry *e, *prev;
	struct core_conn *conn;
	int do_cleanup = 0;

	for (e = exec_queue; e; e = e->next) {
		queue_entry_check_status(e); /* update status if pid */
		switch(e->exec_status) {
		case CORE_EXEC_STATUS_NONE:
			/* start a maximum number of jobs here? */
			if (now->tv_sec >= e->exec_time)
				run_exec_item(e);
			break;
		case CORE_EXEC_STATUS_RESULTS:
			send_exec_msg(control_sock, e);
			break;
		case CORE_EXEC_STATUS_DONE:
			do_cleanup = 1;
			break;
		}
	}

	if (!do_cleanup)
		return;
	/* after we're done processing the queue, go back for cleanup */
	prev = NULL;
	for (e = exec_queue; e; e = e->next) {
		/* log_queue_entry(e); */ /* debug */
		/* this modifies the queue, so we only delete one item; if there
		 * are more entries to prune, just get them next time */
		if (e->exec_status == CORE_EXEC_STATUS_DONE) {
			conn = find_core_conn(e->exec_fd, CORE_CONNTYPE_FIFO);
			if (conn) free_core_conn(conn);
			del_exec_queue(e, prev);
			break;
		}
		prev = e;
	}
}

/*
 * Execute an entry from the execution queue. This forks a child process that
 * reassigns stdout/stderr to a fifo.
 */
int
run_exec_item(e)
struct exec_queue_entry *e;
{
	char filename[30];
	int fd;
	pid_t pid;
	uint32_t node_id;
	char cmd[255];

	if (!e) return(-1);
	node_id = e->exec_node_id;
	strncpy(cmd, (char *)e->exec_cmd, sizeof(cmd));
	sprintf(filename, "/tmp/coreexecd.%u", e->exec_id);
	mkfifo(filename, S_IRUSR | S_IWUSR);
	fd = open(filename, O_RDONLY | O_NONBLOCK);
	if (fd < 0) {
		ex_log("warning: open(%s) error: %s\n", filename, 
			strerror(errno));
		return(-1);
	}
	ex_log("run_exec_item: created pipe %s\n", filename);


	pid = fork();

	/* child process */
	if (pid == 0) {
		close(fd);
		fd = open(filename, O_CREAT | O_TRUNC | O_WRONLY);
		if (fd < 0) {
			perror("child open()");
		}
		ex_log("run_exec_item: child opened %s\n", filename);
		dup2(fd, fileno(stdout)); /* replace stdout */
		close(fd); /* close original, it has been duplicated */
		dup2(fd, fileno(stderr)); /* replace stderr */
		close(fd); /* close original, it has been duplicated */
		do_child(node_id, cmd);
		return(0); /* shouldn't get here */
	}

	e->exec_pid = pid;
	e->exec_status = CORE_EXEC_STATUS_RUNNING; /* child is running */
	e->exec_fd = fd;
	add_core_conn(fd, CORE_CONNTYPE_FIFO);
	return(0);
}

/*
 * This routine is executed by the child process. It switches to the vimage
 * based on the given node number, and passes control onto the given command.
 */
void
do_child(node_id, cmd_str)
uint32_t node_id;
char *cmd_str;
{
#if 0
	int s, argc;
	struct vi_req vi_req;
	char *args[16], *cmd, *p;
	char binname[] = "coreexecd\0";

	s = socket(AF_INET, SOCK_DGRAM, 0);
	bzero(&vi_req, sizeof(vi_req));

	vi_req.req_action = VI_SWITCHTO;
	sprintf(vi_req.vi_name, "e0_n%u", node_id);

	if (ioctl(s, SIOCSPVIMAGE, (caddr_t)&vi_req) < 0) {
		perror("ioctl() error: ");
		close(s);
		return;
	}
	close(s);

	/* build array of null-terminated strings; spaces separate arguments
	 * and quoting is not supported here */
	argc = 0;
	bzero(args, sizeof(args));
	args[argc++] = binname;
	cmd = (char *)cmd_str;
	p = index(cmd, ' ');
	while (p && (argc < 16)) {
		*p = '\0';	/* NULL-terminate this argument */
		args[argc++] = ++p;
		p = index(p, ' ');
	}
	/* fprintf(stderr, "going to execute '%s' with %d arguments\n",
		cmd, argc); */
	execvp(cmd, args);
	/* not reached, unless execlp error */
	exit(1);
#endif
}

/*
 * Print or log messages.
 */
void
ex_log(char *fmt, ...)
{
	va_list ap;
	
	va_start(ap, fmt);
	vfprintf(stdout, fmt, ap);
	va_end(ap);
	fflush(stdout);
}

/*
 * Open log file.
 */
int
ex_open_log(filename, opts)
char *filename;
int opts;
{
	freopen("/dev/null", "r", stdin);

	if (!freopen(filename, (opts == 1) ? "a" : "w", stdout))
		return(-1);

	if (!freopen(filename, "a", stderr)) /* /dev/null ? */
		return(-1);

	return(0);
}

/*
 * Close log file.
 */
void
ex_close_log()
{
	fflush(stdout);
	fflush(stderr);
	fclose(stdout);
	fclose(stderr);
}

/*
 * Write PID to PID file, unless it already exists.
 */
int
ex_write_pid(filename, pid)
char *filename;
pid_t pid;
{
	char buf[16];
	FILE *fp;

	fp = fopen(filename, "r");
	if (fp) {
		bzero(buf, 16);
		fread(buf, 16, 1, fp);
		buf[strlen(buf) - 1 ] = '\0';
		fprintf(stderr, "CORE execution server already running (%s), "
			"or PID file '%s' needs to be removed.\n",
			buf, filename);
		fclose(fp);
		return(-1);
	}

	if (pid == 0) /* don't write a file, just check */
		return(0);

	fp = fopen(filename, "w");
	if (!fp) {
		fprintf(stderr, "Error opening PID file '%s' - %s, quitting.\n",
			filename, strerror(errno));
		return(-1);
	} else {
		sprintf(buf, "%d\n", pid);
		fwrite(buf, strlen(buf), 1, fp);
		fclose(fp);
	}

	return(0);
}

/*
 * Signal handler for status debugging.
 */
void
exec_signal_debug(signal)
int signal;
{
	int count=0;
	struct timeval t;
	struct exec_queue_entry *e;

	gettimeofday(&t, NULL);
	ex_log("\n----- CORE Execution server debug ----- %s",
	       ctime(&t.tv_sec));
	if (exec_queue)
		ex_log("Current jobs in exec queue:\n");
	for (e = exec_queue; e; e = e->next) {
		log_queue_entry(e);
		count++;
	}
	ex_log("----- %d jobs total -----\n", count);
}

/*
 * Signal handler for program termination.
 */
void
exec_signal_ignore(signal)
int signal;
{
	ex_log("\n(ignoring signal %d)\n");
}

/*
 * Signal handler for program termination.
 */
void
exec_terminate(signal)
int signal;
{
	struct timeval t;

	gettimeofday(&t, NULL);
	ex_log("\nCORE execution server shutting down (with signal %d%s) - "
		"%s\n", signal, 
		signal==SIGHUP ? " SIGHUP" :
		signal==SIGINT ? " SIGINT" :
		signal==SIGTERM ? " SIGTERM" :
		signal==SIGSEGV ? " SIGSEGV" : "",
		ctime(&t.tv_sec)
		);
	free_core_conns();
	ex_close_log();
	unlink(EXEC_DEFAULT_PID);
	exit(signal);
}
