/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * core_netgraph.h
 * 
 * Functions specific to the FreeBSD Netgraph system.
 */

#ifndef CORE_NETGRAPH_H
#define CORE_NETGRAPH_H

int  open_netgraph_control(char *);
int  receive_netgraph_control(int);
int  send_wlan_netgraph_message(int, uint32_t, uint32_t, uint32_t, int,
	struct link_params *);
int  send_ng_shutdown(int, char *);
int  send_ng_mkpeer(int, char *, char *, char *, char *, char *, uint32_t *);
int  send_ng_connect(int, char *, char *, char *, char *);
void wlan_debug_print_ngcontrol(char *, char *, int);

#ifdef FREEBSD411
#define NG_PATHSIZ NG_PATHLEN+1
#define NG_NODESIZ NG_NODELEN+1
#define NG_HOOKSIZ NG_HOOKLEN+1
#define NG_TYPESIZ NG_TYPELEN+1
#endif

#endif /* CORE_NETGRAPH_H */
