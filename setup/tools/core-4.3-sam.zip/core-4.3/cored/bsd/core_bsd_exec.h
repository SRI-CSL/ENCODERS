/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE execution server for FreeBSD vimages.
 *
 */
#ifndef _CORE_BSD_EXEC_H_
#define _CORE_BSD_EXEC_H_

/*
 * Constants/configurables
 */
#define EXEC_DEFAULT_PID "/var/run/coreexecd.pid"
#define EXEC_DEFAULT_LOG "/var/log/coreexecd.log"
#define CORE_CONTROL_RETRY 5

#define CORE_EXEC_STATUS_NONE		0
#define CORE_EXEC_STATUS_RUNNING	1
#define CORE_EXEC_STATUS_RESULTS	2
#define CORE_EXEC_STATUS_DONE		3

/*
 * Data types (move to .h?)
 */
struct exec_queue_entry {
	uint32_t exec_time; /* queue entries sorted by time */
	uint32_t exec_node_id;
	uint32_t exec_id;
	uint8_t *exec_cmd;
	uint8_t *exec_result;
	int	 exec_result_len;
	int      exec_status;
	pid_t    exec_pid;
	int      exec_fd;
	struct exec_queue_entry *next;
};

/*
 * Function prototypes.
 */
void print_banner(void);
void print_usage(void);
int  select_loop(void);
int  socket_bind(int, struct sockaddr *, char *);
int  socket_connect(int, struct sockaddr *, int);
int  connect_core_daemon(struct timeval *);
int  send_exec_register(int);
int  receive_exec_output(int);
void queue_entry_check_status(struct exec_queue_entry *);
int  receive_core(struct core_conn*);
int  receive_exec_msg(int, uint8_t *, uint16_t);
int  send_exec_msg(int, struct exec_queue_entry *);
int  add_exec_queue(uint32_t, uint32_t, uint32_t, uint8_t *);
int  del_exec_queue(struct exec_queue_entry *, struct exec_queue_entry *);
struct exec_queue_entry *find_exec_queue(int, struct exec_queue_entry **);
void log_queue_entry(struct exec_queue_entry *);
void process_exec_queue(struct timeval *, int);
int  run_exec_item(struct exec_queue_entry *);
void do_child(uint32_t, char *);
int  ex_open_log(char *, int);
void ex_close_log();
int  ex_write_pid(char *, pid_t);
void exec_signal_ignore(int);
void exec_signal_debug(int);
void exec_terminate(int);
void ex_log(char *fmt, ...);

#endif /* _CORE_BSD_EXEC_H_ */
