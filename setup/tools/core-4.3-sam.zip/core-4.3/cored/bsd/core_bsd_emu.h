/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * core_bsd_emu.h
 * 
 */

#ifndef CORE_BSD_EMU_H
#define CORE_BSD_EMU_H

struct core_node_data;
struct core_link_data;

int  init_bsd_emulation();

int  bsd_init();
int  bsd_node(uint16_t flags, uint32_t node,
	struct core_node_data *data);
int  bsd_netgraph_node(uint16_t flags, uint32_t node, 
	struct core_node_data *data);
int  bsd_link(uint16_t flags, uint32_t node1, uint32_t node2,
	struct core_link_data *data);
int  bsd_create_link(struct core_node *node1, struct core_node *node2,
	struct core_link_data *data);

#endif /* CORE_BSD_EMU_H */
