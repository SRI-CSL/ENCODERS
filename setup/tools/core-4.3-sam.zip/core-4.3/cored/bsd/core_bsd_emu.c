/*
 * CORE 
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE BSD emulation functions.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <unistd.h>		/* close() */
#include <errno.h>		/* errno */
#include <sys/socket.h>		/* inet_pton() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <netgraph.h>		/* Ng*()  */
#include <sys/ioctl.h>		/* ioctl() */
#include <sys/stat.h>		/* mkdir() */
#ifdef FREEBSD411
#include <sys/param.h>
#endif
#include <sys/vimage.h>		/* struct vi_req */

#include <coreapi/coreapi.h>
#include <cored.h>		/* wl_log(), etc. */
#include <core_emu.h>		/* g_emu, etc. */
#include <core_db.h>		/* add_core_node_db(), etc. */

#include "core_bsd_emu.h"
#include "core_netgraph.h"


struct core_emu bsd_emu = {
	.name = "virtnet",
	.init = bsd_init,
	.node = bsd_node,
	.link = bsd_link,
};

extern int control_sock; /* control socket from core_wlan.c */

/* local functions */
struct core_node *bsd_link_get_wlan();

/*
 * Set the Vimage/Netgraph emulation functions
 */
int
init_bsd_emulation()
{
	if (g_emu) /* already loaded? */
		return(-1);
	g_emu = &bsd_emu;

	return(g_emu->init());
}

int
bsd_init()
{
	int s = control_sock; /* assume this has already been opened */
	struct vi_req vi_req;

	/* perform capability checks and return -1 on failure */
	bzero(&vi_req, sizeof(vi_req));
	strcpy(vi_req.vi_name, ".");
	vi_req.req_action = VI_GET;
	if (ioctl(s, SIOCGPVIMAGE, (caddr_t)&vi_req) < 0) {
		wl_log("FreeBSD emulation disabled!\n");
		g_emu->node = NULL;
		g_emu->link = NULL;
		return(-1);
	}
	wl_log("FreeBSD emulation enabled.\n");
	return(0);
}

int
bsd_node(uint16_t flags, uint32_t node_id, struct core_node_data *data)
{
	struct vi_req vi_req;
	struct core_node *node;
	int cmd, s;
	char path[255];
	mode_t mode;
	static uint8_t mac=0; /* TODO: improve this */

	wl_log("bsd_node(flags=0x%x, node=0x%x, type=0x%x)\n",
		flags, node_id, data->type);
	node = NULL;
	if (flags & CORE_API_ADD_FLAG) {
		cmd = VI_CREATE;
		node = add_core_node_db(node_id, data);
		if (!node) {
			wl_log("bsd_node(): error adding node to db!\n");
			return(-1);
		}
		data = &node->node_data; /* reset ptr, data stored with node */
	} else if (flags & CORE_API_DEL_FLAG) {
		cmd = VI_DESTROY;
		node = find_core_node_db(node_id, NULL);
	} else {
		/* for now, we don't need to modify anything in the kernel
		 * may want to update node db
		 */
		cmd = VI_MODIFY;
		return(0);
	}

	if (data->type > PC) {
		/* for switch, hub, wlan, rj45, tunnel, ktunnel
		 * call appropriate Netgraph create function */
		return bsd_netgraph_node(flags, node_id, data);
	}

	if (cmd == VI_DESTROY) {
		if (data->type == router_quagga) {
			run_node_command_fmt(node,
					     "conf/quagga-shutdown.sh n%u",
					     node_id);
		}
	}

	s = control_sock;
	if (cmd == VI_DESTROY) {
		if (node && node->node_data.emuid) { /* shutdown eiface */
			sprintf(path, "[0x%x]:", node->node_data.emuid);
			send_ng_shutdown(s, path);
		}
		if (node && node->node_data.linkid) { /* shutdown pipe */
			sprintf(path, "[0x%x]:", node->node_data.linkid);
			send_ng_shutdown(s, path);
		}
		node = NULL;
		remove_core_node_db(node_id);
	}

	/*
	 * Add/delete kernel vimages
	 */
	bzero(&vi_req, sizeof(vi_req));
	strncpy(vi_req.vi_name, (char *)data->name, sizeof(vi_req.vi_name));
	vi_req.req_action = cmd;
	
	if (ioctl(control_sock, SIOCSPVIMAGE, (caddr_t)&vi_req) < 0) {
		wl_log("bsd_node error: %s\n", strerror(errno));
		return(-1);
	}
	wl_log("bsd_node: vimage %s has been %s.\n", data->name,
		(cmd == VI_CREATE) ? "created" : "destroyed");

	if (cmd == VI_DESTROY)
		return(0); /* finished with cleanup */

	/*
	 * Initialize a node
	 */
	run_node_command_fmt(node, "hostname n%d", node_id);

	/* create an ng_eiface interface */
	if (send_ng_mkpeer(s, ".", "eiface", "ether", "ether", path, 
			&data->emuid) < 0) {
		wl_log("bsd_node: error building interface\n");
		return(-1);
	} else {
		wl_log("bsd_node: installing interface %s (id 0x%x) into %s\n",
			path, data->emuid, data->name);
	}
	/* install interface into vimage */
	bzero(&vi_req, sizeof(vi_req));
	strncpy(vi_req.vi_name, (char *)data->name, sizeof(vi_req.vi_name));
	strncpy(vi_req.vi_chroot, path, sizeof(vi_req.vi_chroot));
#ifdef FREEBSD411
	vi_req.vi_parent_name[0] = 0;
#else
	vi_req.vi_if_xname[0] = 0;
#endif
//	strncpy(vi_req.vi_if_xname, "eth0", sizeof(vi_req.vi_if_xname));
	vi_req.req_action = VI_IFACE;
	if (ioctl(s, SIOCSIFVIMAGE, (caddr_t)&vi_req) < 0) {
		wl_log("bsd_node error: installing if %s\n", strerror(errno));
		return(-1);
	} else {
		wl_log("bsd_node: installed %s@%s\n", path, data->name);
	}
	run_node_command_fmt(node, "ifconfig eth0 ether 00:00:00:aa:0:%d",
			     mac++);

	/* create node directory */
	snprintf(path, sizeof(path), "/tmp/e0_n%d", node_id);
	mode = ACCESSPERMS;
	if (mkdir(path, mode) < 0) {
		wl_log("bsd_node error: making dir '%s' %s\n",
			path, strerror(errno));
		/* non-fatal */
	}
	/*
	 * start processes based on the type, model
	 */
	if (data->type == router_quagga) {
		snprintf(path, sizeof(path), "/tmp/e0_n%d/boot.conf", node_id);
		generate_config(node, path);
		run_node_command_fmt(node, "conf/quagga-startup.sh n%u",
				     node_id);
	}

	return(0);
}

int
bsd_netgraph_node(uint16_t flags, uint32_t node_id, struct core_node_data *data)
{
	int s;
	char ngtype[NG_TYPESIZ], hook[NG_HOOKSIZ], peerhook[NG_HOOKSIZ];
	char tmp[NG_TYPESIZ];

	/* wl_log("bsd_netgraph_node()\n"); */
	s = control_sock; /* by default nodes are hooked to this socket! */

	if (flags & CORE_API_DEL_FLAG) {
		/* may want to convert *emuid if name not specified */
		return(send_ng_shutdown(s, (char *)data->name));
	} else if (!(flags & CORE_API_ADD_FLAG)) {
		return(0); /* what to do? */
	}

	sprintf(hook, "anchor");
	sprintf(peerhook, "anchor");

	switch (data->type) {
	case switch_:
		sprintf(ngtype, "bridge");
		break;
	case hub:
		sprintf(ngtype, "hub");
		break;
	case wlan:
		sprintf(ngtype, "wlan");
		break;
	case rj45:
		ngtype[0] = 0; /* ng_iface already exists */
		break;
	case tunnel:
		ngtype[0] = 0; /* talk to span_ctl */
		break;
	case ktunnel:
		sprintf(ngtype, "ksocket");
		sprintf(peerhook, "inet/dgram/udp");
		break;
	default:
		return(-1); /* unsupported */
	}

	if (ngtype[0] == 0) {
		/* TODO: special cases - no netgraph node required */
		return(0);
	}

	/* create a netgraph node */
	if (send_ng_mkpeer(s, ".", ngtype, hook, peerhook, tmp, &data->emuid)
			< 0) {
		wl_log("bsd_netgraph_node: error making node %s: %s/%s/%s\n",
			data->name, ngtype, hook, peerhook);
		return(-1);
	}
	wl_log("bsd_netgraph_node: created %s node (0x%x)\n", 
		ngtype, data->emuid);

	/* name the node */
	sprintf(tmp, "[0x%x]:", data->emuid);
	if (NgNameNode(s, tmp, (char *)data->name) < 0) {
		wl_log("bsd_netgraph_node: error naming node %s: %x\n",
			data->name, data->emuid);
		/* non-fatal */
	}
	
	/* TODO: perform any other node setup here */
	return(0);
}

/*
 * The link message may create or delete wired or wireless links. Behavior
 * depends on the node type and model. Link parameters may be modified.
 */
int
bsd_link(uint16_t flags, uint32_t node1_id, uint32_t node2_id,
	struct core_link_data *data)
{
	struct core_link *link;
	struct core_node *node1, *node2, *wlan;
//	struct core_node_data tmp;
	int unlink;
	wl_log("bsd_link()\n");

	unlink = 0;
	if (flags & CORE_API_DEL_FLAG) {
		unlink = 1;
		link = find_core_link_db(node1_id, node2_id, NULL);
	} else {
		/* add or modify the link */
		link = add_core_link_db(node1_id, node2_id, data);
	}

	if (!link) {
		wl_log("bsd_link: link not found (unlink=%d)\n", unlink);
		return (-1);
	}

	if (link->node1 && link->node2) { /* use cached info */
		node1 = link->node1;
		node2 = link->node2;
	} else {
		node1 = find_core_node_db(node1_id, NULL);
		node2 = find_core_node_db(node2_id, NULL);
		if (!node1 || !node2) {
			wl_log("bsd_link: node(s) not found\n");
			return(-1); /* node(s) not found */
		}
		link->node1 = node1; /* cache the node lookup */
		link->node2 = node2;
	}

	/* TODO: first check node[1,2]->netid for wlan */
	/* special case: build a wlan node */
	if (node1->node_data.type == router_quagga &&
	    node1->node_data.model == wireless &&
	    node2->node_data.type == router_quagga &&
	    node2->node_data.model == wireless) {
		wlan = bsd_link_get_wlan();
		if (!wlan) {
			wl_log("bsd_link: failed to create wlan\n");
			return(-1); /* wlan create failed */
		}
		if (!unlink) {
			node1->node_data.netid = wlan->node_data.emuid;
			node2->node_data.netid = wlan->node_data.emuid;
			/* create link from each node to the wlan */
			bsd_create_link(wlan, node1, NULL);
			bsd_create_link(wlan, node2, NULL);
		}
		/* send set/unset message to wlan with node data */
		send_wlan_netgraph_message(control_sock, wlan->node_data.emuid,
				node1->node_data.linkid, 
				node2->node_data.linkid, unlink,
				(struct link_params*)&link->link_data);
	} else {
		/* XXX handle wired cases */
	}

	if (unlink)
		remove_core_link_db(node1_id, node2_id);

	return(0);
}

/*
 * find a wlan node or create one
 * this is for preserving functionality from the CORE GUI
 */
struct core_node *
bsd_link_get_wlan()
{
	struct core_node *w;
	struct core_node_data data;
	uint32_t wlan_id = 1000; /* same behavior as CORE GUI */
	uint16_t flags;

	bzero(&data, sizeof(data));
	data.type = wlan;
	w = find_core_node_db2(&data); /* expensive! */
	if (w) { /* return the first wlan found */
		wl_log("bsd_link_get_wlan(): found wlan '%s'\n",
			w->node_data.name);
		return(w);
	}

	flags = CORE_API_ADD_FLAG;
	sprintf((char *)data.name, "wlan%d", wlan_id);
	data.x = 25;
	data.y = 25;

	if (bsd_node(flags, wlan_id, &data) < 0) {
		wl_log("bsd_link_get_wlan: bsd_node error\n");
		return(NULL);
	}
	wl_log("bsd_link_get_wlan(): created wlan '%s'\n", data.name);
	return (find_core_node_db(wlan_id, NULL));
}

/*
 * creates a pipe node between two nodes and links them
 * assumes id of node interface is stored in node->emuid
 * stores id of pipe ind node->linkid
 */
int bsd_create_link(struct core_node *node1, struct core_node *node2,
	struct core_link_data *data)
{
	uint32_t *emuid, tmp;
	char n1p[NG_PATHSIZ], n2p[NG_PATHSIZ], lp[NG_PATHSIZ];
	char lname[NG_NODESIZ], n1hook[NG_HOOKSIZ], n2hook[NG_HOOKSIZ];
	int s = control_sock;
	static int linknum=0;

	wl_log("bsd_create_link()\n");

	if (!node1 || !node2)
		return(-1);

	emuid = data ? &data->emuid : &tmp;

	sprintf(n1p, "[0x%x]:", node1->node_data.emuid);
	sprintf(n2p, "[0x%x]:", node2->node_data.emuid);
	/* use data->name? */
	sprintf(lname, "e0_n%d-n%d", node1->node_id, node2->node_id);

	sprintf(n1hook, "link%d", linknum++); /* TODO */
	sprintf(n2hook, "ether");

	/* create pipe node: node1:if1 e0_n1-n2:upper */
	if (send_ng_mkpeer(s, n1p, "pipe", n1hook, "upper", lp, emuid) < 0) {
		wl_log("bsd_create_link(): error creating pipe\n");
		wl_log(" mkpeer %s pipe %s upper %s\n", n1p, n1hook, lp);
		return(-1); /* error creating pipe node */
	}
	node1->node_data.linkid = *emuid;
	node2->node_data.linkid = *emuid;
	/* name the pipe node */
	sprintf(lp, "[0x%x]:", *emuid);
	if (NgNameNode(s, lp, lname) < 0) {
		wl_log("bsd_create_link(): error naming node\n");
		return(-1); /* unable to name node */
	}
	/* connect node 2 to the pipe: e0_n1-n2:lower ngeth0:ether */
	sprintf(lp, "%s:", lname);
	if (send_ng_connect(s, lp, n2p, "lower", n2hook) < 0) {
		wl_log("bsd_create_link(): error connecting node\n");
		return(-1); /* error connecting to pipe */
	}

	return(0);
}
