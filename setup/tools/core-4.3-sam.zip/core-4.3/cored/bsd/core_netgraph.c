/*
 * CORE 
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE Netgraph functions.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#include <signal.h>		/* signal() */
#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <netgraph.h>		/* Ng*()  */

#include <coreapi/coreapi.h>
#ifndef MULTICAST_LOOKUPS
#define MULTICAST_LOOKUPS
#endif
#include <cored.h>
#include <models/model.h>
#include <models/model_list.h>
#include <kernel/ng_wlan/ng_wlan.h>

#include "core_netgraph.h"

#ifndef NG_PATHLEN
#define NG_PATHLEN NG_PATHSIZ
#endif

/*
 * Open a control socket for local messages.
 */
int
open_netgraph_control(char *name)
{
	int s = 0;
	if (!name)
		return (-EINVAL);
	if ((NgMkSockNode(name, &s, NULL)) < 0) {
		return (-errno);
	} else {
		return (s);
	}
}

/*
 * Handle Netgraph control socket activity
 */
int
receive_netgraph_control(int s)
{
	int len, buflen, r_len;
	char buf[512], path[NG_PATHLEN+1], id[NG_PATHLEN+1], r[NG_TEXTRESPONSE];
	struct ng_mesg *ngm;
	uint32_t tmp;
	struct core_wlan_model *m;
	
	bzero(r, NG_TEXTRESPONSE);
	ngm = (struct ng_mesg*) buf;
	buflen = sizeof(buf);
	len = NgRecvMsg(s, ngm, buflen, path);
	if (len == 0) /* socket was closed */
		return(-1);

	switch(ngm->header.cmd) {
	case NGM_TEXT_CONFIG:
		/* Read flush=ID command */
		if (ngm->header.arglen && 
			!strncasecmp(ngm->data, "flush=", 5)) {
			strncpy(id, &ngm->data[6], sizeof(id));
			if ( id[0]=='a' && id[1]=='l' && id[2]=='l' ) {
				sprintf(r, "Flushing all node data.\n");
				flush_all_models();
			} else {
				sscanf(id, "%x", &tmp);
				sprintf(r, "Flushing data for WLAN 0x%x\n",tmp);
				for_each_model(m, g_models) if (m->flush)
					m->flush(0, tmp);
			}
			wl_log(r);
			break;
		} else {
		    sprintf(r, "invalid config");
		}
		break;
	default:
		wl_log("Warning: %s: unknown control message!\n", path);
		wlan_debug_print_ngcontrol(buf, path, len);
		break;
	}

	/* reply */
	r_len = strlen(r) + 1;
	if (r_len > 1) {
		NgSendReplyMsg(s, path, ngm, r, r_len);
	}
	return(0);
}


/*
 * Send a netgraph set/unset message to a ng_wlan node given link parameters.
 */
int send_wlan_netgraph_message(int s, uint32_t net, uint32_t node1,
	uint32_t node2,  int delete, struct link_params *params)
{
	char path[NG_PATHLEN+1];
	int arglen, err; /*, ng_sock; */
	struct ng_wlan_config	arg_config;
	struct ng_wlan_set_data	arg_set;

	bzero(&arg_config, sizeof(arg_config));
	bzero(&arg_set, sizeof(arg_set));
	
	sprintf(path, "[0x%x]:", net);

	if (delete) {
		arg_config.node1 = node1;
		arg_config.node2 = node2;
		arglen = sizeof(struct ng_wlan_config);
	} else {
		if (!params)
			return(-1);
		arg_set.node1 = node1;
		arg_set.node2 = node2;
		arg_set.delay 		= params->delay;
		arg_set.bandwidth 	= params->bw;
		arg_set.per 		= params->per;
		arg_set.duplicate 	= params->dup;
		arg_set.jitter		= params->jitter;
		arg_set.burst		= params->burst;
		arglen = sizeof(struct ng_wlan_set_data);
	}

	/* if (NgMkSockNode(NULL, &ng_sock, NULL) < 0) {
		wl_log("send_wlan_netgraph_message: unable to open a socket"
			"(err=%d)\n", errno);
		return(-1);
	} */
	err = NgSendMsg(s, path, NGM_WLAN_COOKIE,
			delete ? NGM_WLAN_NODES_UNSET : NGM_WLAN_NODES_SET,
			delete ?  (void *)&arg_config : (void *)&arg_set,
			arglen);
	/* close(ng_sock); */
	/* wl_log("sent %s message to WLAN %s (node1=0x%x node2=0x%x)",
		delete ? "unset" : "set", path, node1, node2);
	if (!delete) wl_log(" params=(%llu, %llu, %u, %u, %u)", 
			params->delay, params->bw, params->per, 
			params->dup, params->jitter);
	wl_log(" (err=%d)\n", err); // */
	return(err);	
}

/*
 * Send a netgraph mcastset/unset message to a ng_wlan node for a given
 * group, source number.
 */
int
send_wlan_mcast_netgraph_message(int s, uint32_t net, uint32_t node1,
	uint32_t node2, int delete, uint32_t group, uint32_t source)
{
	char path[NG_PATHLEN+1];
	struct ng_wlan_multicast_set_data arg_set;
	int err;
	
	sprintf(path, "[0x%x]:", net);
	arg_set.node1 = node1;
	arg_set.node2 = node2;
	arg_set.group = group;
	arg_set.source = source;

	err = NgSendMsg(s, path, NGM_WLAN_COOKIE,
			delete ? NGM_WLAN_MULTICAST_UNSET : 
			NGM_WLAN_MULTICAST_SET, (void *)&arg_set,
			sizeof(arg_set));
	return(err);	
}

/*
 * Netgraph shutdown message, removes a node
 */
int
send_ng_shutdown(int s, char *path)
{
	return NgSendMsg(s, path, NGM_GENERIC_COOKIE, NGM_SHUTDOWN, NULL, 0);
}

/*
 * Netgraph mkpeer message, with resulting node name stored in result and
 * netgraph ID stored in emuid.
 */
int
send_ng_mkpeer(s, path, type, hook, peerhook, result, emuid)
int s;
char *path;
char *type;
char *hook;
char *peerhook;
char *result;
uint32_t *emuid;
{
	struct ngm_mkpeer arg;
	struct ng_mesg *rep;
	struct namelist *namelist;
	struct nodeinfo *nodeinfo;
	struct ngm_rmhook arg2;
	int i, err = 0;
	int arglen = sizeof(arg);
	char from_path[NG_HOOKSIZ];

	/* build/send a mkpeer message */
	bzero(&arg, arglen);
	snprintf(arg.type, NG_TYPESIZ, type);
	snprintf(arg.ourhook, NG_HOOKSIZ, hook);
	snprintf(arg.peerhook, NG_HOOKSIZ, peerhook);

	err = NgSendMsg(s, path, NGM_GENERIC_COOKIE, NGM_MKPEER, &arg, arglen);
	if (err < 0)
		return(err);

	/* get list of netgraph nodes */
	err = NgSendMsg(s, ".", NGM_GENERIC_COOKIE, NGM_LISTNODES, NULL, 0);
	if (err < 0)
		return(err);
	err = NgAllocRecvMsg(s, &rep, from_path);
	if (err < 0)
		return(err);
	namelist = (struct namelist *) rep->data;
	for (i = 0; i < namelist->numnames; i++) {
		nodeinfo = &namelist->nodeinfo[i];
		/* find the first netgraph node with matching type */
		if (strncmp(nodeinfo->type, type, NG_TYPESIZ)==0)
			break; /* found */
		nodeinfo = NULL;
	}

	/* remove hook from this socket */
	arglen = sizeof(arg2);
	bzero(&arg2, arglen);
	snprintf(arg2.ourhook, NG_HOOKSIZ, hook);
	err = NgSendMsg(s, "wlan_ctl:", NGM_GENERIC_COOKIE, NGM_RMHOOK, 
			&arg2, arglen);
	if (err < 0) wl_log("rmhook error! hook=%s\n", hook);

	/* fill result with peer name, and put id into emuid */
	if (nodeinfo) {
		strncpy(result, nodeinfo->name, NG_NODESIZ);
		*emuid = nodeinfo->id;
		err = 0;
	} else {
		bzero(result, NG_NODESIZ);
		*emuid = 0;
		err = -1; /* node not created? */
	}
	free(rep);
	return(err);
}


/*
 * Netgraph connect message
 */
int
send_ng_connect(s, path, peerpath, hook, peerhook)
int s;
char *path;
char *peerpath;
char *hook;
char *peerhook;
{
	struct ngm_connect arg;
	int err;
	int arglen = sizeof(arg);

	/* build/send a mkpeer message */
	bzero(&arg, arglen);
	snprintf(arg.path, NG_TYPESIZ, peerpath);
	snprintf(arg.ourhook, NG_HOOKSIZ, hook);
	snprintf(arg.peerhook, NG_HOOKSIZ, peerhook);

	err = NgSendMsg(s, path, NGM_GENERIC_COOKIE, NGM_CONNECT, &arg, arglen);
	return(err);
}


/*
 * Send a netgraph set/unset message to a ng_wlan node given link parameters.
 */
int send_wlan_mer(int s, uint32_t net, uint16_t mer, uint16_t mburst)
{
	char path[NG_PATHLEN+1];
	int err;
	struct {
		uint16_t mer;
		uint16_t mburst;
	} arg_mer;
	
	sprintf(path, "[0x%x]:", net);
	arg_mer.mer = mer;
	arg_mer.mburst = mburst;

	err = NgSendMsg(s, path, NGM_WLAN_COOKIE, NGM_WLAN_MER,
			(void *)&arg_mer, sizeof(arg_mer));
	return(err);	
}



/*
 * Debug
 */
void 
wlan_debug_print_ngcontrol(buf, path, len)
char *buf;
char *path;
int len;
{
	struct ng_mesg *ngm = (struct ng_mesg*)buf;
	wl_log("(%s=%d)", path, len);
	wl_log("ver=%d, spare=%d arglen=%d flags=0x%x token=0x%x "
		"typecookie=0x%x cmd=0x%x cmdstr=%s\n",
		ngm->header.version,
		ngm->header.spare,
		ngm->header.arglen,
		ngm->header.flags,
		ngm->header.token,
		ngm->header.typecookie,
		ngm->header.cmd,
		ngm->header.cmdstr	);
	wlan_hexdump(buf, len);
}

