/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * coreconn.h
 *
 * Data types and function prototypes for managing CORE connections.
 */

#ifndef _CORE_CONN_H_
#define _CORE_CONN_H_

/*
 * Data types.
 */
struct core_conn
{
	int sock;
	int type;
	uint8_t *recv_buff;
	int recv_buff_len;
	int recv_len;
	uint8_t subscriptions[9]; /* <= CORE_API_MSG_MAX */
	char name[255];
	struct core_conn *next;
};

#define CORE_CONNTYPE_TCP_INCOMING	1 /* TCP listening socket */
#define CORE_CONNTYPE_TCP		2 /* established or outgoing TCP */
#define CORE_CONNTYPE_UDP_INCOMING	3 /* UDP listening socket */
#define CORE_CONNTYPE_UDP		4 /* outgoing UDP connections */
#define CORE_CONNTYPE_CONTROL		5 /* Control messages */
#define CORE_CONNTYPE_FIFO		6 /* FIFO named pipe */

extern struct core_conn *conns;

/*
 * Function prototypes.
 */
struct core_conn *add_core_conn(int, int);
uint8_t *get_core_conn_recv_buff(struct core_conn *, int);
void core_conn_reset_recv_buff(struct core_conn*, uint8_t*);
int free_core_conn(struct core_conn *);
void free_core_conns(void);
struct core_conn *find_core_conn(int, int);

#endif /* _CORE_CONN_H_ */
