/* 
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE node/link DB definitions.
 */
#ifndef CORE_DB_H
#define CORE_DB_H

#define MIN_BUCKETS 512
#define CORE_NODE_HASH(a)  (a % MIN_BUCKETS)
#define CORE_LINK_HASH(a, b)  ((a | (b << 16)) % MIN_BUCKETS)
#define CORE_LINK_FLAGS_LINKED		0x1
#define CORE_LINK_FLAGS_UNLINKED	0x2

struct core_node_data {
	uint32_t type;
	uint8_t name[255];
	int num_addrs;
	struct sockaddr_storage *addrs;
	uint16_t model;
	uint16_t x;
	uint16_t y;
	uint16_t canvas;
	uint32_t emuid;		/* netgraph ID of node (iface for routers) */
	uint32_t netid;		/* netgraph ID of connected wlan */
	uint32_t linkid;	/* netgraph ID of pipe node */
	/* TODO: support multiple interfaces and pipes */
/*	uint32_t _lat;
	uint32_t _long;
	uint32_t _alt;
	uint32_t heading;
	uint16_t ptype;
	uint8_t *pid; 
 */
};

struct core_node {
	uint32_t node_id;
	struct core_node_data node_data;
/*	struct core_link_list *links; */
	struct core_node *next;
};

/*
struct core_node_list {
	struct core_node *node;
	struct core_node_list *next;
}; */
struct link_ifparams {
	int num_addrs;
	struct sockaddr_storage *addrs;
	int ifnum;
};

struct core_link_data {
	struct link_params p;
	struct link_ifparams if1;
	struct link_ifparams if2;
	uint32_t emuid;
	uint32_t netid;
	uint32_t type;
};

struct core_link {
	uint32_t node1_id;
	uint32_t node2_id;
	struct core_link_data link_data;
	int flags;
	struct core_node *node1;
	struct core_node *node2;
	struct core_node *wlan;
	struct core_link *next;
};

/*
struct core_link_list {
	struct core_link *link;
	struct core_link_list *next;
};
*/

#define link_params_copy(d, s) \
	do {\
		(d)->delay =	(s)->delay; \
		(d)->bw =	(s)->bw; \
		(d)->per =	(s)->per; \
		(d)->dup =	(s)->dup; \
		(d)->jitter =	(s)->jitter; \
		(d)->mer =	(s)->mer; \
		(d)->burst =	(s)->burst; \
		(d)->mburst =	(s)->mburst; \
	} while(0)

#define core_link_data_copy(d, s) \
    do {\
	link_params_copy(&((d)->p), &((s)->p)); \
	(d)->netid = (s)->netid; \
	(d)->type = (s)->type; \
    } while (0)

void init_core_db();
struct core_node *add_core_node_db(uint32_t, struct core_node_data *);
int  remove_core_node_db(uint32_t);
struct core_node *find_core_node_db(uint32_t, struct core_node **);
struct core_node *find_core_node_db2(struct core_node_data *);
void flush_core_node_db();
int core_node_data_copy(struct core_node_data *, struct core_node_data *);
struct sockaddr *core_node_data_get_addr_ptr(struct core_node_data *, int);

struct core_link *add_core_link_db(uint32_t, uint32_t, struct core_link_data *);
int  core_link_ifparams_copy(struct link_ifparams *, struct link_ifparams *);
int  remove_core_link_db(uint32_t, uint32_t);
struct core_link *find_core_link_db(uint32_t, uint32_t, struct core_link **);
struct core_link *find_core_link_by_node(uint32_t, struct core_link *);
void flush_core_link_db();

struct sockaddr *core_link_param_get_addr_ptr(struct link_ifparams *, int);
int debug_core_db();
int debug_core_node_db();
int debug_core_link_db();

/* from coreconn.c */
int generate_config(struct core_node*, char *);
int run_local_command_fmt(struct core_node*, char *, ...);
int run_node_command_fmt(struct core_node*, char *, ...);
int run_node_command(struct core_node*, char *, uint8_t);
int send_span_command(int, char *, int);
#endif /* CORE_DB_H */
