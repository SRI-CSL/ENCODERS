/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE node DB.
 */

#include <stdlib.h> /* malloc */
#include <stdio.h>  /* sprintf */
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> /* for cored.h */
#include <inttypes.h>

#include "cored.h"
#include "core_db.h"

static struct core_node *core_nodes_db[MIN_BUCKETS];
static struct core_link *core_links_db[MIN_BUCKETS];

void
init_core_db()
{
	bzero(core_nodes_db, sizeof(core_nodes_db));
	bzero(core_links_db, sizeof(core_links_db));
}

struct
core_node *add_core_node_db(uint32_t node_id, 
	struct core_node_data *node_data)
{
	struct core_node *node, *prev=NULL;
	int bucket;

	node = find_core_node_db(node_id, &prev);

	if (!node) { /* not found - create new */
		node = (struct core_node *) malloc(sizeof(struct core_node));
		if (!node) return(NULL); /* ENOMEM */
		bzero(node, sizeof(struct core_node));
		node->node_id = node_id;

		/* link into bucket */
		if (prev) {
			prev->next = node;
		} else {
			bucket = CORE_NODE_HASH(node_id);
			core_nodes_db[bucket] = node;
		}
	}

	/* this updates the node data for new and existing node entries */
	if (node_data) {
		/* XXX TODO: don't obilterate old values */
		if (core_node_data_copy(&node->node_data, node_data) < 0)
			return(NULL);
	}

	return(node);
}

int
remove_core_node_db(uint32_t node_id)
{
	struct core_node *node, *prev;
	int bucket;

	node = find_core_node_db(node_id, &prev);
	if (!node)
		return(-1); /* node not found */


	/* TODO: remove any refs to node in the links */

	if (prev) {
		prev->next = node->next;
	} else {
		bucket = CORE_NODE_HASH(node_id);
		core_nodes_db[bucket] = node->next;
	}

	/* TODO: free any node->data */
	if (node->node_data.addrs)
		free(node->node_data.addrs);
	bzero(node, sizeof(struct core_node));
	free(node);
	return(0); /* no error */
}

struct core_node *
find_core_node_db(uint32_t node_id, struct core_node **prev)
{
	struct core_node *node;
	int bucket = CORE_NODE_HASH(node_id);

	if (prev)
		*prev = NULL;
	for (node = core_nodes_db[bucket]; node; node = node->next) {
		if (node_id == node->node_id)
			break; /* found */
		if (prev)
			*prev = node;
	}
	return (node);
}

/*
 * find the first node that matches criteria from node data
 * note: expensive b/c it doesn't use the hash function!
 */
struct core_node *
find_core_node_db2(struct core_node_data *data)
{
	struct core_node *node;
	int b;
	for (b=0; b<MIN_BUCKETS; b++) {
		for (node = core_nodes_db[b]; node; node = node->next) {
			if (data->type && node->node_data.type == data->type)
				return(node);
			/* implement other matches here as needed, such as
			 * data->name
			 */
		}
	}
	return(NULL);
}

void
flush_core_node_db()
{
	struct core_node *node, *next;
	int b;

	for (b=0; b<MIN_BUCKETS; b++) {
		node = core_nodes_db[b];
		while (node) { /* free the linked list */
			next = node->next;
			/* TODO: free node->data */
			if (node->node_data.addrs)
				free(node->node_data.addrs);
			bzero(node, sizeof(struct core_node));
			free(node);
			node = next;
		}
		core_nodes_db[b] = NULL;
	}
}


int
core_node_data_copy(struct core_node_data *dst, struct core_node_data *src)
{
	int addrs_len;

	if (!dst || !src)
		return(-1); /* EINVAL */
	dst->type =	src->type;
	dst->model =	src->model;
	strncpy((char *)dst->name, (char *)src->name, sizeof(dst->name));
	dst->num_addrs = src->num_addrs;
	if (src->num_addrs > 0) { /* special handling for addrs list */
		if (dst->addrs)
			free(dst->addrs);
		addrs_len = src->num_addrs * sizeof(struct sockaddr_storage);
		dst->addrs = malloc(addrs_len);
		if (!dst->addrs)
			return(-1); /* ENOMEM */
		memcpy(dst->addrs, src->addrs, addrs_len);
	}
	dst->x =	src->x;
	dst->y =	src->y;
	dst->canvas =	src->canvas;
	dst->emuid = 	src->emuid;
	dst->netid =	src->netid;
	dst->linkid =	src->linkid;
	return(0); /* OK */
}

struct sockaddr *
core_node_data_get_addr_ptr(struct core_node_data *data, int family)
{
	int i;
	struct sockaddr *addr;

	if (!data) return NULL;
	for (i = 0; i < data->num_addrs; i++) {
		addr = (struct sockaddr *)&data->addrs[i];
		if (addr->sa_family == family) {
			return(addr);
		}
	}
	return(NULL);
}

struct
core_link *add_core_link_db(uint32_t node1_id, uint32_t node2_id,
	struct core_link_data *link_data)
{
	struct core_link *link, *prev=NULL;
	int bucket;

	link = find_core_link_db(node1_id, node2_id, &prev);

	if (!link) { /* not found - create new */
		link = (struct core_link *) malloc(sizeof(struct core_link));
		if (!link) return(NULL); /* ENOMEM */
		bzero(link, sizeof(struct core_link));
		link->node1_id = node1_id;
		link->node2_id = node2_id;

		/* link into bucket */
		if (prev) {
			prev->next = link;
		} else {
			bucket = CORE_LINK_HASH(node1_id, node2_id);
			core_links_db[bucket] = link;
		}
	}

	/* this updates the link data for new and existing link entries */
	if (link_data) {
		core_link_data_copy(&link->link_data, link_data);
		core_link_ifparams_copy(&link->link_data.if1, &link_data->if1);
		core_link_ifparams_copy(&link->link_data.if2, &link_data->if2);
	}

	return(link);
}

int
core_link_ifparams_copy(struct link_ifparams *dst, struct link_ifparams *src)
{
	int addrs_len;

	if (!dst || !src)
		return(-1); /* EINVAL */
	dst->ifnum =	src->ifnum;
	dst->num_addrs = src->num_addrs;
	if (src->num_addrs > 0) { /* special handling for addrs list */
		if (dst->addrs)
			free(dst->addrs);
		addrs_len = src->num_addrs * sizeof(struct sockaddr_storage);
		dst->addrs = malloc(addrs_len);
		if (!dst->addrs)
			return(-1); /* ENOMEM */
		memcpy(dst->addrs, src->addrs, addrs_len);
	}
	return(0); /* OK */
}

int
remove_core_link_db(uint32_t node1_id, uint32_t node2_id)
{
	struct core_link *link, *prev;
	int bucket;

	link = find_core_link_db(node1_id, node2_id, &prev);
	if (!link)
		return(-1); /* link not found */

	/* TODO: remove any refs to nodes in the links */
	if (prev) {
		prev->next = link->next;
	} else {
		bucket = CORE_LINK_HASH(node1_id, node2_id);
		core_links_db[bucket] = link->next;
	}

	/* TODO: free any link->data */
	bzero(link, sizeof(struct core_link));
	free(link);
	return(0); /* no error */
}

struct core_link *
find_core_link_db(uint32_t node1_id, uint32_t node2_id, struct core_link **prev)
{
	struct core_link *link;
	int bucket = CORE_LINK_HASH(node1_id, node2_id);

	if (prev)
		*prev = NULL;
	for (link = core_links_db[bucket]; link; link = link->next) {
		if (node1_id == link->node1_id &&
		    node2_id == link->node2_id)
			break; /* found */
		if (prev)
			*prev = link;
	}
	return (link);
}

/* find a link if either node1 or node2 have a matching node_id
 * start is optional, to speed up search with a starting point */
struct core_link *
find_core_link_by_node(uint32_t node_id, struct core_link *start)
{
	struct core_link *link;
	int b;

	if (start) { /* starting bucket determined by start */
		b = CORE_LINK_HASH(start->node1_id, start->node2_id);
		start = start->next;
	} else {
		b = 0;
		start = core_links_db[b];
	}

	for (; b<MIN_BUCKETS; b++) {
		for (link = start; link; link = link->next) {
			if (link->node1_id == node_id || 
			    link->node2_id == node_id)
				return(link);
		}
		start = core_links_db[b+1];
	}

	return (NULL);
}


void 
flush_core_link_db()
{
	struct core_link *link, *next;
	int b;

	for (b=0; b<MIN_BUCKETS; b++) {
		link = core_links_db[b];
		while (link) { /* free the linked list */
			next = link->next;
			bzero(link, sizeof(struct core_link));
			free(link);
			link = next;
		}
		core_links_db[b] = NULL;
	}
}

struct sockaddr *
core_link_param_get_addr_ptr(struct link_ifparams *data, int family)
{
	int i;
	struct sockaddr *addr;

	if (!data) return NULL;
	for (i = 0; i < data->num_addrs; i++) {
		addr = (struct sockaddr *)&data->addrs[i];
		if (addr->sa_family == family) {
			return(addr);
		}
	}
	return(NULL);
}

int debug_core_db()
{
	int err;
	err = debug_core_node_db();
	err += debug_core_link_db();
	return(err);
}

int debug_core_node_db() 
{
	struct core_node *node;
	struct core_node_data *d;
	int b;

	wl_log("NODES:\n");
	for (b=0; b<MIN_BUCKETS; b++) {
		for (node = core_nodes_db[b]; node; node = node->next) {
			d = &node->node_data;
			wl_log("N(%u,type=%u,name=%s,naddrs=%d,model=%u,"
			       "xy=%u,%u,c=%u,e=%u,n=%u,l=%u)\n",
			       node->node_id, d->type, d->name, d->num_addrs,
			       d->model, d->x, d->y, d->canvas, d->emuid,
			       d->netid, d->linkid);
		}
	}
	wl_log("\n");
	return(0);
}

int debug_core_link_db()
{
	struct core_link *link;
	struct core_link_data *ld;
	struct link_params *p;
	struct link_ifparams *ifp;
	int b;

	wl_log("LINKS:\n");
	for (b=0; b<MIN_BUCKETS; b++) {
		for (link = core_links_db[b]; link; link = link->next) {
			ld = &link->link_data;
			p = &ld->p;
			wl_log("L(%u-%u,e=%u,n=%u,t=%u,p(d=%lu,bw=%lu,pe=%u,"
			       "dup=%u,j=%u,me=%u,brst=%u,mbrst=%u)\n",
			       link->node1_id, link->node2_id, ld->emuid,
			       ld->netid, ld->type, p->delay, p->bw, p->per,
			       p->dup, p->jitter, p->mer, p->burst, p->mburst);
			ifp = &ld->if1;
			wl_log("if1=%d,naddrs=%d,", ifp->ifnum, ifp->num_addrs);
			ifp = &ld->if2;
			wl_log("if2=%d,naddrs=%d)", ifp->ifnum, ifp->num_addrs);
		}
	}
	wl_log("\n");
	return(0);
}

