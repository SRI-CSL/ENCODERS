/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * cored.h
 * 
 * Definitions for the CORE daemon.
 */
#ifndef _CORED_H_
#define _CORED_H_

#define CORED_VER 1.6

#define closesocket close
#define CORED_DEFAULT_LOG	"/var/log/cored.log"
#define CORED_DEFAULT_PID	"/var/run/cored.pid"
#define CORE_CONF_DIR		"/etc/core"
#define CORE_CONTROL_RETRY	5

struct sockaddr;

/* useful sockaddr macros */
#define SA(x) (struct sockaddr *)(x)
#define SA2IP(x) (((struct sockaddr*)x)->sa_family==AF_INET) ? \
        (void*)&((struct sockaddr_in*)x)->sin_addr : \
        (void*)&((struct sockaddr_in6*)x)->sin6_addr
#define SALEN(x) (((struct sockaddr*)x)->sa_family==AF_INET) ? \
        sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6)
#define SAIPLEN(x) (((struct sockaddr*)x)->sa_family==AF_INET) ? 4 : 16
#define NIPQUAD(addr) 	((unsigned char*)&addr)[0] & 0xFF, \
			((unsigned char*)&addr)[1] & 0xFF, \
			((unsigned char*)&addr)[2] & 0xFF, \
			((unsigned char*)&addr)[3] & 0xFF

#define MAC2STR(addr)  	((unsigned char*)&addr)[5] & 0xFF, \
			((unsigned char*)&addr)[4] & 0xFF, \
			((unsigned char*)&addr)[3] & 0xFF, \
			((unsigned char*)&addr)[2] & 0xFF, \
			((unsigned char*)&addr)[1] & 0xFF, \
			((unsigned char*)&addr)[0] & 0xFF


/*
 * Data types
 */
struct link_params { /* may want to include ng_wlan/ng_wlan_tag.h instead */
	uint64_t delay;
	uint64_t bw;
	uint16_t per;
	uint16_t dup;
	uint32_t jitter;
	uint16_t mer;
	uint16_t burst;
	uint16_t mburst;
};

extern int verbose_debug;

/*
 * Function declarations
 */
int  str_to_addr(char *data, struct sockaddr *addr);
int  addr_to_str(struct sockaddr *addr, char *data, int len);
void wl_log(char *, ...);
int link_nodes(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t,
	struct link_params *);
int unlink_nodes(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);

void register_wlan_handler(uint32_t, char *);
int  send_register_caps(int);
void flush_all_models();
void wlan_hexdump(char *, int);

int send_node_message(char *, uint16_t, uint32_t, uint32_t, uint32_t, uint16_t,
	uint16_t);
#ifdef VERBOSE_DEBUG
#define wl_log_v wl_log
#else
void wl_log_v(char *, ...);
#endif

#ifndef bzero
#define bzero(s, n) memset(s, 0, n)
#endif

#endif /* _CORED_H_ */
