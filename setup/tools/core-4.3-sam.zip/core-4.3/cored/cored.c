/*
 * CORE daemon
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE daemon emulation and WLAN services.
 *
 */

#include <config.h>		/* autoconf defines */
#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#include <signal.h>		/* signal() */
#include <sys/types.h>		/* select() */
#include <sys/stat.h>		/* umask() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select() */
#include <time.h>		/* ctime() */
#include <stdarg.h>		/* va_start() */

#include <coreapi/coreapi.h>
#include "cored.h"
#include "coreconn.h"
#include "core_db.h"
#include "core_emu.h"
#include "models/model.h"
#include "models/model_list.h"

#ifdef FREEBSD
#include <kernel/ng_wlan/ng_wlan.h>
#include "bsd/core_bsd_emu.h"
#include "bsd/core_netgraph.h"
#else
#include "linux/core_openvz_emu.h"
/*#include <linux/in6.h>*/		/* struct in6_addr */
#endif /* FREEBSD */

/*
 * Function prototypes.
 */
void print_banner(void);
void print_usage(void);
int  select_loop(void);
int  receive_control(int);
int  receive_core(struct core_conn *);
int  forward_core(struct core_conn *, int, uint8_t *, int);
int  receive_node_msg(int, uint8_t *, uint16_t);
int  receive_link_msg(int, uint8_t *, uint16_t);
int  receive_exec_msg(int, uint8_t *, uint16_t);
int  receive_reg_msg(struct core_conn *, uint8_t *, uint16_t);
int  receive_conf_msg(int, uint8_t *, uint16_t);
int  receive_file_msg(int, uint8_t *, uint16_t);
int  receive_iface_msg(int, uint8_t *, uint16_t);
int  receive_event_msg(int, uint8_t *, uint16_t);
int  socket_bind(int, struct sockaddr *, char *);
int  socket_connect(int, struct sockaddr *, int);
int  send_link_message(uint32_t, uint32_t, uint32_t, int, struct link_params *);
int  connect_emulation_handler(struct timeval *now);
int  wl_open_log(char *, int);
void wl_close_log();
int  wl_write_pid(char *, pid_t);
void wlan_signal_ignore(int);
void wlan_signal_debug(int);
void wlan_terminate(int);
#ifdef WIN32
void wl_WinError(int code);
#endif

/*
 * Globals.
 */
int control_sock=0;			/* control socket */
struct core_conn *conns=NULL;		/* linked-list of connections */
struct core_wlan_model *g_models;	/* linked-list of models */
struct core_emu *g_emu;			/* emulation support functions */
int verbose_debug = 0;			/* verbose debugging */


/*
 * Main routine.
 */
int 
main(argc, argv)
int argc;
char **argv;
{
	char log_filename[255], ipstr[INET6_ADDRSTRLEN];
	pid_t pid;
	struct core_wlan_model *m;

	/*
	 * Initializations
	 */
	int do_daemon = 0, do_log = 0, api_connect = 0, log_opts; /* options */
	struct sockaddr_in connect_addr, bind_addr = {};
	int core_sock;
	bzero(&connect_addr, sizeof(connect_addr));
	signal(SIGINT, wlan_terminate);
	signal(SIGTERM, wlan_terminate);
	signal(SIGPIPE, wlan_signal_ignore);
#ifndef WLAN_DEBUG
	signal(SIGSEGV, wlan_terminate);
#endif
	signal(SIGHUP, wlan_signal_debug);
	sprintf(log_filename, "%s", CORED_DEFAULT_LOG);
	log_opts = 0;
	control_sock = core_sock = 0;

	/*
	 * Parse command-line arguments.
	 */
	argv++, argc--;
	while (argc > 0) {
		if (strcmp(*argv, "-d") == 0) {
			do_daemon = 1;
			do_log = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-c") == 0) {
			api_connect |= 0x01;
			argv++, argc--;
			if (argc==0 || !argv) {
				wl_log("Error: please specify connect"
					" address.\n");
				print_usage();
				exit(1);
			}
			connect_addr.sin_family = AF_INET;
			if (str_to_addr(*argv, SA(&connect_addr)) != 1) {
				wl_log("Error: Invalid connect address.\n");
				exit(1);
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-s") == 0) {
			api_connect |= 0x10;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-l") == 0) {
			argv++, argc--;
			do_log = 1;
			if (argc==0 || !argv) {
				wl_log("Error: please specify log file.\n");
				print_usage();
				exit(1);
			} else {
				strncpy(log_filename, *argv, 255);
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-k") == 0) {
			wl_log("Preserving the log file.\n");
			log_opts = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-v") == 0) {
			verbose_debug = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-h") == 0) {
			print_usage();
			exit(0);
		}

		/* unknown arguments */
		print_usage();
		exit(1);
	}

	/*
         * Run as daemon.
         */	
	if (do_daemon) {
		/* check for PID file */
		if (wl_write_pid(CORED_DEFAULT_PID, 0) < 0)
			exit(1);
		if ((pid = fork()) < 0) {
			wl_log("fork() error: %s\n", strerror(errno));
			exit(1);
		} else if (pid > 0) {
			/* parent process exits here, writing PID to pid file */
			exit(wl_write_pid(CORED_DEFAULT_PID, pid));
		}
		umask(0); /* change file mode mask */
		if (setsid() < 0) /* obtain a new process group */
			exit(1);
		if (chdir("/") < 0)
			exit(1);
	}
	if (do_log) { /* replace stdout/stderr/stdin */
		if (wl_open_log(log_filename, log_opts) < 0) {
			fprintf(stderr,
				"Error opening log file '%s' - %s, quitting.\n",
				log_filename, strerror(errno));
			exit(1);
		}
	}

	print_banner();
	if (verbose_debug)
		wl_log("Verbose debugging enabled.\n");
	/* Load and initialize WLAN models here */
	/* TODO: insert magic model loading here */
#ifdef GPS_MODEL
	add_model(m, g_models, &gps_model);
#endif
#ifdef SIMPLE_MODEL
	add_model(m, g_models, &simple_model);
#endif
#ifdef SCRIPTED_MODEL
	add_model(m, g_models, &scripted_model);
#endif
#ifdef RANDWAYP_MODEL
	add_model(m, g_models, &randwayp_model);
#endif

	for_each_model(m, g_models) {
		if (!m->link) m->link = link_nodes;
		if (!m->unlink) m->unlink = unlink_nodes;
		if (m->init) m->init();
	}

	g_emu = NULL;
#ifdef FREEBSD
	/*
	 * Open a control socket for local messages.
	 */
	if ((control_sock = open_netgraph_control("wlan_ctl")) < 0) {
		wl_log("NgMkSockNode() error (%d): %s\n",
			errno, strerror(errno));
		if (errno == EPERM)
			wl_log(">> This program must be run as root, in order "
				"to open Netgraph sockets. <<\n");
		else if (errno == EADDRINUSE)
			wl_log(">> Please check that cored is not already "
				"running. <<\n");
		exit(1);
	}
	add_core_conn(control_sock, CORE_CONNTYPE_CONTROL);

	/*
	 * Populate emulation functions
	 */
#if 0
	if (init_bsd_emulation() < 0)
		wl_log("Vimage/Netgraph emulation not enabled.\n");
#endif
#else /* FREEBSD */
	/*
	 * Linux support
	 */
	control_sock = 0;
	if (init_openvz_emulation() < 0)
		wl_log("OpenVZ emulation not enabled.\n");
#endif /* FREEBSD */
	if (api_connect==0) api_connect = 0x10; /* auto-start server */

	/*
	 * Command-line options -c/-s
         * Make a connection or listen to CORE_API_PORT.
	 */
	if (api_connect & 0x01) { /* connect to API server */
		connect_addr.sin_family = AF_INET;
		if (connect_addr.sin_port == 0)
			connect_addr.sin_port = htons(CORE_API_PORT);
		addr_to_str(SA(&connect_addr), ipstr, sizeof(ipstr));
		wl_log("Connecting to %s:%u.\n",
			ipstr, ntohs(connect_addr.sin_port));
		core_sock = socket_connect(IPPROTO_TCP, SA(&connect_addr), 0);
		if (core_sock < 0) {
			wl_log("Error connecting CORE API socket: %s\n", 
				strerror(errno));
		} else {
			add_core_conn(core_sock, CORE_CONNTYPE_TCP);
		}
	}
	if (api_connect & 0x10) { /* listen as API server */
		bind_addr.sin_family = AF_INET;
		bind_addr.sin_port = htons(CORE_API_PORT);
		core_sock = -1;
		while (core_sock < 0) {
			core_sock = socket_bind(IPPROTO_TCP, SA(&bind_addr),
						"core_wlan");
			if ((core_sock < 0) && (errno == EADDRINUSE)) {
				wl_log("Server address is in use, will try "
				       " again after 3 seconds.\n");
				sleep(3);
			} else if (core_sock < 0) {
				wl_log("Error opening CORE API socket: %s\n", 
					strerror(errno));
				wlan_terminate(0);
			}
		}
		add_core_conn(core_sock, CORE_CONNTYPE_TCP_INCOMING);
		wl_log("Listening for CORE API messages on port %d.\n", 
		       CORE_API_PORT);
	}

	select_loop();
	return (0);
}

/*
 * Print or log a title message.
 */
void
print_banner()
{
	struct timeval t;
	gettimeofday(&t, NULL);
	wl_log("CORE daemon v.%.1f - %s", CORED_VER, ctime(&t.tv_sec));
}

/*
 * Prints command-line options.
 */
void
print_usage()
{
	print_banner();
	printf("CORE daemon for emulation and wireless support.");
	printf("\n");
	printf("usage: cored [-d] [-c <remote-ip>] -l <log-file>]\n");
	printf("\t-d\t\tdaemonize:\trun in the background and output to\n");
	printf("\t\t\t\t\tlog file\n");
	printf("\t-c <remote-ip>\tconnect API control socket to <remote-ip> ");
	printf("port %d\n", CORE_API_PORT);
	printf("\t-s\t\tstart API server for accepting connections to port ");
	printf("%d\n", CORE_API_PORT);
	printf("\t-l <log-file>\tlog output to specified file\n");
	printf("\t-k keep the log file, don't truncate if it exists\n");
	printf("\t-v enable verbose debugging\n");
	printf("\n");
}

/*
 * This is where the program spends all of its time.
 */
int
select_loop()
{
	int max, err, do_flush;
	fd_set read_fdset;
	struct timeval to, now, control_retry = {0, 0};
	struct core_wlan_model *m;
	struct core_conn *conn;

	/*
	 * Loop forever. A separate signal handler will 
         * catch CTRL+C or KILL signals.
	 */
	for (;;) {
		do_flush = 1; /* flush models if connection is closed */
		/* Set up for select() call */
		max = 0;
		FD_ZERO(&read_fdset);
		for (conn = conns; conn; conn = conn->next) {
			if (conn->type == CORE_CONNTYPE_TCP_INCOMING)
				do_flush = 0; /* server: flag prevent flush */
			if (conn->sock == 0)
				continue;
			FD_SET((unsigned int)conn->sock, &read_fdset);
			if (conn->sock > max)
				max = conn->sock;
		}
		/* This timeout affects the rate that periodic functions
		 * are called.
		 */
		to.tv_sec = 0;
		to.tv_usec = 334000; /* 334,000us = 334ms = .3s */

		/* Perform select() and dispatch to separate receive functions
		 * if there is any data. 
                 */
		if ((err = select(max+1, &read_fdset, NULL,NULL, &to)) < 0) {
#ifdef WIN32
			if (err != SOCKET_ERROR)
				continue;
			wl_WinError(GetLastError());
#endif
			wl_log("select() error(%d): %s\n", 
				errno, strerror(errno));
			if (errno != EINTR)
				return(-errno);
		} else if (err == 0) {
			/* timeout */
			gettimeofday(&now, NULL);
			if ((!g_emu) &&
			    (now.tv_sec > control_retry.tv_sec))
				control_retry.tv_sec = now.tv_sec +
						connect_emulation_handler(&now);
			for_each_model(m, g_models) {
				if (m->model_state < MODEL_STATE_ENABLED)
					continue;
				if (m->periodic) m->periodic(&now);
				if (m->debug) m->debug(1);
			}
		} else  {
			/* First, handle control socket data */
			if ((control_sock > 0) &&
			    FD_ISSET(control_sock, &read_fdset)) {
				err = receive_control(control_sock);
				if (err < 0) {
					wl_log("Control socket closed!\n");
					close(control_sock);
					control_sock = 0;
				}
				continue;
			}
			/* Check for data on all our sockets. */
			for (conn = conns; conn; conn = conn->next) {
				if (conn->sock == 0)
					continue;
				if (!FD_ISSET(conn->sock, &read_fdset))
					continue;
				if (receive_core(conn) < 0) {
					if (g_emu &&
					    strncmp(g_emu->name, conn->name,
						    sizeof(conn->name))==0) {
						wl_log("Connection with emulati"
						    "on handler was closed.\n");
						free(g_emu);
						g_emu = NULL;
					}
					free_core_conn(conn);
					if (do_flush) {
					wl_log("CORE API socket closed, flush"
						"ing all node data.\n");
					flush_all_models();
					}
					break; /* exit loop: conn now invalid!*/
				}
			} /* end for each conn */

		/* end if select() */
		}
	/* end for (;;) */
	}

	return(0);
}


/* 
 * Perform socket(), bind(), and listen() calls in one function.
 */
#define MAX_INCOMING 200
int
socket_bind(protocol, addr, msg)
int protocol;
struct sockaddr *addr;
char *msg;
{
	int s, addrlen, err, opt;
	int type = (protocol == IPPROTO_TCP) ? SOCK_STREAM : SOCK_DGRAM;

	/* open socket */
	if ((s = socket(addr->sa_family, type, protocol)) < 0) {
		wl_log("%s socket() error %d: %s\n", 
			msg, errno, strerror(errno));
		return(-1);
	}

	opt = 1;
	if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
		wl_log("%s setsockopt() SO_REUSEADDR error %d: %s\n",
			msg, errno, strerror(errno));
		/* non-fatal error */
	}

	/* bind socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	if ((err = bind(s, addr, addrlen)) < 0) {
		wl_log("%s bind() error %d: %s\n", msg, errno, strerror(errno));
		closesocket(s);
		return(-1);
	}
	
	/* put socket into listening state if TCP */
	if (type == SOCK_STREAM) {
		if ((err = listen(s, MAX_INCOMING)) < 0) {
			wl_log("%s listen() error %d: %s\n ", 
				msg, errno, strerror(errno));
			closesocket(s);
			return(-1);
		}
	}

	return(s);
}


/* 
 * Perform socket() and connect() calls in one function.
 */
int
socket_connect(protocol, addr, flags)
int protocol;
struct sockaddr *addr;
int flags;
{
	int s, addrlen;
	char name[255];

	sprintf(name, "%u.%u.%u.%u:%u", 
		NIPQUAD(((struct sockaddr_in*)addr)->sin_addr.s_addr),
		ntohs(((struct sockaddr_in*)addr)->sin_port));

	/* wl_log("Connecting to %s using %s...\n", name,
		(protocol == IPPROTO_TCP) ? "TCP" : "UDP"); */

	/* open socket */	
	if ((s = socket(addr->sa_family, (protocol == IPPROTO_TCP) ? 
			SOCK_STREAM : SOCK_DGRAM, protocol)) < 0) {
		wl_log("socket() error %d: %s\n", errno, strerror(errno));
		return(-1);
	}

	/* connect socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	/* else IPv6 set sin6_port */
	if (connect(s, addr, addrlen) < 0) {
		/* wl_log("connect() error %d: %s\n", errno, strerror(errno));*/
		closesocket(s);
		return(-1);
	}

	return(s);
}


/*
 * Handle control socket activity
 */
int
receive_control(int s)
{
#ifdef FREEBSD
	return receive_netgraph_control(s);
#endif
	return 0;
}


/*
 * Handle CORE API socket activity
 */
int
receive_core(conn)
struct core_conn *conn;
{
	int len, buff_len_remain, flags, type, err=0;
	socklen_t addr_len;
	uint8_t *bufp;
	struct sockaddr_in addr;
	uint16_t msg_len;
	int s;

	/* wl_log("receive_core(type=%d sock=%d)\n",
		conn->type, conn->sock); // */

	if (!conn)
		return(-1);
	if (conn->type == CORE_CONNTYPE_TCP_INCOMING) {
		/*
		 * accept new TCP connections and continue
		 */
		addr_len = sizeof(addr);
		s = accept(conn->sock, SA(&addr), &addr_len);
		if (s < 0) {
			wl_log("accept() error: %s\n", strerror(errno));
			return(-1);
		}
		add_core_conn(s, CORE_CONNTYPE_TCP);
		return(0);
	} else {
		s = conn->sock;
	}

	/* Allocate a new receive buffer or continue with existing buffer */
	bufp = get_core_conn_recv_buff(conn, 4096);
	if (!bufp) return(-1);
	buff_len_remain = conn->recv_buff_len - conn->recv_len;
	/* NOTE: we could use flags=MSG_PEEK to look at the message header
	 *       and determine the message size here, but then we are limited 
	 *	 to receiving one message at a time (and lots of mallocs).
	 */

	flags = 0;
	addr_len = sizeof(addr);
	len = recvfrom(s, (char *)bufp, buff_len_remain, flags,
		       SA(&addr), &addr_len);
	if (len < 0) {
		wl_log("recvfrom() error(%d): %s\n", errno, strerror(errno));
		return(-1);
	} else if (len == 0) { /* socket closed */
		/* wl_log("recvfrom() socket closed\n"); // */
		return(-1);
	}
	/* wl_log("receive_core(): socket %d, %d bytes\n", s, len); // */

	conn->recv_len += len;
	bufp = &conn->recv_buff[0]; /* look at start of receive buffer */
	while (conn->recv_len > 0) {
		/* parse CORE API message header */
		err = 0;
		msg_len = conn->recv_len;
		type = core_api_parse_message(bufp, &msg_len);
		if (type == -3) {
			/* Don't free the receive buffer, but allow more data
			 * to accumulate next time. */
			wl_log("receive_core(): truncated message at %d bytes, "
			       "waiting for more data\n", conn->recv_len);
			/* If we are in the middle of the buffer, move data
			 * to the start in preparation for the next read. */
			core_conn_reset_recv_buff(conn, bufp);
			return(0);
		} else if (type < 0) {
			wl_log("receive_core(): bad message (%d) from %s, %d "
				"bytes discarded\n",
				type, conn->name, conn->recv_len);
			break;
		}
		/* wl_log("receive_core: handle message type %d\n", type); */
		/* handle certain CORE API messages */
		switch (type) {
		case CORE_API_NODE_MSG:
			err = receive_node_msg(s, bufp, msg_len);
			break;
		case CORE_API_LINK_MSG:
			err = receive_link_msg(s, bufp, msg_len);
			break;
		case CORE_API_EXEC_MSG:
			err = receive_exec_msg(s, bufp, msg_len);
			break;
		case CORE_API_REG_MSG:
			err = receive_reg_msg(conn, bufp, msg_len);
			break;
		case CORE_API_CONF_MSG:
			err = receive_conf_msg(s, bufp, msg_len);
			break;
		case CORE_API_FILE_MSG:
			err = receive_file_msg(s, bufp, msg_len);
			break;
		case CORE_API_IFACE_MSG:
			wl_log("TODO: interface message\n");
			break;
		case CORE_API_EVENT_MSG:
			err = receive_event_msg(s, bufp, msg_len);
			break;
		default:
			err = -1;
			wl_log("warning: CORE API message type %d is "
				"not handled.\n", type);
		}
		/* advance ptr */
		msg_len += sizeof(struct core_api_msg);
		if (err == 0) {
			/* forward the message to registered entities */
			if (forward_core(conn, type, bufp, (int)msg_len) < 0)
				wl_log("warning: problem forwarding message\n");
		}
		bufp += msg_len;
		conn->recv_len -= msg_len;
		if (conn->recv_len < 0) {
			err = 0; /* don't hangup connection */
			wl_log("receive_core(): overflow %d %d\n", 
				conn->recv_len, msg_len);
			break;
		} else if (err < 0) {
			err = 0; /* don't hangup connection */
			wl_log("receive_core(): message type %d error\n", type);
			break;
		}
	}

	/* Here we are done with the receive buffer, so free it.
	 */
	core_conn_reset_recv_buff(conn, NULL);
	return(err);
}

int
forward_core(struct core_conn *from, int type, uint8_t *buf, int len)
{
	struct core_conn *c;
	/* int num_fwd=0; */

	/* warning: from my be NULL */

	for (c = conns; c; c = c->next) {
		if (from == c) /* don't forward to self */
			continue;
		if (type > sizeof(c->subscriptions)) /* array safeguard */
			continue;
		if (c->subscriptions[type] == 0) /* not subscribed */
			continue;
		/* wl_log("forwarding message type %d len %d from %s to %s\n",
			type, len, from->name, c->name); //*/
		if (send(c->sock, buf, len, 0) < 0) {
			wl_log("forward_core(): error sending message to conn "
			       "sock=%d type=%d: \n", c->sock, c->type,
			       strerror(errno));
		}
		/* num_fwd++; */
	}
	/* wl_log("forwarded message type %d len %d to %d entities\n",
		type, len, num_fwd);
	*/

	return(0);
}

int
receive_node_msg(int core_sock, uint8_t *buf, uint16_t length)
{
	struct core_api_tlv *tlv;
	struct core_node_data data;
	uint32_t node_id;
	uint16_t flags;
	struct core_wlan_model *m;
	int emulated = 1;
	uint8_t name[255];
	struct sockaddr_storage addrs[3];
	int naddrs;

	memset(name, 0, sizeof(name));
	memset(addrs, 0, 3 * sizeof(struct sockaddr_storage));

	flags = (uint16_t) core_api_message_get_flags(buf);

	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_NUMBER);
	if (core_api_get_tlv_val32(tlv, &node_id) < 0)
		return(-1); /* node number is required */

	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_TYPE);
	core_api_get_tlv_val32(tlv, &data.type);

	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_NAME);
	core_api_get_tlv_string(tlv, data.name, sizeof(data.name));

	naddrs = 0;
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_NODE_IPADDR, 0,
					AF_INET, SA(&addrs[naddrs]));
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_NODE_MACADDR, 0,
					AF_LOCAL, SA(&addrs[naddrs]));
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_NODE_IPADDR, 0,
					AF_INET, SA(&addrs[naddrs]));

	data.num_addrs = naddrs;
	if (naddrs > 0)
		data.addrs = &addrs[0];

	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_MODEL);
	core_api_get_tlv_val16(tlv, &data.model);
	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_XPOS);
	core_api_get_tlv_val16(tlv, &data.x);
	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_YPOS);
	core_api_get_tlv_val16(tlv, &data.y);
	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_CANVAS);
	core_api_get_tlv_val16(tlv, &data.canvas);

	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_EMUID);
	if (core_api_get_tlv_val32(tlv, &data.emuid) < 0) {
		/* if the emulation ID is absent, then we assume the
		 * sender is not responsible for emulation */
		emulated = 0;
	}
	
	tlv = core_api_get_tlv(buf, CORE_TLV_NODE_NETID);
	core_api_get_tlv_val32(tlv, &data.netid); 
	
	/* wl_log("node: %x (%x)  %u, %u\n", node, netid, x, y); */
	/* we are responsible for emulation */
	if (!emulated && g_emu && g_emu->node) {
		g_emu->node(flags, node_id, &data);
	}
	/* call the update function for each enabled module */
	for_each_model(m, g_models) {
		if (m->model_state < MODEL_STATE_ENABLED)
			continue;
		if (m->update) 
			m->update(flags, data.netid, node_id, data.emuid,
					(uint32_t)data.x, (uint32_t)data.y);
	}
	
	return(0);
}

int
receive_link_msg(int core_sock, uint8_t *buf, uint16_t length)
{
	struct core_api_tlv *tlv;
	struct core_link_data data;
	uint32_t node1, node2;
	uint16_t flags, val16;
	int naddrs, naddrs1;
	struct sockaddr_storage addrs[6]; /* IPv4, MAC, IPv6 for both nodes */

	int emulated = 1;

	flags = (uint16_t) core_api_message_get_flags(buf);

	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_N1NUMBER);
	if (core_api_get_tlv_val32(tlv, &node1) < 0)
		return(-1); /* node1 number is required */
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_N2NUMBER);
	if (core_api_get_tlv_val32(tlv, &node2) < 0)
		return(-1); /* node2 number is required */

	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_DELAY);
	core_api_get_tlv_val64(tlv, &data.p.delay);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_BW);
	core_api_get_tlv_val64(tlv, &data.p.bw);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_PER);
	core_api_get_tlv_val16(tlv, &data.p.per);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_DUP);
	core_api_get_tlv_val16(tlv, &data.p.dup);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_JITTER);
	core_api_get_tlv_val32(tlv, &data.p.jitter);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_MER);
	core_api_get_tlv_val16(tlv, &data.p.mer);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_BURST);
	core_api_get_tlv_val16(tlv, &data.p.burst);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_MBURST);
	core_api_get_tlv_val16(tlv, &data.p.mburst);
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_TYPE);
	core_api_get_tlv_val32(tlv, &data.type);

	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_EMUID);
	if (core_api_get_tlv_val32(tlv, &data.emuid) < 0) {
		/* if the emulation ID is absent, then we assume the
		 * sender is not responsible for emulation */
		emulated = 0;
	}
	
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_NETID);
	core_api_get_tlv_val32(tlv, &data.netid);

	data.if1.ifnum = data.if2.ifnum = -1;
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_IF1NUM);
	if (tlv) {
		core_api_get_tlv_val16(tlv, &val16);
		data.if1.ifnum = (int) val16;
	}
	tlv = core_api_get_tlv(buf, CORE_TLV_LINK_IF2NUM);
	if (tlv) {
		core_api_get_tlv_val16(tlv, &val16);
		data.if2.ifnum = (int) val16;
	}
	naddrs = 0;	
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_LINK_IF1IP4,
			CORE_TLV_LINK_IF1IP4MASK, AF_INET,  SA(&addrs[naddrs]));
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_LINK_IF1MAC,
			0, AF_LOCAL, SA(&addrs[naddrs]));
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_LINK_IF1IP6,
			CORE_TLV_LINK_IF1IP6MASK, AF_INET6, SA(&addrs[naddrs]));

	data.if1.num_addrs = naddrs1 = naddrs;
	if (data.if1.num_addrs > 0)
		data.if1.addrs = &addrs[0];

	naddrs += core_api_get_tlv_address(buf, CORE_TLV_LINK_IF2IP4,
			CORE_TLV_LINK_IF2IP4MASK, AF_INET,  SA(&addrs[naddrs]));
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_LINK_IF2MAC,
			0, AF_LOCAL, SA(&addrs[naddrs]));
	naddrs += core_api_get_tlv_address(buf, CORE_TLV_LINK_IF2IP6,
			CORE_TLV_LINK_IF2IP6MASK, AF_INET6, SA(&addrs[naddrs]));

	data.if2.num_addrs = naddrs - naddrs1;
	if (data.if2.num_addrs > 0)
		data.if2.addrs = &addrs[naddrs1];

	/* wl_log("node: %x (%x)  %u, %u\n", node, netid, x, y); */
	/* we are responsible for emulation */
	if (!emulated && g_emu && g_emu->link) {
		g_emu->link(flags, node1, node2, &data);
	}

	/* TODO: add link function to models if needed.
	 * Currently, models receive node update messages only, and
	 * generate their own link messages for GUI updates, updating the
	 * netgraph emulation directly.
	 */
#if 0
	for_each_model(m, g_models) {
		if (m->model_state < MODEL_STATE_ENABLED)
			continue;
		if (m->update) 
			m->update(flags, netid, node, emuid,
					(uint32_t)x, (uint32_t)y);
	}
#endif
	return(0);
}


int
receive_exec_msg(int core_sock, uint8_t *buf, uint16_t length)
{
	int len, err;
	struct core_api_tlv *tlv;
	uint32_t node_id, exec_id, exec_time, exec_result;
	uint8_t flags, *resp;

	/* execution number required for both requests and results */
	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_NUM);
	if (core_api_get_tlv_val32(tlv, &exec_id) < 0)
		return(-1);

	/* 
	 * Check for execution result. If the status request flag is set
	 * then we forward the message to the emulation handler. The TLVs
	 * are converted to numbers and a response string is allocated
	 * for the function call.
	 */
	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_RESULT);
	flags = core_api_message_get_flags(buf);
	/* wl_log("Received Execute message %s (%u, flags=0x%x)\n",
		(tlv==NULL) ? "request" : "result", exec_id, flags ); // */
	if (tlv && (flags & CORE_API_TTY_FLAG)) {
		/* replies to interactive terminal requests 
		 * are sent to the GUI
		 * TODO: update cmd result with 'ssh user@host cmd' for nodes
		 *       that are not local
		 */
		return(0); /* let forward_core() handle it */
	}
	if (tlv && (flags & CORE_API_STR_FLAG)) {
		if (g_emu && g_emu->exec) {
			len = core_api_get_tlv_length(tlv) + 1;
			resp = malloc(len);
			if (!resp)
				return(-1);
			core_api_get_tlv_string(tlv, resp, len);
			/* get some extra TLVs */
			tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_NODE);
			if (core_api_get_tlv_val32(tlv, &node_id) < 0)
				return(-1);
			tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_TIME);
			core_api_get_tlv_val32(tlv, &exec_time);
			tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_RESULT);
			core_api_get_tlv_val32(tlv, &exec_result);

			err = g_emu->exec(flags, node_id, exec_id, exec_time,
					  NULL, resp, exec_result);
			free(resp);
			return(err);
		}
	}
	return(0);
}

int
receive_reg_msg(struct core_conn *conn, uint8_t *buf, uint16_t length)
{
	struct core_api_tlv *tlv;
	char tmp[255], modtypestr[16];

	bzero(tmp, sizeof(tmp));
	tlv = NULL;
	/* wl_log("receive_reg_msg(sock=%d, buf=%p, length=%d)\n",
	       conn->sock, buf, length); */

	while ((tlv = core_api_get_next_tlv(buf, tlv))) {
	  switch (tlv->type) {
	case CORE_TLV_REG_WIRELESS:
	        sprintf(modtypestr, "Wireless");
	case CORE_TLV_REG_MOBILITY:
		if (tlv->type == CORE_TLV_REG_MOBILITY)
	            sprintf(modtypestr, "Mobility");
	case CORE_TLV_REG_UTILITY:
		if (tlv->type == CORE_TLV_REG_UTILITY)
	            sprintf(modtypestr, "Utility");
		strncpy(tmp, (char *)tlv->value, tlv->length);
		wl_log("  +---%s Model '%s' has been registered from %s.\n",
			modtypestr, tmp, conn->name);
		/* we may receive config messages for this model */
		conn->subscriptions[CORE_API_CONF_MSG] = 1;
		/* add_conn_model(conn, tlv->type, tmp); */
		break;
	case CORE_TLV_REG_EXECSRV:
		strncpy(tmp, (char *)tlv->value, tlv->length);
		wl_log("Execution server '%s' has been registered.\n", tmp);
		/* register to receive exec and file messages */
		conn->subscriptions[CORE_API_EXEC_MSG] = 1;
		conn->subscriptions[CORE_API_FILE_MSG] = 1;
		break;
	case CORE_TLV_REG_GUI:
		strncpy(tmp, (char *)tlv->value, tlv->length);
		wl_log("GUI '%s' has been registered, sending daemon "
		       "capabilities.\n", tmp);
		snprintf(conn->name, sizeof(conn->name), "%s", tmp);
		/* send information on the models we support (capabilities) */
		if (send_register_caps(conn->sock) < 0)
			wl_log("Warning: error sending model info to GUI.\n");
		/* register to receive node, link, and interface messages */
		conn->subscriptions[CORE_API_NODE_MSG] = 1;
		conn->subscriptions[CORE_API_LINK_MSG] = 1;
		conn->subscriptions[CORE_API_EXEC_MSG] = 1;
		conn->subscriptions[CORE_API_IFACE_MSG] = 1;
		conn->subscriptions[CORE_API_EVENT_MSG] = 1;
		break;
	case CORE_TLV_REG_EMULSRV:
		strncpy(tmp, (char *)tlv->value, tlv->length);
		if (g_emu) {
			wl_log("Warning: emulation handler already set, but "
				"proceeding to register anyway.\n");
		} else {
			wl_log("Setting '%s' as the new emulation handler.\n",
				tmp);
			g_emu = (struct core_emu*) 
				malloc(sizeof(struct core_emu));
			memset(g_emu, 0, sizeof(struct core_emu));
			g_emu->name = malloc(tlv->length + 1);
			memset(g_emu->name, 0, tlv->length + 1); 
			strncpy(g_emu->name, tmp, tlv->length);
			/* conn->name = g_emu->name, needed when closing sock */
			memset(conn->name, 0, sizeof(conn->name));
			strncpy(conn->name, tmp, sizeof(conn->name));
			/* note that all g_emu function ptrs are still NULL */
		}
		wl_log("Emulation server '%s' has been registered.\n", tmp);
		/* register to receive node, link, and interface messages */
		conn->subscriptions[CORE_API_NODE_MSG] = 1;
		conn->subscriptions[CORE_API_LINK_MSG] = 1;
		conn->subscriptions[CORE_API_IFACE_MSG] = 1;
		conn->subscriptions[CORE_API_EVENT_MSG] = 1;
		break;
	default:
		wl_log("Warning: unknown registration type %d, skipping.\n",
		       tlv->type);
		break;
	  } /* end switch */
	} /* end while */

	return(0);
}

int
receive_conf_msg(int core_sock, uint8_t *buf, uint16_t length)
{
	struct core_api_tlv *tlv;
	uint8_t conf_object[255];
	uint32_t node, emuid;
	uint16_t type_flags;
	struct core_wlan_model *m;

	tlv = core_api_get_tlv(buf, CORE_TLV_CONF_NODE);
	if (core_api_get_tlv_val32(tlv, &node) < 0)
		return(-1);
	tlv = core_api_get_tlv(buf, CORE_TLV_CONF_OBJ);
	if (core_api_get_tlv_string(tlv, conf_object, sizeof(conf_object)) < 0)
		return(-1);
	tlv = core_api_get_tlv(buf, CORE_TLV_CONF_TYPE);
	if (core_api_get_tlv_val16(tlv, &type_flags) < 0)
		return(-1);

	/* configuration message directed to "all" models */
	if (strncmp((char *)conf_object, "all", sizeof(conf_object)) == 0) {
		/* flush all models */
		if (type_flags & CONF_TYPE_FLAGS_RESET) {
			wl_log("receive_conf(): flushing all model "
				"configuration\n");
			flush_all_models();
			return(0);
		}
		/* TODO: handle other config messages sent to all models. */
	}

	//wl_log("node config: %x %s %x\n", node, conf_object, type_flags);
	/* search available models for matching model name */
	for (m = g_models; m; m = m->model_next) {
		if (strncmp(m->model_name, (char *)conf_object, 
			sizeof(m->model_name)) == 0)
			break;
	}
	if (!m) {
		wl_log("receive_conf(): unknown model name '%s'\n", 
			conf_object);
		return(-1);
	}
	/* if the wlan node has been instantiated in the emulation with
	 * this module, enable it here */
	if ((type_flags & CONF_TYPE_FLAGS_UPDATE) &&
	    ((tlv = core_api_get_tlv(buf, CORE_TLV_CONF_NETID)) != NULL)) {
		m->model_state = MODEL_STATE_ENABLED;
		core_api_get_tlv_val32(tlv, &emuid);
		wl_log("%s model enabled for WLAN 0x%x\n", m->model_name,emuid);
	}

	/* check for request flag */
	if (type_flags & CONF_TYPE_FLAGS_REQUEST) { 
		/* request requires a response */
		int err, len, hdr_len;
		uint8_t response[1024];
		bzero(response, sizeof(response));	
		/* create a reply message containing the node number and 
		 * configuration object
		 */
		hdr_len = len = core_api_create_message(response, 
					CORE_API_CONF_MSG, 0, 0, NULL);
		len += core_api_create_tlv32(&response[len], CORE_TLV_CONF_NODE,
				node);
		len += core_api_create_tlv(&response[len], CORE_TLV_CONF_OBJ,
				strlen((char*)conf_object), conf_object);
		len += core_api_create_tlv16(&response[len], CORE_TLV_CONF_TYPE,
				0); /* flag nothing, this is a reply */
		core_api_message_set_length(response, len - hdr_len);
		/* configuration request procedure needs to fill in the
		 * remaining TLVs that will be sent via the CORE API */
		err = m->conf(type_flags, response, len);
		if (err < 0)
			return(-1);
		len = err;
		err = send(core_sock, response, len, 0);
		if (len < 0) {
			wl_log("receive_conf(): error sending response: %s\n",
				strerror(errno));
			return(-1);
		}
		return(0); /* OK */
	} else { /* response containing config data */
		return m->conf(type_flags, buf, length);
	}
}

int
receive_file_msg(int core_sock, uint8_t *buf, uint16_t length)
{
	//int len;
	struct core_api_tlv *tlv;

	/* basic check for required TLV */ 
	tlv = core_api_get_tlv(buf, CORE_TLV_FILE_NAME);
	if (!tlv)
		return(-1);

	/* File messages are forwarded to an execution server to handle
	 * file I/O. This is to prevent blocking if there were a large
	 * file transfer, and because accessing a node's filesystem
	 * may be specific to different emulations. */
	return(0);
}


int
receive_event_msg(int core_sock, uint8_t *buf, uint16_t length)
{
	struct core_api_tlv *tlv;
	uint32_t event_type;
	struct timeval now;

	tlv = core_api_get_tlv(buf, CORE_TLV_EVENT_TYPE);
	if (core_api_get_tlv_val32(tlv, &event_type) < 0)
		return(-1); /* event type is required */
	gettimeofday(&now, NULL);
	wl_log("event type %u at %s", event_type, ctime(&now.tv_sec));

	/* Event messages are printed here and then forwarded on to other
	 * entities. */
	return(0);
}

/*
 * Send the capabilities list (list of all models) for this CORE Plugin
 * using the CORE API.
 */
int
send_register_caps(int s)
{
	uint8_t buf[768];
	int len, hdr_len, tlv_len, flags = 0;
	struct core_wlan_model *m;
	/* send the CORE API Register message */
	hdr_len = len = core_api_create_message(
				buf,
				CORE_API_REG_MSG, 
				CORE_API_ADD_FLAG, 0, NULL);
	tlv_len = 0;
	if (g_emu) {
		/* TLV indicating emulation capabilitiy */
		tlv_len = core_api_create_tlv(&buf[len], CORE_TLV_REG_EMULSRV,
			    strlen(g_emu->name), (uint8_t *)g_emu->name);
		len += tlv_len;
	}

	for_each_model(m, g_models) {
		tlv_len = core_api_create_tlv(&buf[len], m->model_type,
			    strlen(m->model_name), (uint8_t *)m->model_name);
		len += tlv_len;
	}
	core_api_message_set_length(buf, len - hdr_len);
	if (send(s, buf, len, flags) < 0) {
		wl_log("send_register_caps() send() error: %s\n",
			strerror(errno));
		return(-1);
	}
	return(0);
}

int
link_nodes(uint32_t net, uint32_t node1, uint32_t node2, uint32_t emuid1, 
	uint32_t emuid2, struct link_params *params)
{
	struct core_link_data data; /* only part of this struct is used */
#ifdef FREEBSD
	int s = control_sock;
	if (emuid1 && emuid2)
		send_wlan_netgraph_message(s, net, emuid1, emuid2, 0, params);
#endif
	if (g_emu && g_emu->link) {
		memset(&data, 0, sizeof(data));
		if (params) memcpy(&data.p, &params, sizeof(data.p));
		data.netid = net;
		data.type = 0;
		g_emu->link(CORE_API_ADD_FLAG, node1, node2, &data);
	}
	return (send_link_message(net, node1, node2, 0, params));/* notify GUI */
}

int
unlink_nodes(uint32_t net, uint32_t node1, uint32_t node2, uint32_t emuid1, 
	uint32_t emuid2)
{
	struct core_link_data data; /* only part of this struct is used */
#ifdef FREEBSD
	int s = control_sock;
	if (emuid1 && emuid2)
		send_wlan_netgraph_message(s, net, emuid1, emuid2, 1, NULL);
#endif
	if (g_emu && g_emu->link) {
		memset(&data, 0, sizeof(data));
		data.netid = net;
		data.type = 0;
		g_emu->link(CORE_API_DEL_FLAG, node1, node2, &data);
	}
	return (send_link_message(net, node1, node2, 1, NULL)); /* notify GUI */
}

/*
 * Send CORE API Link message to the GUI for updating the display.
 */
int
send_link_message(uint32_t net, uint32_t node1, uint32_t node2, int delete, 
	struct link_params *params)
{
	uint8_t buf[256];
	int len, hdr_len;

	hdr_len = len = core_api_create_message(
			buf,
			CORE_API_LINK_MSG, 
			delete ? CORE_API_DEL_FLAG : CORE_API_ADD_FLAG,
			0, NULL);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_N1NUMBER, node1);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_N2NUMBER, node2);
	if (!delete) {
	len += core_api_create_tlv64(&buf[len], CORE_TLV_LINK_DELAY,
					params->delay);
	len += core_api_create_tlv64(&buf[len], CORE_TLV_LINK_BW, params->bw);
	len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_PER, params->per);
	len += core_api_create_tlv16(&buf[len], CORE_TLV_LINK_DUP, params->dup);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_JITTER, 
					params->jitter);
	}
	len += core_api_create_tlv32(&buf[len], CORE_TLV_LINK_NETID, net);
	core_api_message_set_length(buf, len - hdr_len);

	if (forward_core(NULL, CORE_API_LINK_MSG, buf, len) < 0) {
		wl_log("send_link_message() message not forwarded\n");
		return(-1);
	}
	return(0);
}

/*
 * Send CORE API Node message to GUI for moving a node.
 * When source is specified, we'll send this message to all models, excluding
 * the source model.
 */
int
send_node_message(char *source, uint16_t flags, uint32_t node_id,
	uint32_t net_id, uint32_t emu_id, uint16_t x, uint16_t y)
{
	uint8_t buf[256];
	int len, hdr_len;
	struct core_wlan_model *m;

	/* send an informational position message to the GUI */
	hdr_len = len = core_api_create_message(buf, CORE_API_NODE_MSG,
						(uint8_t)flags, 0, NULL);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_NUMBER, node_id);
	len += core_api_create_tlv16(&buf[len], CORE_TLV_NODE_XPOS, x);
	len += core_api_create_tlv16(&buf[len], CORE_TLV_NODE_YPOS, y);
	core_api_message_set_length(buf, len - hdr_len);
	if (forward_core(NULL, CORE_API_NODE_MSG,  buf, len) < 0) {
		wl_log("send_link_message() message not forwarded\n");
		return(-1);
	}
	if (!source)
		return(0);

	for_each_model(m, g_models) {
		if (m->model_state < MODEL_STATE_ENABLED)
			continue;
		if (strncmp(m->model_name, source, sizeof(m->model_name)) == 0)
			continue;
		if (m->update) 
			m->update(flags, net_id, node_id, emu_id,
				(uint32_t)x, (uint32_t)y);
	}
	return(0);
}

/*
 * Connect to another CORE daemon so it can register. Print messages on success
 * or failure. Returns the number of seconds until connect retry.
 */
int
connect_emulation_handler(now)
struct timeval *now;
{
	struct sockaddr_in connect_addr;
	int core_sock;
	static int show_retry_msg=1;
	bzero(&connect_addr, sizeof(connect_addr));

	/*
	 * Connect to CORE daemon.
	 */
	connect_addr.sin_family = AF_INET;
	connect_addr.sin_port = htons(CORE_API_EMU_PORT);
	core_sock = socket_connect(IPPROTO_TCP, SA(&connect_addr),
				   show_retry_msg);
	if (core_sock < 0) {
		if (show_retry_msg) {
			wl_log("Couldn't connect to CORE daemon on port %d, "
			       "will retry every %d seconds - %s",
				CORE_API_EMU_PORT, CORE_CONTROL_RETRY,
				ctime(&now->tv_sec));
		}
		show_retry_msg = 0;
		return(CORE_CONTROL_RETRY);
	}
	wl_log("Connected to CORE daemon on port %d - %s",
		CORE_API_EMU_PORT, ctime(&now->tv_sec));
	show_retry_msg = 1;
	add_core_conn(core_sock, CORE_CONNTYPE_TCP);
	return(0);
}

/*
 * Debug
 */
void
wlan_hexdump(data, len)
char *data;
int len;
{
	int i;
	/* hex dump 16 bytes wide */
	for(i=0; i<len; i++) 
		wl_log("%.2x%s", data[i]&0xFF, (i && !(i % 16)) ? "\n" : " " );
	wl_log("\n");
}

/*
 * String to address.
 */
int str_to_addr(char *data, struct sockaddr *addr)
{
#ifdef WIN32
        int len = SALEN(addr);
        return(WSAStringToAddress((LPSTR)data, addr->sa_family, NULL,
                        addr, &len)==0);
#else
	uint16_t port;
	char *port_str;
	if ((addr->sa_family == AF_INET) && (port_str = strrchr(data, ':'))) {
		if (sscanf(port_str, ":%hu", &port) != 1)
			return(0);
		((struct sockaddr_in*)addr)->sin_port = htons(port);
		*port_str = '\0';
	}
        return(inet_pton(addr->sa_family, (char*)data, SA2IP(addr)));
#endif
}

/*
 * Address to string.
 */
int addr_to_str(struct sockaddr *addr, char *data, int len)
{
#ifdef __WIN32__
	DWORD dw = (DWORD)len;
	return(WSAAddressToString(addr, SALEN(addr), NULL, data, &dw)!=0);
#else
	return(inet_ntop(addr->sa_family, SA2IP(addr), (char*)data, len)==NULL);
#endif
}

/*
 * Print or log messages.
 */
void
wl_log(char *fmt, ...)
{
	va_list ap;
	
	va_start(ap, fmt);
	vfprintf(stdout, fmt, ap);
	va_end(ap);
	fflush(stdout);
}

#ifndef VERBOSE_DEBUG
void
wl_log_v(char *fmt, ...)
{
	return;
}
#endif


#ifdef WIN32
void wl_WinError(int code) {
        LPVOID lpMsgBuf;
        FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER|
                FORMAT_MESSAGE_FROM_SYSTEM, NULL, code,
                MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                (LPTSTR) &lpMsgBuf, 0, NULL);
        wl_log("error %d: %s", code, lpMsgBuf);
        LocalFree(lpMsgBuf);
}
#endif

/*
 * Open log file.
 */
int
wl_open_log(filename, opts)
char *filename;
int opts;
{
	if (!freopen("/dev/null", "r", stdin))
		return(-1);

	if (!freopen(filename, (opts == 1) ? "a" : "w", stdout))
		return(-1);

	if (!freopen(filename, "a", stderr)) /* /dev/null ? */
		return(-1);

	return(0);
}

/*
 * Close log file.
 */
void
wl_close_log()
{
	fflush(stdout);
	fflush(stderr);
	fclose(stdout);
	fclose(stderr);
}

/*
 * Write PID to PID file, unless it already exists.
 */
int
wl_write_pid(filename, pid)
char *filename;
pid_t pid;
{
	char buf[16];
	FILE *fp;
	int len;

	fp = fopen(filename, "r");
	if (fp) {
		len = sizeof(buf);
		bzero(buf, len);
		if (fread(buf, len, 1, fp) == 0)
			fprintf(stderr, "Warning: unable to read PID file.\n");
		buf[strlen(buf) - 1 ] = '\0';
		fprintf(stderr, "CORE daemon already running (%s), or PID file "
			"'%s' needs to be removed.\n", buf, filename);
		fclose(fp);
		return(-1);
	}

	if (pid == 0) /* don't write a file, just check */
		return(0);

	fp = fopen(filename, "w");
	if (!fp) {
		fprintf(stderr, "Error opening PID file '%s' - %s, quitting.\n",
			filename, strerror(errno));
		return(-1);
	} else {
		sprintf(buf, "%d\n", pid);
		len = strlen(buf);
		if (fwrite(buf, len, 1, fp) != 1)
			fprintf(stderr, "Warning: unable to write to PID "
				"file.\n");
		fclose(fp);
	}

	return(0);
}

/*
 * Empty all config and node data from all models.
 */
void
flush_all_models()
{
	struct core_wlan_model *m;
	for_each_model(m, g_models) {
		if (m->flush) m->flush(FLUSH_FLAGS_ALL_NODES, 0);
		m->model_state = MODEL_STATE_INIT;
	}
}

/*
 * Signal handler for program termination.
 */
void
wlan_signal_ignore(signal)
int signal;
{
	wl_log("\n(ignoring signal %d)\n");
}

/*
 * Dump out debugging information when receiving a SIGUSR1 signal.
 */
void
wlan_signal_debug(signal)
int signal;
{
	struct core_wlan_model *m;
	struct timeval t;

	gettimeofday(&t, NULL);
	wl_log("\nDEBUG (daemon v.%.1f) - %s\n", CORED_VER, ctime(&t.tv_sec));
	debug_core_db();
	for_each_model(m, g_models)
		if (m->debug) m->debug(0);
	wl_log("\nend DEBUG\n");
}

/*
 * Signal handler for program termination.
 */
void
wlan_terminate(signal)
int signal;
{
	struct core_wlan_model *m;
	struct timeval t;

	gettimeofday(&t, NULL);
	wl_log("\nCORE daemon shutting down (with signal %d%s) - %s\n", 
		signal, 
		signal==SIGHUP ? " SIGHUP" :
		signal==SIGINT ? " SIGINT" :
		signal==SIGTERM ? " SIGTERM" :
		signal==SIGSEGV ? " SIGSEGV" : "",
		ctime(&t.tv_sec)
		);
	for_each_model(m, g_models) {
		m->model_state = MODEL_STATE_DISABLED;
		if (m->flush) m->flush(FLUSH_FLAGS_ALL_NODES, 0);
	}
	free_core_conns();
	unlink(CORED_DEFAULT_PID);
	wl_close_log();
	exit(signal);
}
