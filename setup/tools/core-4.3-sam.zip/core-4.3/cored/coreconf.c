/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * coreconf.c
 *
 * Functions for managing CORE configurations.
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <stdarg.h>		/* va_start() */
#include <string.h>		/* strerror() */
#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <sys/wait.h>		/* WIFEXITED() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select() */
#include <fcntl.h>		/* open() */
#include <errno.h>		/* errno */

#include <coreapi/coreapi.h>
#include "cored.h"
#include "core_db.h"
#include "coreconn.h"

extern int forward_core(struct core_conn *, int, uint8_t *, int); /* cored.c */

/*
 * Local functions
 */
int get_config_format(char *, char *, char *, int);

/*
 * Write config files for a node.
 */
int
generate_config(node, out_filename)
struct core_node *node;
char *out_filename;
{
	char fmt_filename[255], fmt[512], tmp[128], ospfstr[512], ospf6str[512];
	char ifname[16], ipv4str[INET_ADDRSTRLEN], ipv6str[INET6_ADDRSTRLEN];
	char rtridstr[INET_ADDRSTRLEN];
	int i, have_ipv4, have_ipv6, do_ospf;
	struct sockaddr *addr;
	FILE *f;
	struct core_link *link;
	struct link_ifparams *params;
	uint32_t rtrid, ipv4;

	memset(fmt_filename, 0, sizeof(fmt_filename));
	memset(ospfstr, 0, sizeof(ospfstr));
	memset(ospf6str, 0, sizeof(ospf6str));

	if (!node)
		return(-1);
	switch (node->node_data.type) {
	case router_quagga:
		if (node->node_data.model == wireless)
			sprintf(fmt_filename, "quagga-wireless");
		else if (node->node_data.model == wired)
			sprintf(fmt_filename, "quagga-wired");
		break;
	case router_xorp:
		sprintf(fmt_filename, "xorp");
		break;
	case host: /* these node types do not need a config written, for now */
	case PC:
	case switch_:
	case hub:
	case wlan:
	case rj45:
	case tunnel:
	case ktunnel:
	default:
		return(0);
	}
/*
	wl_log("generate_config(): file=%s fmt_filename=%s num_addrs=%d\n",
			out_filename, fmt_filename, node->node_data.num_addrs);
	debug_core_db();
// */

	/* no config file format */
	if (strlen(fmt_filename) == 0)
		return(0);

	if (get_config_format(fmt_filename, "-if.conf", fmt, sizeof(fmt)) < 0)
		return(-1);
	if (!(f = fopen(out_filename, "w"))) {
		wl_log("generate_config(): failed to open %s: %s\n",
			out_filename, strerror(errno));
		return(-1);
	}

	if ((node->node_data.type == router_quagga) &&
	    (node->node_data.model == wireless)) {
		sprintf(ospfstr, "!"); /* turn off ospf on wireless interface */
		do_ospf = 0;
	} else {
		do_ospf = 1;
	}

	have_ipv4 = have_ipv6 = 0;
	rtrid = -1; /* unsigned max */

	link = NULL;
	while ((link = find_core_link_by_node(node->node_id, link))) {
		if (link->node1_id == node->node_id)
			params = &link->link_data.if1;
		else
			params = &link->link_data.if2;
		for (i = 0; i < params->num_addrs; i++) {
			if (!&params->addrs[i])
				break;
			addr = (struct sockaddr*)&params->addrs[i];
			switch (addr->sa_family) {
			case AF_INET:
				inet_ntop(AF_INET, SA2IP(addr), ipv4str, 
						sizeof(ipv4str));
				have_ipv4 = 1;
				/* IPv4 address with the lowest value is
				 * chosen for the router ID. This must match
				 * the algorithm used in the GUI in order for
				 * the adjacency widget to work properly. */
				ipv4 = ntohl(((struct sockaddr_in *)
					     addr)->sin_addr.s_addr);
				if (ipv4 < rtrid)
					rtrid = ipv4;
				break;
			case AF_INET6:
				inet_ntop(AF_INET6, SA2IP(addr), ipv6str, 
						sizeof(ipv6str));
				have_ipv6 = 1;
				break;
			case AF_LOCAL: /* ignore MAC address */
			default:
				break;
			}
		}
		/* for now, only write a config section if we have both addrs */
		if (have_ipv4 && have_ipv6) {
			/* interface ethX statement */
			have_ipv4 = have_ipv6 = 0;
			sprintf(ifname, "eth%d", params->ifnum);
			fprintf(f, fmt,	ifname, ipv4str, 24, ipv6str, 64);

			/* ospfd network statement */
			if (do_ospf) {
				sprintf(tmp, " network %s/24 area 0\n",ipv4str);
				strcat(ospfstr, tmp);
			}
			/* ospf6d interface statement */
			sprintf(tmp, " interface eth%d area 0.0.0.0\n", 
				params->ifnum);
			strcat(ospf6str, tmp);
		}
	}

	if (rtrid == -1) /* fall back to using node ID as router ID */
		rtrid = node->node_id;
	rtrid = htonl(rtrid);
	inet_ntop(AF_INET, &rtrid, rtridstr, sizeof(rtridstr));

	if (get_config_format(fmt_filename, ".conf", fmt, sizeof(fmt)) < 0) {
		fclose(f);
		return(-1);
	}
	/* hostname, router ospf section, router ospf6 section */
	fprintf(f, fmt, node->node_data.name, rtridstr, ospfstr, 
		rtridstr, ospf6str);
	fclose(f);
	
	return(0);
}

/*
 * Read a config file format from a text file into a string.
 */
int
get_config_format(filename, suffix, dst, dst_len)
char *filename;
char *suffix;
char *dst;
int dst_len;
{
	int fd, len;
	char fname[255];
	memset(dst, 0, dst_len);
	snprintf(fname, sizeof(fname), "%s%s%s", 
		CORE_CONF_DIR, filename, suffix);
	if ((fd = open(fname, O_RDONLY | O_NONBLOCK)) < 0)
		return(-1);
	len = read(fd, dst, dst_len);
	close(fd);
	return(len);
}

/*
 * Run a local command, e.g. on the host/root/dom0 machine. Commands may be
 * run on behalf of a node, if specified, meaning they will be queued in the
 * execution server until the node is no longer busy. Do not use wildcards
 * for these commands, it won't work.
 */
int
run_local_command_fmt(struct core_node *node, char *fmt, ...)
{
	va_list ap;
	char cmd[512];
	int status;

	va_start(ap, fmt);
	vsnprintf(cmd, sizeof(cmd), fmt, ap);
	va_end(ap);

	/* when 'node' is specified, queue the command and run it using the
 	 * execution server
 	 */
	if (node)
		return(run_node_command(node, cmd, CORE_API_LOC_FLAG));
	/* when node==NULL, run the command now and return the process' return
	 * code; assume the operation is atomic and will return immediately
 	 */
	/* wl_log("[run_local: %s]\n", cmd); */ /* verbose debug */
	status = system(cmd);
	if (WIFEXITED(status)) /* child terminated normally */
		return(WEXITSTATUS(status));
	else /* child signal, core dump, stopped, etc */
		return(-1);
}

int
run_node_command_fmt(struct core_node *node, char *fmt, ...)
{
	va_list ap;
	char cmd[512];
	va_start(ap, fmt);
	vsnprintf(cmd, sizeof(cmd), fmt, ap);
	va_end(ap);
	return (run_node_command(node, cmd, 0));
}

int
run_node_command(node, cmd, flags)
struct core_node *node;
char *cmd;
uint8_t flags;
{
	int cmd_len, buf_len, len, hdr_len, err;
	uint8_t *buf;
	static uint32_t exec_num = 2000; /* arbitrary starting number */
	uint32_t exec_time = 0;

	if (!node || !cmd)
		return(-1); /* EINVAL */

	if (verbose_debug >= 2)
		wl_log("[run_node(n%u): %s]\n", node->node_id, cmd);
	cmd_len = strlen(cmd);
	buf_len = sizeof(struct core_api_msg) + 4*(sizeof(struct core_api_tlv))+
			6*sizeof(uint32_t) + cmd_len + TLV_PAD(cmd_len);

	buf = malloc(buf_len);
	if (!buf)
		return(-1); /* malloc error */

	hdr_len = len = core_api_create_message(buf, CORE_API_EXEC_MSG, flags,
						0, NULL);

	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NODE,
				     node->node_id);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NUM, exec_num++);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_TIME, exec_time);
	len += core_api_create_tlv(&buf[len], CORE_TLV_EXEC_CMD, cmd_len,
				   (uint8_t *)cmd);

	core_api_message_set_length(buf, len - hdr_len);
	/* short circuit 0 = no reply */
	err = forward_core(NULL, CORE_API_EXEC_MSG, buf, len);
	free(buf);
	return(err);
}

int
send_span_command(type, data, data_len)
int type;
char *data;
int data_len;
{
	int err, span_sock, len;
	struct span_hdr {
		unsigned short int type;
		unsigned short int len;
		char src[32];
	} *sh;
	char buf[512];
	union sockaddr_u {
		struct sockaddr_storage dst_ss;
		struct sockaddr dst;
		struct sockaddr_in dst4;
	} dst;

	/* 
	 * build a span header with the provided type, and copy the string
	 * data to a buffer following the header 
	 */
	len = sizeof(struct span_hdr) + data_len;
	if (len > sizeof(buf))
		len = sizeof(buf);
	memset(buf, 0, sizeof(buf));
	sh = (struct span_hdr *) buf;
	sh->type = htons(type);
	sh->len = htons(len);
	sprintf(sh->src, "cored");
	memcpy(&buf[sizeof(struct span_hdr)], data, data_len);
	
	/*
	 * send the message using a local UDP socket to SPAN_PORT 4039
	 */
	span_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (span_sock < 0) {
		wl_log("[send_span_command() socket() error: %s]\n",
			strerror(errno));
		return(-1);
	}

	memset(&dst, 0, sizeof(struct sockaddr_storage));
	dst.dst4.sin_family = AF_INET;
	dst.dst4.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
	dst.dst4.sin_port = htons(4039); /* SPAN_PORT */

	err = sendto(span_sock, buf, len, 0, &dst.dst, SALEN(&dst.dst4));
	if (err < 0) {
		wl_log("[send_span_command() sendto() error: %s]\n",
			strerror(errno));
	}
	wl_log("sent %d bytes message type %d to span\n", len, type);
	close(span_sock);
	return(err);
}
