#!/bin/sh
#
# this script is called before a Quagga node is shut down
# usage:
#  conf/quagga-shutdown.sh n1
#
#if [ $1a = a ]
#then
	# node name required
#	exit;
#fi;
#NODE=$1

#
# kill any existing Quagga processes
# 
killall -q ospf6d
killall -q ospfd
killall -q ripd
killall -q bgpd
killall -q zebra

#
# kill all processes
#
#procs=`ps x | awk '{print $1}'`
#for proc in $procs
#do
#  if [ $proc = "PID" ]
#  then
#    continue
#  fi
#  if [ $proc = $$ ]
#  then
#    continue
#  fi
#  kill $proc
#done

