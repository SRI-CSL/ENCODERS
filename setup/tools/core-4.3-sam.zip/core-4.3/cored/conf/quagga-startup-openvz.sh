#!/bin/sh
#
# this script is called when a Quagga node is started
# usage:
#  conf/quagga-startup.sh n1
#
if [ $1a = a ]
then
	# node name required
	exit;
fi;
NODE=$1
#CONF=/etc/quagga/Quagga.conf
CONF=/root/boot.conf

#
# kill any existing Quagga processes
# 
killall -q ospf6d
killall -q ospfd
killall -q ripd
killall -q bgpd
killall -q zebra

#
# launch Quagga processes
#
zebra -d

vtysh -b

for f in rip ripng ospf6 ospf bgp; do
    grep -q "router \<${f}\>" $CONF && ${f}d -d
done

vtysh -b

sysctl -w net.ipv4.ip_forward=1

exit 0;
