#!/bin/sh
#
# this script is called before a Quagga node is shut down
# usage:
#  conf/quagga-shutdown.sh n1
#
if [ $1a = a ]
then
	# node name required
	exit;
fi;
NODE=$1

procs=`ps x | awk '{print $1}'`
for proc in $procs
do
  if [ $proc = "PID" ]
  then
    continue
  fi
  if [ $proc = $$ ]
  then
    continue
  fi
  kill -9 $proc
done

ifconfig lo0 127.0.0.1 -alias
ifconfig lo0 inet6 ::1 -alias
ifconfig lo0 inet6 fe80::1%lo0 -alias
ifconfig lo0 down
# kill -9 -1 2> /dev/null

# TODO: shutdown all interfaces

rm -rf /tmp/e0_${NODE}
