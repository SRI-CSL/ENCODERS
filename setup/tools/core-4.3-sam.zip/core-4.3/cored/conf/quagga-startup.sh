#!/bin/sh
#
# this script is called when a Quagga node is started
# usage:
#  conf/quagga-startup.sh n1
#
if [ $1a = a ]
then
	# node name required
	exit;
fi;
NODE=$1
CONF=/tmp/e0_${NODE}/boot.conf

ifconfig lo0 inet localhost
ifconfig eth0 mtu 1500
route add 224.0.0.0/4 localhost
sysctl vfs.morphing_symlinks=1
sysctl net.inet.icmp.bmcastecho=1
sysctl net.inet.icmp.icmplim=0
sysctl net.inet.ip.forwarding=1
sysctl net.inet6.ip6.forwarding=1

if [ ! -h /var/run/quagga ]
then
	ln -s /tmp/@ /var/run/quagga
fi
if [ ! -h /usr/local/etc/quagga/Quagga.conf ]
then
	ln -s /tmp/@/boot.conf /usr/local/etc/quagga/Quagga.conf
fi

#
# launch Quagga processes
#
zebra -d

vtysh -b

for f in rip ripng ospf6 ospf bgp; do
    grep -q "router \<${f}\>" $CONF && ${f}d -d
done

vtysh -b

return 0;
