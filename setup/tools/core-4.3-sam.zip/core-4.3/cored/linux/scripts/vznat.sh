#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Give a CORE OpenVZ container NAT access.
#
pubeth=eth0
vethnum=0
privsubnet=192.168.9

ip=/sbin/ip
ifconfig=/sbin/ifconfig
iptables=/sbin/iptables
vzctl=/usr/sbin/vzctl
vzlist=/usr/sbin/vzlist

if [ a$1 = "a" ] || [ "a$1" = "a-h" ] ; then
  echo "This script configures NAT networking for a container."
  echo ""
  echo "usage: $0 <num> [<ethnum>]"
  echo ""
  echo "  <num> is a container number, such as 1000 for VE 1000."
  echo -n "  <ethnum> is an optional Ethernet number for the container; for "
  echo "example 0 (the"
  echo -n "   default value) causes an eth0 device to be used/created inside"
  echo " the given"
  echo "   container for NAT access "
  echo "change other parameters (interfaces, IP addresses) by editing this script"
  echo ""
  exit 1;
fi;

# validate the node number
venum=$1
vzlistcmd=`$vzlist $venum`
if [ $? != 0 ]; then
  echo "Container $venum was not found."
  exit 1
fi;
echo $vzlistcmd | grep -q running
if [ $? != 0 ]; then
  echo "Container $venum is not running, please start it first."
  exit 1
fi;

if [ "a$2" != "a" ]; then
  vethnum=$2
fi

hostvethnum=$vethnum
veth=eth$vethnum

TMP=`$ip addr show dev $pubeth`
if [ $? != 0 ]; then
  echo "Invalid host interface '$pubeth'."
  exit 1
fi;
PUBLIC_IP=`$ip -4 addr show dev $pubeth | awk '/inet /{split($2,a,"/");print a[1]}'`

echo "Using the public IP address of $PUBLIC_IP from host interface $pubeth."

TMP=`$ip addr show dev veth$venum.$hostvethnum`
if [ $? != 0 ]; then
  echo "Interface $veth does not exist for container $venum, so I will create it."
  $vzctl set $venum --netif_add $veth
fi;

echo "Configuring container device $veth with address ${privsubnet}.2/24."
$vzctl exec $venum $ifconfig $veth $privsubnet.2/24

echo "Configuring host device veth$venum.$hostvethnum with address ${privsubnet}.1/24."
$ifconfig veth$venum.$hostvethnum $privsubnet.1/24

echo "Adding NAT rule:"
echo "$iptables -t nat -A POSTROUTING -s $privsubnet.0/24 -o $pubeth -j SNAT --to $PUBLIC_IP"

$iptables -t nat -A POSTROUTING -s $privsubnet.0/24 -o $pubeth -j SNAT --to $PUBLIC_IP

echo "Setting container default route..."
$vzctl exec $venum $ip ro del default
$vzctl exec $venum $ip ro add default via $privsubnet.1

echo "Setting container nameserver..."
grep nameserver /etc/resolv.conf > /vz/private/$venum/etc/resolv.conf

echo "Done."

exit 0
