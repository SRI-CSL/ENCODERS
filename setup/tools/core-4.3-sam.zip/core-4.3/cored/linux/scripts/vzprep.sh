#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Prepare an existing OpenVZ container for starting in CORE. This creates the
# temporary directory structure in /tmp/n0 containing per-node state, such as
# /tmp/n0/var/log for log files.
#

# these are the per-node directories that will be created
# edit the below line to include your own per-node directory
DIRS="/var/run/quagga /var/run/dbus /var/log /usr/local/etc /usr/local/var/log \
      /usr/local/var/run /etc/avahi/services /etc/avahi/etc"

if [ a$1 = "a" ]; then
  echo "This script is used by CORE to prepare OpenVZ containers for starting."
  echo "usage: $0 <num> [stop]"
  echo ""
  echo "<num> is a node number such as 3 for VE 1003."
  echo "The special <num> 'all' may be specified to update all node temporary"
  echo " directories."
  exit 1
elif [ a$1 = "aall" ]; then
  # update all node temporary directories
  venums=`/usr/sbin/vzlist -o ctid -a -H | xargs`
else
  # update only the node specified with the first argument
  venums=`expr 1000 + $1`
  if [ $? != 0 ]; then
    echo "Invalid node number specified: '$1'"
    exit 1
  fi;
fi;


for ve in $venums
do
  node=`expr $ve - 1000`
  # remove the temporary area; this cleans out all logs and PID files
  if [ x$2 = xstop ]; then
    rm -rf /tmp/n$node
  else
  # create a new, empty temporary area
    mkdir -p /tmp/n$node
    for d in $DIRS
    do
      mkdir -p /tmp/n$node$d
    done
  fi
done
exit 0
