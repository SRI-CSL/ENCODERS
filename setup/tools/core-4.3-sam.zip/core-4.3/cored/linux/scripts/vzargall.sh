#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Run a command using the container number as an argument. Uses all containers,
# even if they are stopped.
#

VZL=`vzlist -a | awk '{ print $1 }'`

if [ a$1 = "a" ]; then
	echo "usage: $0 <command> <args> VEID"
	echo -n "  Run <command> with <args> arguments for each container "
	echo "(where VEID is auto-"
	echo "  matically replaced with each container number.)"
	echo "  This uses all containers (vzlist -a), even if they are stopped."
	echo "example: $0 vzctl destroy"
	echo "  Would destroy all containers."
	exit 1;
fi;

for ve in $VZL
do
	if [ $ve = "CTID" ]; then
		continue
	fi;
	echo "$1 $2 $3 $4 $5 $6 $7 $8 $9 $ve"
	$1 $2 $3 $4 $5 $6 $7 $8 $9 $ve
done;
