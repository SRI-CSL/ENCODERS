#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Run a command on all containers.
#

VZL=`vzlist -a | awk '{ print $1 }'`

if [ a$1 = "a" ]; then
	echo -n "Use this script to precreate a certain number of CORE "
	echo "containers. This will "
	echo "speed CORE startup for the first time the node is started."
	echo ""
	echo "usage: $0 <num>"
	echo ""
	exit 1;
fi;

#echo "WARNING: about to destroy these containers:"
#echo `echo $VZL|xargs`
#echo "continue? (y/N)"
#read confirm

#if [ a$confirm != "ay" ]; then
#	exit 0;	
#fi

#for ve in $VZL
#do
#	if [ $ve = "CTID" ]; then
#		continue
#	fi;
#	echo "vzctl destroy $ve"
	#/usr/sbin/vzctl destroy $ve 
#done;

#echo "---------------------------------"

vend=`expr 1000 + $1`
ve=1000

until [ $ve -gt $vend ]
do
	echo "vzctl destroy $ve"
	/usr/sbin/vzctl destroy $ve
	echo "vzctl create $ve --ostemplate centos-5-i386-quagga --config core"
	/usr/sbin/vzctl create $ve --ostemplate centos-5-i386-quagga --config core
	ve=`expr $ve + 1`
done


