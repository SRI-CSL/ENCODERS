#!/bin/sh
#
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# brctl wrapper script
# usage: addif.sh <bridge> <if>

# interface creation can take up to 15 seconds: tune these accordingly
ATTEMPTS=25
DELAY=2
# required binaries
BRCTL_BIN=/usr/sbin/brctl
IFCONFIG_BIN=/sbin/ifconfig
# also /bin/sleep /usr/bin/expr /bin/grep

# gather arguments
if [ "$1a" = "a" ]
then
	exit 1
fi;
BRIDGE=$1
if [ "$2a" = "a" ]
then
	exit 1
fi;
IFNAME=$2

# wait for interface to be created
while [ $ATTEMPTS -gt 0 ]
do
  $IFCONFIG_BIN $IFNAME > /dev/null
  if [ $? = 0 ]
  then
	echo "interface $IFNAME exists"
	break
  else
	echo "waiting for creation of interface $IFNAME"
  fi
  ATTEMPTS=`expr $ATTEMPTS - 1`
  sleep $DELAY 
done

# add interface to the bridge, retry upon failure
while [ $ATTEMPTS -gt 0 ]
do
  $BRCTL_BIN addif $BRIDGE $IFNAME

  if [ $? = 0 ]
  then
	# check if interface was actually added to a bridge
	$BRCTL_BIN show | grep $IFNAME > /dev/null
	if [ $? = 0 ]
	then
		# success: interface was added to bridge
		echo "interface $IFNAME was added to bridge $BRIDGE"
		exit 0
	else
		echo "interface $IFNAME was not added with attempts=$ATTEMPTS"
	fi
  else
	echo "interface $IFNAME had brctl error"
  fi;

  ATTEMPTS=`expr $ATTEMPTS - 1`
  sleep $DELAY 
done

exit 1;
