#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Stop all containers and cleanup any bridges created by CORE.
#

EBCHAINS=`/sbin/ebtables -L | grep vzbr | awk -F, '{ print $1; }' | awk '{ print $3; }'`
/sbin/ebtables -F
for c in $EBCHAINS
do
	echo "Removing ebtables chain $c..."
	/sbin/ebtables -X $c
done;

VZBRS=`/sbin/ifconfig -a | grep ^vzbr | awk '{ print $1 }'`

for b in $VZBRS
do
	echo "Shutting down bridge $b..."
	/sbin/ifconfig $b down
	/usr/sbin/brctl delbr $b
done;

VZL=`/usr/sbin/vzlist | awk '{ print $1 }'`
for ve in $VZL
do
	if [ $ve = "CTID" ]; then
		continue
	fi;
	echo "vzctl stop $ve"
	/usr/sbin/vzctl stop $ve;
done;

