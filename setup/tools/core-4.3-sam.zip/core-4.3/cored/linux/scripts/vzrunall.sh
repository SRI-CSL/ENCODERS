#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Run a command on all containers.
#

VZL=`vzlist | awk '{ print $1 }'`

if [ a$1 = "a" ]; then
	echo "usage: $0 <command>"
	exit 1;
fi;

for ve in $VZL
do
	if [ $ve = "CTID" ]; then
		continue
	fi;
	echo "vzctl exec $ve $1 $2 $3 $4 $5 $6 $7 $8 $9"
	/usr/sbin/vzctl exec $ve $1 $2 $3 $4 $5 $6 $7 $8 $9
done;
