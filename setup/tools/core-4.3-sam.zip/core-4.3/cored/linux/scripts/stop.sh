# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Stop CORE processes, remove logs.
#

DAEMONS="coreexecd cored span"

for d in $DAEMONS
do
  /usr/bin/killall -v $d
  rm -vf /var/log/$d.log
  rm -vf /var/log/$d.log.err
  rm -vf /var/run/$d.pid
done

rm -vf /vz/lock/core.ebtables.lck
rm -f /tmp/core_*.conf
