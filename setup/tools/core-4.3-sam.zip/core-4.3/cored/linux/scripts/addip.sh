#!/bin/sh
#
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# ifconfig/ip addr wrapper script
# usage: addip.sh <if> <addr/mask>
# examples: addip.sh eth0 192.168.0.3/24
#           addip.sh eth1 3ffe:1::12/48

# interface creation can take up to 15 seconds: tune these accordingly
ATTEMPTS=25
DELAY=4
# required binaries
IFCONFIG_BIN=/sbin/ifconfig
IP_BIN=/sbin/ip

# also /bin/sleep /usr/bin/expr /bin/grep

# gather arguments
if [ "$1a" = "a" ]
then
	echo "$0 missing first parameter <if>"
	exit 1
fi;
IFNAME=$1
if [ "$2a" = "a" ]
then
	echo "$0 missing second parameter <addr/mask>"
	exit 1
fi;
ADDR=$2

# wait for interface to be created
while [ $ATTEMPTS -gt 0 ]
do
  $IFCONFIG_BIN $IFNAME > /dev/null
  if [ $? = 0 ]
  then
	echo "adding address $ADDR interface $IFNAME exists"
	break
  else
	echo "adding address $ADDR waiting for creation of interface $IFNAME"
  fi
  ATTEMPTS=`expr $ATTEMPTS - 1`
  sleep $DELAY 
done

# add address to interface, retry upon failure
while [ $ATTEMPTS -gt 0 ]
do
  $IFCONFIG_BIN $IFNAME up
  $IP_BIN addr add $ADDR dev $IFNAME

  # take no action on ip return code, if the address already exists the 
  # return code will be error
  # if [ $? = 0 ]

  # check if address was actually added to the interface
  $IP_BIN addr show dev $IFNAME | grep $ADDR > /dev/null
  if [ $? = 0 ]; then
	echo "address $ADDR was added to interface $IFNAME"
	exit 0
  else
	echo -n "address $ADDR was not added to interface $IFNAME "
	echo "with attempts=$ATTEMPTS"
  fi

  ATTEMPTS=`expr $ATTEMPTS - 1`
  sleep $DELAY 
done

exit 1;
