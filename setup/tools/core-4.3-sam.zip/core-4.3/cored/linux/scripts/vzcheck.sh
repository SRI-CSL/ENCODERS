#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Check that an OpenVZ container has properly started.
#

ATTEMPTS=20
DELAY=2

vzctl=/usr/sbin/vzctl


if [ a$1 = "a" ]; then
  echo -n "This script is used by CORE to check that an OpenVZ container has "
  echo "started."
  echo "usage: $0 <num>"
  echo ""
  exit 1
fi;

venum=`expr 1000 + $1`
if [ $? != 0 ]; then
  echo "Invalid node number specified: '$1'"
  exit 1
fi;


# check container status
is_running=0
while [ $ATTEMPTS -gt 0 ]; do
  STAT=`$vzctl status $venum`
  if [[ $STAT = *running* ]] ; then
    echo "VE $venum is running"
    break;
  fi
  echo "Waiting for VE $venum to start $ATTEMPTS..."
  ATTEMPTS=`expr $ATTEMPTS - 1`
  sleep $DELAY
done

# check for loopback interface
while [ $ATTEMPTS -gt 0 ]; do
  $vzctl exec2 $venum 'ifconfig lo up' 2> /dev/null
  LO=`$vzctl exec2 $venum ifconfig lo`
  if [ $? = 0 ]; then
    if [[ $LO = *UP* ]] ; then
      echo "VE $venum loopback is running"
      break;
    fi
  fi
  echo "Waiting for $venum loopback lo to start $ATTEMPTS..."
  ATTEMPTS=`expr $ATTEMPTS - 1`
  sleep $DELAY
done

if [ $ATTEMPTS -gt 0 ]; then
  echo "VE $venum is ready"
  exit 0
fi
exit 1
