#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Stop routing processes on all containers.
#

VZL=`vzlist | awk '{ print $1 }'`

for ve in $VZL
do
	if [ $ve = "CTID" ]; then
		continue
	fi;
	echo "Shutting down procs in $ve..."
	/usr/sbin/vzctl exec $ve killall ospf6d ospfd zebra 
done;
