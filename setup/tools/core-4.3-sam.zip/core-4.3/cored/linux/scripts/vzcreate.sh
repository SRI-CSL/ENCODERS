#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Create an OpenVZ container for use with CORE. 
#
VZ=vz
PRIV=private
VZPRIVROOT=/$VZ/$PRIV/core-root
VZCONF=/etc/vz/conf
CORECONF=/etc/core

if [ a$1 = "a" ]; then
  echo "This script is used by CORE to create OpenVZ containers."
  echo "usage: $0 <num>"
  echo "usage: $0 <num-min> <num-max>"
  echo ""
  exit 1;
fi;

nodenum=$1
venum=`expr 1000 + $nodenum`
if [ $? != 0 ]; then
  echo "Invalid node number specified: '$nodenum'"
  exit 1
fi;
nodenummax=$nodenum
if [ a$2 != a ]; then
  nodenummax=$2
fi;

# sanity checks
if [ ! -d $VZPRIVROOT ]; then
  echo "The CORE container root filesystem is missing in $VZPRIVROOT."
  exit 1
fi
if [ -d /usr/local/etc/core ]; then
  # default to /etc/core but use /usr/local/etc/core if it exists
  CORECONF=/usr/local/etc/core
fi

# begin loop
while [ $nodenum -le $nodenummax ]
do
  venum=`expr $nodenum + 1000`
  if [ -d /$VZ/$PRIV/$venum ]; then
    echo "Container private area /$VZ/$PRIV/$venum already exists."
    continue
  fi
  
  # create private area
  ln -s $VZPRIVROOT /$VZ/$PRIV/$venum
  
  # create config
  cp $CORECONF/vps.mount $VZCONF/$venum.mount
  cp $VZCONF/ve-core.conf-sample $VZCONF/$venum.conf
  echo "HOSTNAME=\"n$nodenum\"" 			>> $VZCONF/$venum.conf
  echo "VE_ROOT=\"/vz/root/\$VEID\""			>> $VZCONF/$venum.conf
  echo "VE_PRIVATE=\"/vz/private/\$VEID\""		>> $VZCONF/$venum.conf
  echo "OSTEMPLATE=\"centos-5-x86-quagga\""	 	>> $VZCONF/$venum.conf
  echo "ORIGIN_SAMPLE=\"core\""				>> $VZCONF/$venum.conf
  
  nodenum=`expr $nodenum + 1`
done
# end loop

exit 0
