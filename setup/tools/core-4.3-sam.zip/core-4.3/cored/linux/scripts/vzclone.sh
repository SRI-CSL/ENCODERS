#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# vzclone.sh
#   Convert a container's filesystem into hard links.
#   These directories are hard-linked from <src> to <dst>: /bin /lib /sbin /usr
#

if [ "$1a" = "a" -o "$2a" = "a" ];
then
	echo "Usage: $0 <src> <dst>"
	echo "Where <src>, <dst> are numbers like 1001 for /vz/private/1001."
	exit 1;
fi;

if [ ! -d /vz/private/$1 ]
then
	echo "/vz/private/$1 does not exist"
	exit 1;
fi
SRC=$1
if [ ! -d /vz/private/$2 ]
then
	echo "/vz/private/$2 does not exist"
	exit 1;
fi
DST=$2

# find types:
# b block, c character, d dir, p pipe, f file, l symlink, s socket

echo "Searching for files..."
FILES=`find /vz/private/${SRC}/bin /vz/private/${SRC}/lib /vz/private/${SRC}/usr /vz/private/${SRC}/sbin -type f`
NUMFILES=`echo $FILES | wc -w`
CENTS=`expr $NUMFILES / 80`

echo "Found $NUMFILES files."

echo "Building hard links."
for f in $FILES
do
	i=`expr $i + 1`
	if [ `expr $i % $CENTS` = 0 ]; then
		echo -n "."
	fi
	dstf=`echo $f | sed s/${SRC}/${DST}/`
	rm -f $dstf
	ln $f $dstf
done
echo "Done."

