#!/bin/sh
# (c)2009 the Boeing Company
# Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
# Destroy one or more OpenVZ containers created by CORE. The 'vzctl destroy'
# command does not know how to properly remove container symlinks generated
# by CORE.
#
VZ=vz
PRIV=private
VZCONF=/etc/vz/conf

if [ a$1 = "a" ]; then
  echo "Use this script to destroy CORE OpenVZ containers."
  echo "usage: $0 <num>"
  echo "       $0 <num-min> <num-max>"
  echo -n "Use <num> to specify one container, <num-min> and <num-max> to "
  echo "destroy an entire"
  echo -n "range of containers. The command 'vzctl destroy' is not used "
  echo "because it does not"
  echo "properly handle CORE's symlinks."
  echo ""
  exit 1;
fi;

venum=`expr 1000 + $1`
if [ $? != 0 ]; then
  echo "Invalid node number specified: '$1'"
  exit 1
fi;
venummax=`expr 1000 + $2 2> /dev/null`
if [ $? != 0 ]; then
  venummax=$venum
fi;

while [ $venum -le $venummax ]
do
  #echo "venum=$venum"
  rm -rf /$VZ/$PRIV/$venum
  rm -rf $VZCONF/$venum.{conf,mount}
  rm -rf /tmp/n$1

  venum=`expr $venum + 1`
done

exit 0
