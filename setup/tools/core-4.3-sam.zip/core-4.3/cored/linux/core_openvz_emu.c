/*
 * CORE 
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE OpenVZ emulation functions.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <unistd.h>		/* close() */
#include <errno.h>		/* errno */
#include <dirent.h>		/* opendir() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/types.h>		/* stat() */
#include <sys/stat.h>		/* stat() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* stat() */


#include <coreapi/coreapi.h>
#include <cored.h>		/* wl_log(), etc. */
#include <core_emu.h>		/* g_emu, etc. */
#include <core_db.h>		/* add_core_node_db(), etc. */
#include <coreconn.h>		/* get_core_conn_sock(), etc. */

#include "core_openvz_emu.h"

#define HOST_MAC_MASK 0x00bb00000000LL

struct core_emu openvz_emu = {
	.name = "openvz",
	.init = openvz_init,
	.node = openvz_node,
	.link = openvz_link,
	.exec = openvz_exec,
};

extern int control_sock; /* control socket from cored.c */
extern int forward_core(struct core_conn *, int, uint8_t *, int);

/* local functions */
struct core_node *openvz_find_wlan(struct core_node *, struct core_node *);
struct core_link *openvz_link_to_wlan(struct core_node *, struct core_node *, 
	struct link_ifparams *);
void openvz_config_filename(struct core_node *, char *);
int openvz_restart_routing(struct core_node *);
int openvz_bridge_name(uint32_t, uint32_t, char *, int);

/*
 * Set the Vimage/Netgraph emulation functions
 */
int
init_openvz_emulation()
{
	int err;
	if (g_emu) /* already loaded? */
		return(-1);
	g_emu = &openvz_emu;
	err = g_emu->init();
	if (err < 0)
		g_emu = NULL;
	return(err);
}

int
openvz_init()
{
	int err = 0;
	struct stat buf;

	/* perform capability checks and return -1 on failure */
	err = stat("/proc/bc/resources", &buf);
	if ((err == 0) && (!S_ISREG(buf.st_mode)))
		err = -1;

	if (err < 0) {
		wl_log("This kernel does not seem to support OpenVZ.\n");
		/* wl_log("OpenVZ emulation disabled!\n");*/
		g_emu->node = NULL;
		g_emu->link = NULL;
	} else {
		wl_log("OpenVZ emulation enabled.\n");
	}
	return(err);
}

int
openvz_node(uint16_t flags, uint32_t node_id, struct core_node_data *data)
{
	struct core_node *node = NULL;
	struct core_link *link;
	int node_exists, ret;
	char path[255], ifstr[64];
	uint64_t *mac_addr, mac_addr_host;
	struct sockaddr *addr;
	uint32_t vz_node_id;
	DIR *dp;
	struct dirent *de;
	uint8_t resp_flag = 0;

	wl_log("openvz_node(flags=0x%x, node=0x%x, type=0x%x)\n",
		flags, node_id, data->type);
	if (flags & CORE_API_ADD_FLAG) {
		node = add_core_node_db(node_id, data);
		if (!node) {
			wl_log("openvz_node(): error adding node to db!\n");
			return(-1);
		}
		data = &node->node_data; /* reset ptr, data stored with node */
	} else {
		node = find_core_node_db(node_id, NULL);
	}

	/* for switch, hub, wlan, rj45, tunnel, ktunnel
	 * call appropriate Netgraph create function */
	if (node && node->node_data.type > PC) {
		return openvz_layer2_node(flags, node);
	} else if (data->type > PC) {
		wl_log("openvz_node(): layer-2 node %u not known\n", node_id);
		return(-1);
	}
	/* dummy and remote router bypass - handled only by GUI for now */
	if (node && node->node_data.type == router_quagga) {
		if ((node->node_data.model == dummy) || 
		    (node->node_data.model == remote)) {
			wl_log("openvz_node() quagga router has %s model, "
				"ignoring\n", node->node_data.model == dummy ?
				"dummy" : "remote");
			return(0);
		}
	}

	/*
	 *  check if VE node already exists 
	 */
	node_exists = 0;
	vz_node_id = vznum(node_id);
	
	if (!(dp = opendir(OPENVZ_CONF_DIR))) {
		wl_log("openvz_node(): error opening directory %s: %s\n",
			OPENVZ_CONF_DIR, strerror(errno));
		return(-1);
	}
	snprintf(path, sizeof(path), "%u.conf", vz_node_id);
	while ((de = readdir(dp))) {
		if (strncmp(de->d_name, path, sizeof(path))==0) {
			node_exists = 1;
			break;
		}
	}
	closedir(dp);

	if (flags & CORE_API_STR_FLAG) {
		resp_flag = CORE_API_STR_FLAG;
	}

	/* stop a node (but don't permanently destroy the container) */
	if (flags & CORE_API_DEL_FLAG) {
		if (!node) {
			wl_log("openvz_node(): warning: node %d not found in "
				"the database\n", node_id);
			return(-1);
		} else if (node->node_data.type == router_quagga) {
			run_node_command_fmt(node,
				"/root/quagga-shutdown-openvz.sh n%u", node_id);
		}
		
		if (!node_exists) {
			wl_log("openvz_node(): cannot delete node that does "
				"not exist - VE %u\n", vz_node_id);
			remove_core_node_db(node_id);
			return(-1);
		}

		/* shutdown any links connecting this node */
		link = NULL;
		while ((link = find_core_link_by_node(node_id, link))) {
			ret = openvz_shutdown_link(link, node);
			if (ret < 0) { /* error */
				break;
			} else if (ret == 1) {
				remove_core_link_db(link->node1_id, 
						    link->node2_id);
				link = NULL;
			}
		}

		wl_log("openvz_node(): stopping VE %u\n", vz_node_id);
		sprintf(path, "/usr/sbin/vzctl stop %u", vz_node_id);
		run_node_command(node, path, CORE_API_LOC_FLAG | resp_flag);
		remove_core_node_db(node_id);
		return(0);
	/* modify, do nothing for now */
	} else if (!(flags & CORE_API_ADD_FLAG)) {
		wl_log("openvz_node(): ignoring node modify\n");
		return(0);
	}

	/* create/start a node */
	node = add_core_node_db(node_id, data);
	if (!node) {
		wl_log("openvz_node(): error adding node to db!\n");
		return(-1);
	}
	data = &node->node_data; /* reset ptr, data stored with node */
	if (!node_exists) {
		wl_log("openvz_node(): going to create VE %u\n", vz_node_id);
		run_local_command_fmt(node, "%s/vzcreate.sh %u",
				      CORE_CONF_DIR, node->node_id);
		wl_log("openvz_node(): preparing to start VE %u\n", vz_node_id);
		run_local_command_fmt(node, "%s/vzprep.sh %u",
				      CORE_CONF_DIR, node->node_id);
	} else {
		wl_log("openvz_node(): VE %u filesystem already created\n",
		       vz_node_id);
	}
	/* this creates /tmp/n0/ temporary directories */
	wl_log("openvz_node(): preparing to start VE %u\n", vz_node_id);
	run_local_command_fmt(node, "%s/vzprep.sh %u",
				      CORE_CONF_DIR, node->node_id);

	wl_log("openvz_node(): going to start VE %u\n", vz_node_id);
	/* this command may generate a response back to the GUI */
	sprintf(path, "/usr/sbin/vzctl start %u", vz_node_id);
	//sprintf(path, "/usr/sbin/vzctl start %u --wait", vz_node_id);
	run_node_command(node, path, CORE_API_LOC_FLAG);
	/* check if a node has started and generate response back to the GUI */
	sprintf(path, "%s/vzcheck.sh %u", CORE_CONF_DIR, node->node_id);
	run_node_command(node, path, CORE_API_LOC_FLAG | resp_flag);

	/* 
 	 * add an eth0 interface
	 */
	mac_addr = NULL;
	addr = core_node_data_get_addr_ptr(&node->node_data, AF_LOCAL);
	if (addr) mac_addr = (uint64_t*) addr->sa_data;

	memset(ifstr, 0, sizeof(ifstr));
	if (mac_addr) {
		mac_addr_host = *mac_addr | HOST_MAC_MASK;
		sprintf(ifstr, " --netif_add eth0,%02x:%02x:%02x:%02x:%02x:%02x"
			",veth%u.0,%02x:%02x:%02x:%02x:%02x:%02x",
			MAC2STR(*mac_addr), vz_node_id,	MAC2STR(mac_addr_host));
	}
	run_local_command_fmt(node, "/usr/sbin/vzctl set %u --hostname %s "
			      "--onboot=no%s", 
			      vz_node_id, node->node_data.name, ifstr);

	/* vtysh -b is not bringing eth0 up*/
	if (mac_addr) {
		run_node_command(node, "ifconfig eth0 up", 0);
		run_node_command(node, "sysctl -w "
				 "net.ipv4.conf.eth0.send_redirects=0", 0);
	}

	/*
	 * start processes based on the type, model
	 */
	/* this is called for each link message */
	/* openvz_restart_routing(node); */

	return(0);
}

void openvz_config_filename(struct core_node *node, char *filename)
{
	switch (node->node_data.type) {
	case router_quagga:
		sprintf(filename, "/vz/private/%u/etc/quagga/Quagga.conf",
			vznum(node->node_id));
		break;
	case router_xorp:
		sprintf(filename, "/vz/private/%u/usr/local/etc/xorp.conf",
			vznum(node->node_id));
		break;
	default:
		sprintf(filename, "/vz/private/%u/tmp/%u.conf", node->node_id,
			vznum(node->node_id));
		break;
	}
}

int
openvz_restart_routing(struct core_node *node)
{
	int err, run_boot_script=0;
	/* char tmp_path[255], config_path[255]; */

	if (!node)
		return(-1);

	switch (node->node_data.type) {
	case router_quagga:
		if (node->node_data.model > wired) {/* static_, dummy, remote */
			run_boot_script = 1;
			break; /* don't start Quagga processes */
		}
		err = run_local_command_fmt(node,
				    "cp -avu %s/quagga-startup-openvz.sh"
				    " /tmp/n%u", CORE_CONF_DIR, node->node_id);
		err += run_local_command_fmt(node, 
				    "cp -avu %s/quagga-shutdown-openvz.sh"
				    " /tmp/n%u", CORE_CONF_DIR, node->node_id);
		err += run_node_command_fmt(node,
				    "/root/quagga-startup-openvz.sh n%d",
				    node->node_id);
		return(err);
	case router_xorp:
		wl_log("openvz_restart_routing(): XORP not implemented yet\n");
		break;
	case host:
	case PC:
		run_boot_script = 1;
		break;
	default:
		wl_log("openvz_restart_routing(): unknown node type\n");
		break;
	}

	/* old code */
	/* snprintf(tmp_path, sizeof(tmp_path), "/tmp/core_%u.conf",
		 vznum(node->node_id));
	generate_config(node, tmp_path);
	openvz_config_filename(node, config_path); */
	/* copy config and startup script to VE and run it */
	/* err = run_local_command_fmt(node, "cp -av %s %s",
				    tmp_path, config_path); */

	if (run_boot_script) {
		err = run_node_command_fmt(node, "/bin/sh /root/boot.conf",
					    node->node_id);
		return(err);

	}
	return(0);
}

int
openvz_layer2_node(uint16_t flags, struct core_node *node)
{
	struct core_node_data *data;
	uint32_t node_id;
	char br[64], *eth=NULL, tap[64];
	char ipstr[INET6_ADDRSTRLEN], mapstr[255];
	int err, do_bridge=0;
	enum { SH_TYPE_OPEN_UDP = 3, SH_TYPE_MAP = 6, SH_TYPE_TAP = 7 };
	enum { TAP_ADD = 1, TAP_DEL = 2 };
	uint32_t tapcode;
	struct tapmsg_type {
		uint32_t flags;
		char tapname[64];
	} tapmsg;

	if (!node)
		return(-1);
	node_id = node->node_id;
	data = &node->node_data;

	wl_log("openvz_layer2_node(): node_id=0x%x type=%d\n", 
		node_id, data->type); 
	switch (data->type) {
	case wlan:
	case switch_:
	case hub:
		do_bridge = 1;
		break;
	case rj45:
		/* check that interface name is valid and exists */
		eth = (char *)data->name;
		if (strlen(eth) <= 0) {
			wl_log("openvz_layer2_node(): rj45 invalid name\n");
			return(-1);
		}
		err = run_local_command_fmt(NULL, "/sbin/ifconfig %s > /dev/"
					    "null 2>&1", eth);
		if (err != 0) {
			wl_log("openvz_layer2_node(): rj45 '%s' not found\n",
			       eth);
			return(-1);
		}
		wl_log("openvz_layer2_node(): rj45 bringing down %s\n", eth);
		run_local_command_fmt(node, "/sbin/ifdown %s", eth);
		do_bridge = 1;
		break;
	case tunnel:
		do_bridge = 1;
		break;
	case ktunnel:
	default:
		wl_log("openvz_layer2_node(): node n%u type %d not "
		       "implemented yet!\n", node_id, data->type); 
		return(-1);
	}

	if (!do_bridge) /* we are done */
		return(0);

	/* create or delete an ethernet bridge */
	snprintf(br, sizeof(br), "vzbrn%u", node_id);
	err = run_local_command_fmt(NULL, "/sbin/ifconfig %s > /dev/"
					    "null 2>&1", br);
	if (err != 1) { /* bridge exists - exit, or remove it */
		if (flags & CORE_API_ADD_FLAG) {
			wl_log("bridge %s already exists\n", br);
			return(0);
		} else if (!(flags & CORE_API_DEL_FLAG)) {
			wl_log("ignoring node modify for %s\n", br);
			return(0);
		}
		wl_log("removing bridge %s\n", br);
		run_local_command_fmt(node, "/sbin/ifconfig %s down", br);
		run_local_command_fmt(node, "/usr/sbin/brctl delbr %s", br);
	}
	if (flags & CORE_API_ADD_FLAG) {
		wl_log("creating bridge %s\n", br);
		run_local_command_fmt(node, "/usr/sbin/brctl addbr %s", br);
		run_local_command_fmt(node, "/usr/sbin/brctl setfd %s 0", br);
		run_local_command_fmt(node, "/sbin/ifconfig %s up", br);
	}

	/* special cases after bridge creation */
	if (data->type == wlan) {
		/* remove the jump to the user-defined chain and delete it */
		if (flags & CORE_API_DEL_FLAG) {
			run_local_command_fmt(node, "/sbin/ebtables -D FORWARD "
			      "--logical-out %s -j %s", br, br);
			run_local_command_fmt(node, "/sbin/ebtables -F %s", br);
			run_local_command_fmt(node, "/sbin/ebtables -X %s", br);
		/* direct packets for this bridge to the user-defined chain */
		} else {
			/* create new user-defined chain for this WLAN
			 * (splitting this into two commands makes this 
			 * ebtables-2.0.6 compatible (64-bit rhel5)) */
			run_local_command_fmt(node, "/sbin/ebtables -N %s", br);
			run_local_command_fmt(node, "/sbin/ebtables -P %s DROP",
			      br);
			run_local_command_fmt(node, "/sbin/ebtables -I FORWARD "
			      "--logical-out %s -j %s", br, br);
		}
	} else if (data->type == rj45) {
		wl_log("enslaving %s to bridge %s\n", eth, br);
		run_local_command_fmt(node, "%s/addif.sh %s %s",
				      CORE_CONF_DIR, br, eth);
		run_local_command_fmt(node, "/sbin/ifconfig %s 0", eth);
		/* XXX delete if? */
	} else if (data->type == tunnel) {
		strncpy(ipstr, (char *)data->name, sizeof(ipstr));
		sprintf(tap, "vztap%d", node_id);
		/* instruct span to create/delete a TAP device */
		tapcode =  (flags & CORE_API_DEL_FLAG) ? TAP_DEL : TAP_ADD;
		tapmsg.flags = htonl(tapcode);
		strncpy(tapmsg.tapname, tap, sizeof(tapmsg.tapname));
		send_span_command(SH_TYPE_TAP, (char *)&tapmsg,
				  sizeof(uint32_t) + 1+strlen(tap)); 
		if (!(flags & CORE_API_DEL_FLAG)) {
		/* instruct span to connect to peer (IP given in node name) */
		send_span_command(SH_TYPE_OPEN_UDP, ipstr, 1+strlen(ipstr)); 
		/* add mappings in span */
		snprintf(mapstr, sizeof(mapstr), "%s-%s", tap, ipstr);
		send_span_command(SH_TYPE_MAP, mapstr, 1+strlen(mapstr));
		/* TODO: need to map peerhook->localhook 
		 * support configurable hook names from the GUI using
		 * the node message; for now this only supports UDP and
		 * core0
		 */
		snprintf(mapstr, sizeof(mapstr), "%s-%s", "core0", tap);
		send_span_command(SH_TYPE_MAP, mapstr, 1+strlen(mapstr));
		/* remote mapping message */
		snprintf(mapstr, sizeof(mapstr), "%s-%s@%s", tap, "core0",
			ipstr);
		send_span_command(SH_TYPE_MAP, mapstr, 1+strlen(mapstr));
		wl_log("enslaving %s to bridge %s\n", tap, br);
		run_local_command_fmt(node, "%s/addif.sh %s %s",
				      CORE_CONF_DIR, br, tap);
		}
	}

	if (flags & CORE_API_DEL_FLAG)
		remove_core_node_db(node_id);
	return(0);
}

/*
 * The link message may create or delete wired or wireless links. Behavior
 * depends on the node type and model. Link parameters may be modified.
 */
int
openvz_link(uint16_t flags, uint32_t node1_id, uint32_t node2_id,
	struct core_link_data *data)
{
	struct core_link *link, *n1link, *n2link;
	struct core_node *node1, *node2;
	int unlink=0, need_if_params=0, do_wireless=0;
	int restart_routing_n1=0, restart_routing_n2=0, newflags;
	char br[64];

	wl_log("openvz_link(): n1=%u n2-%u if1=(%d, %d) if2=(%d, %d)\n",
		node1_id, node2_id,
		data->if1.ifnum, data->if1.num_addrs,
		data->if2.ifnum, data->if2.num_addrs); // */

	link = find_core_link_db(node1_id, node2_id, NULL);

	if (flags & CORE_API_ADD_FLAG) {
		if (!link) {
			link = add_core_link_db(node1_id, node2_id, data);
			need_if_params = 1;
		}
	} else if (flags & CORE_API_DEL_FLAG) {
		unlink = 1;
	}

	/* special "flush" message removes all wireless links */
	if ( (node1_id == node2_id) && unlink ) {
		node1 = find_core_node_db(node1_id, NULL);
		if (!node1 || node1->node_data.type != wlan) {
			wl_log("openvz_link: request to flush node %u ignored"
				"\n", node1_id);
			return(-1);
		} else {
			wl_log("openvz_link: flushing WLAN node %u\n",
				node1_id);
		}
		/* flush the rules */
		snprintf(br, sizeof(br), "vzbrn%u", node1_id);
		run_local_command_fmt(node1, "/sbin/ebtables -F %s", br);
		wl_log("openvz_link: removing ebtables rules for %s\n", br);
		/* search all nodes connected to this WLAN */
		n1link = NULL;
		while ((n1link = find_core_link_by_node(node1_id, n1link))) {
			node2_id = n1link->node2_id;
			link = NULL;
			/* look at all of this node's links, and unlink those
			 * belonging to this WLAN */
			while ((link = find_core_link_by_node(node2_id, link))){
				if (link->wlan == node1)
					link->flags = CORE_LINK_FLAGS_UNLINKED;
			}
		}

		return(0);
	}

	if (!link) {
		wl_log("openvz_link: link not found (unlink=%d)\n", unlink);
		return (-1);
	}

	if (link->node1 && link->node2) { /* use cached info */
		node1 = link->node1;
		node2 = link->node2;
	} else {
		node1 = find_core_node_db(node1_id, NULL);
		node2 = find_core_node_db(node2_id, NULL);
		if (!node1 || !node2) {
			wl_log("openvz_link: node(s) not found\n");
			return(-1); /* node(s) not found */
		}
		link->node1 = node1; /* cache the node lookup */
		link->node2 = node2;
	}

	/* modify a link */
	if (!unlink && !(flags & CORE_API_ADD_FLAG)) {
		link = add_core_link_db(node1_id, node2_id, data); /*update db*/
		if (node1->node_data.type <= PC)
			openvz_set_link_params(node1, data->if1.ifnum,&data->p);
		if (node2->node_data.type <= PC)
			openvz_set_link_params(node2, data->if2.ifnum,&data->p);
		return(0);
	}

	/* this link is explcitly a wired link */
	if (link->link_data.type == 1) {
		do_wireless = 0;
/*		wl_log("openvz_link: link type %d indicates wired link\n",
			link->link_data.type); */
	/* link type indicates wireless, and this is not the link linking the
	 * wlan to the node (wlan will always be node1) */
	} else if ((link->link_data.type == 0) && 
		   (node1->node_data.type != wlan)) {
/*		wl_log("openvz_link: link type %d indicates wireless link\n",
			link->link_data.type); */
		do_wireless = 1;
	/* link between two wireless quagga routers - do not build interfaces
	 * and bridges */
	} else if (node1->node_data.type == router_quagga &&
	    node1->node_data.model == wireless &&
	    node2->node_data.type == router_quagga &&
	    node2->node_data.model == wireless) {
/*		wl_log("openvz_link: assuming wireless link due to node type "
		       "and models\n"); */
		do_wireless = 1;
	} else {
/*		wl_log("openvz_link: assuming wired link due to node type "
		       "and models\n"); */
		do_wireless = 0;
	}

	if (do_wireless) {
		wl_log("openvz_link: %s a wireless link\n",
		       unlink ? "removing" : "creating");
		if (!link->wlan) {
			/* No cached wlan info, search for a wlan that both
			 * nodes have in common. This should only happen the
			 * first time two nodes are wirelessly linked together.
			 */
			link->wlan = openvz_find_wlan(node1, node2);
			/* TODO: in order to support two nodes belonging to
			 * two of the same wlans, we need to check link data
			 * for a wlan hint from GUI */
		}
		if (!link->wlan) {
			wl_log("openvz_link: failed to find wlan for nodes %u-"
			       "%u\n", node1_id, node2_id);
			return(-1);
		}
		n1link = find_core_link_db(link->wlan->node_id, node1_id, NULL);
		n2link = find_core_link_db(link->wlan->node_id, node2_id, NULL);
		if (!unlink) {
			if (!n1link || !n2link) {
				wl_log("openvz_link: failed to find link to "
				       "wlan %u - node %u\n",
				       link->wlan->node_id, n1link ?
					node2_id : node1_id);
				return(-1);
			}
			/* get if params from links to wlan nodes */
			if (need_if_params) {
				core_link_ifparams_copy(&link->link_data.if1,
							&n1link->link_data.if2);
				core_link_ifparams_copy(&link->link_data.if2,
							&n2link->link_data.if2);
			}
		}
		/* make or break the wireless link */
		newflags = unlink ? CORE_LINK_FLAGS_UNLINKED : 
					CORE_LINK_FLAGS_LINKED;
		if (link->flags != newflags) {
			/* models such as simple may send many link messages
			 * even if the nodes are already linked, so we maintain
			 * our own flag here to ensure duplicate ebtables
			 * rules are not added */
			openvz_link_wlan(link, node1, node2, unlink);
			link->flags = newflags;
		}
		/* note that link object is not deleted from db when
		 * wireless nodes are unlinked */
	} else {
		wl_log("openvz_link: %s a wired link\n",
		       unlink ? "removing" : "creating");
		if (unlink) {
			openvz_shutdown_link(link, node1);
			openvz_shutdown_link(link, node2);
			remove_core_link_db(node1_id, node2_id);
			return(0);
		}
		openvz_create_link(node1, node2, data);
		restart_routing_n1 = restart_routing_n2 = 1;
		/* cache the wlan node if this is a wlan-node link */
		if (node1->node_data.type == wlan) {
			link->wlan = node1;
			restart_routing_n1 = 0;
		} else if (node2->node_data.type == wlan) {
			link->wlan = node2;
			restart_routing_n2 = 0;
		}
	}

	if (restart_routing_n1)
		openvz_restart_routing(node1);
	if (restart_routing_n2)
		openvz_restart_routing(node2);

	return(0);
}

/*
 * helper to find a wlan node between two nodes; each node has a link to
 * one or more wlans with link->wlan set; after finding a wlan common to
 * both nodes, this should be cached in link->wlan
 */
struct core_node *
openvz_find_wlan(struct core_node *node1, struct core_node *node2)
{
	struct core_link *link = NULL;

	/* look through all links to node1 */
	while ((link = find_core_link_by_node(node1->node_id, link))) {
		/* this is a link link from a wlan to node1 */
		if (link->wlan) {
			/* see if node2 is linked to this wlan */
			if (find_core_link_db(link->wlan->node_id,
					      node2->node_id, NULL))
				return(link->wlan);
		}
	}
	return(NULL);
}

/*
 * helper to link a node to a wlan, preserving interface parameters for node2
 * this adds a new link to the db, and creates a new emulated link
 */
struct core_link *
openvz_link_to_wlan(struct core_node *wlan, struct core_node *node, 
	struct link_ifparams *ifp)
{
	struct core_link *link;
	struct core_link_data data; /* dummy link data: wlan has no if params */

	memset(&data, 0, sizeof(data));
	data.if1.ifnum = data.if2.ifnum = -1;

	link = add_core_link_db(wlan->node_id, node->node_id, &data);
	/* copy parameters for if2 for node2 */
	core_link_ifparams_copy(&link->link_data.if2, ifp);
	openvz_create_link(wlan, node, &link->link_data);

	return(link);
}

int openvz_bridge_name(uint32_t node1_id, uint32_t node2_id,
	char *dst, int dst_len)
{
	memset(dst, 0, dst_len);
	return (snprintf(dst, dst_len, "vzbrn%u-n%u", 
		node1_id, node2_id));
}

/*
 * creates a bridge between two nodes and joins the corresponding host 
 * interfaces to the bridge
 */
int openvz_create_link(struct core_node *node1, struct core_node *node2,
	struct core_link_data *data)
{
	char br[64], tap[64];
	int if1num, if2num;
	struct core_node *l2node = NULL, *l3node = NULL, *gnode;
	struct link_ifparams *ifp = NULL;


	if (!node1 || !node2)
		return(-1);
	
	wl_log("openvz_create_link(%u-%u)\n", node1->node_id, node2->node_id);

	/* 
 	 * Connect a layer-3 node (router, pc, host) with a
 	 * layer-2 device (wlan, hub, switch)
 	 */
	if (node1->node_data.type > PC) {
		l2node = node1;
		l3node = node2;
		if (data) ifp = &data->if2;
	} else if (node2->node_data.type > PC) {
		l2node = node2;
		l3node = node1;
		if (data) ifp = &data->if1;
	}
	if (l2node) {
		if1num = 0;
		if (data)
			if1num = ifp->ifnum;
		/* when rj45 joined to another layer2 node, use the interface 
		 * name from node name; remove existing bridge for rj45 */
		if (l3node && l3node->node_data.type == rj45) {
			/* remove existing rj45 bridge */
			snprintf(br, sizeof(br), "vzbrn%u", l3node->node_id);
			run_local_command_fmt(l3node, 
					      "/usr/sbin/brctl delif %s %s", br,
					      l3node->node_data.name);
			run_local_command_fmt(l3node, "/sbin/ifconfig %s down",
					      br);
			run_local_command_fmt(l3node, 
					      "/usr/sbin/brctl delbr %s", br);
			/* enslave rj45 to new layer2 bridge */
			snprintf(br, sizeof(br), "vzbrn%u", l2node->node_id);
			run_local_command_fmt(l3node, "%s/addif.sh %s %s",
					      CORE_CONF_DIR, br,
					      l3node->node_data.name);
			if (verbose_debug)
				wl_log("adding interface %s to bridge %s\n",
					l3node->node_data.name, br);
			return(0);
		/* TODO: two layer2 nodes linked together */
		} else if (l3node && l3node->node_data.type > PC) {
			/* tunnel node doesn't need a bridge, remove it */
			if ((node1->node_data.type == tunnel) ||
                            (node2->node_data.type == tunnel)) {
				/* l3node is the tunnel node */
				if (node1->node_data.type == tunnel) {
					l3node = node1;
					l2node = node2;
				} else {
					l3node = node2;
					l2node = node1;
				}
				snprintf(tap, sizeof(tap), "vztap%d",
					l3node->node_id);
				snprintf(br, sizeof(br), "vzbrn%u",
					l3node->node_id);
				run_local_command_fmt(l3node, 
				    "/usr/sbin/brctl delif %s %s", br, tap);
				run_local_command_fmt(l3node,
				    "/sbin/ifconfig %s down", br);
				run_local_command_fmt(l3node, 
				    "/usr/sbin/brctl delbr %s", br);
				/* enslave rj45 to new layer2 bridge */
				snprintf(br, sizeof(br), "vzbrn%u", 
					l2node->node_id);
				run_local_command_fmt(l3node,
					"%s/addif.sh %s %s", CORE_CONF_DIR, br,
					tap);
				if (verbose_debug)
				    wl_log("adding interface %s to bridge %s\n",
					tap, br);
				return(0);
			}
			wl_log("error: cannot handle linking two layer2 nodes "
			       "yet\n");
			return(-1);
		}
		if (data)
			openvz_create_interface(l3node, ifp); 
		snprintf(br, sizeof(br), "vzbrn%u", l2node->node_id);
		/* run_local_command_fmt(l3node,
					      "/sbin/ifconfig veth%u.%u 0",
					      vznum(l3node->node_id), if1num);*/
		run_local_command_fmt(l3node, "/sbin/ifconfig veth%u.%u up",
				      vznum(l3node->node_id), if1num);
		run_local_command_fmt(l3node, "%s/addif.sh %s veth%u.%u",
				      CORE_CONF_DIR, br, vznum(l3node->node_id),
				      if1num);
		if (verbose_debug)
			wl_log("adding interface veth%u.%u to bridge %s\n",
				vznum(l3node->node_id), if1num, br);
		openvz_set_link_params(l3node, if1num, &data->p);
		return(0);
	}

	/*
 	 * Link together two layer-3 nodes (router, PC, host)
 	 */
	if (!data)
		return(-1);

	/* get interface numbers */
	if1num = if2num = 0;
	if (data->if1.ifnum > 0) if1num = data->if1.ifnum;
	if (data->if2.ifnum > 0) if2num = data->if2.ifnum;

	/* make sure interface exists */
	openvz_create_interface(node1, &data->if1);
	openvz_create_interface(node2, &data->if2);

	/* create a bridge for wired nodes */
	if (data->type == wired) {
		if (openvz_bridge_name(node1->node_id, node2->node_id, 
				       br, sizeof(br)) < 0)
			return(-1);
		if (verbose_debug)
			wl_log("creating bridge %s between veth%u.%u and "
			       "veth%u.%u\n", br, vznum(node1->node_id), if1num,
				vznum(node2->node_id), if2num);
		/* the node having a greater node id (gnode)  is used to queue
		 * all of these commands, because subsequent commands depend
		 * on this first brctl command */
		gnode = (node1->node_id > node2->node_id) ? node1 : node2;
		run_local_command_fmt(gnode, "/usr/sbin/brctl addbr %s", br);
		run_local_command_fmt(gnode, "/usr/sbin/brctl setfd %s 0", br);
		run_local_command_fmt(gnode, "/sbin/ifconfig veth%u.%u up",
				      vznum(node1->node_id), if1num);
		run_local_command_fmt(gnode, "/sbin/ifconfig veth%u.%u up",
				      vznum(node2->node_id), if2num);
		run_local_command_fmt(gnode, "%s/addif.sh %s veth%u.%u",
				      CORE_CONF_DIR, br, vznum(node1->node_id),
				      if1num);
		run_local_command_fmt(gnode, "%s/addif.sh %s veth%u.%u",
				      CORE_CONF_DIR, br, vznum(node2->node_id),
				      if2num);
		run_local_command_fmt(gnode, "/sbin/ifconfig %s up", br);

		openvz_set_link_params(node1, if1num, &data->p);
		openvz_set_link_params(node2, if2num, &data->p);
	} else {
		wl_log("openvz_create_link(%u-%u) link is not wired, "
			"unhandled case\n",
			node1->node_id, node2->node_id);
	}

	return(0);
}


/* apply the given link parameters to an interface that is already running */
int
openvz_set_link_params(struct core_node *node, int ifnum, struct link_params *p)
{
	int err=0, have_netem=0;
	char qdisc_str[512], s[256];
	double reord;
	if (!node || !p)
		return(-1);

	/* replace will add the rule if it does not exist or perform a
	 * nearly-atomic remove/add */
	memset(qdisc_str, 0, sizeof(qdisc_str));
	snprintf(qdisc_str, sizeof(qdisc_str),
		 "/sbin/tc qdisc replace dev veth%u.%u handle 1:0 root netem ",
		 vznum(node->node_id), ifnum);

	if (p->delay > 0) { /* set any delay */
		snprintf(s, sizeof(s), "delay %" PRIu64 "us ", p->delay);
		strncat(qdisc_str, s, sizeof(qdisc_str) - 1);
		have_netem = 1;
	}
	/* loss and burst go together */
	if (p->per > 0) { /* set any loss */
		if (p->per > 100) {
			wl_log("openvz_set_link_params(): node %u if %d per "
			       "was reduced from %d to 100\n",
			       node->node_id, ifnum, p->per);
			p->per = 100;
		}
		snprintf(s, sizeof(s), "drop %u ", p->per);
		strncat(qdisc_str, s, sizeof(qdisc_str) - 1);
		have_netem = 1;
		if (p->burst > 0) {
			snprintf(s, sizeof(s), "%u ", p->burst);
			strncat(qdisc_str, s, sizeof(qdisc_str) - 1);
		}
	}

	if (p->dup > 0) { /* set any duplicates */
		snprintf(s, sizeof(s), "dup %u ", p->dup);
		strncat(qdisc_str, s, sizeof(qdisc_str) - 1);
		have_netem = 1;
	}
	if (p->jitter > 0 && p->delay > 0) { /* use reordering for jitter */
		reord = 100.0 * ((double)p->jitter) / ((double)p->delay);
		if (reord > 100.0) reord = 100.0;
		snprintf(s, sizeof(s), "reorder %.2f ", reord);
		strncat(qdisc_str, s, sizeof(qdisc_str) - 1);
		have_netem = 1;
	}

	snprintf(s, sizeof(s), "handle 1:0 root");
	if (have_netem) {
		qdisc_str[strlen(qdisc_str)-1] = '\0'; /* remove trailing ' ' */
		wl_log("openvz_set_link_params: '%s'\n", qdisc_str);
		err = run_local_command_fmt(node, qdisc_str);
		snprintf(s, sizeof(s), "parent 1:1");
	}

	if (p->bw > 0) {
		memset(qdisc_str, 0, sizeof(qdisc_str));
		/* TODO: support a burst bw limit */
		snprintf(qdisc_str, sizeof(qdisc_str),
			 "/sbin/tc qdisc replace dev veth%u.%u %s "
			 "handle 10: tbf rate %" PRIu64 " burst %" PRIu64 
			 " limit 3000",
			 vznum(node->node_id), ifnum, s, p->bw, p->bw);
		
		wl_log("openvz_set_link_params: (bw) %s\n", qdisc_str);
		err += run_local_command_fmt(node, qdisc_str);
	}
	/* TODO: support mer and mburst */
	return(err);
}


/* turn off an interface of one node on a link, and remove the link from
 * the kernel if it is the only node */
int
openvz_shutdown_link(struct core_link *link, struct core_node *node)
{
	struct link_ifparams *ifc;
	struct core_node *other_node;
	uint32_t other_node_id;
	char br[64];

	if (!link || !node)
		return(-1);
	wl_log("openvz_shutdown_link(%u-%u)\n", link->node1_id, link->node2_id);
	
	if (node->node_id == link->node1_id) {
		ifc = &link->link_data.if1;
		other_node_id = link->node2_id;
		if (openvz_bridge_name(node->node_id, other_node_id, br,
				       sizeof(br)) < 0)
			return(-1);
		link->node1 = NULL; /* remove this node from cache */
		other_node = link->node2;
	} else {
		ifc = &link->link_data.if2;
		other_node_id = link->node1_id;
		if (openvz_bridge_name(other_node_id, node->node_id, br,
				       sizeof(br)) < 0)
			return(-1);
		link->node2 = NULL; /* remove this node from cache */
		other_node = link->node1;
	}

	/* delete any interface associated with node */
	if (ifc->ifnum != -1) {
		wl_log("openvz_shutdown_link: removing eth%d from VE %u\n",
			ifc->ifnum, vznum(node->node_id));
		run_node_command_fmt(node, "/sbin/ifconfig eth%d down",
				     ifc->ifnum);
		run_local_command_fmt(node, "/usr/sbin/vzctl set %u --netif_del"
				      " veth%u.%u", vznum(node->node_id),
				      vznum(node->node_id), ifc->ifnum);
	}

	/* determine if the other node has been removed */
	if (!other_node) {
		if (link->link_data.type == wired) {
			wl_log("openvz_shutdown_link: removing bridge %s\n",br);
			run_local_command_fmt(node, "/sbin/ifconfig %s down",
					      br);
			run_local_command_fmt(node, "/usr/sbin/brctl delbr %s",
					      br);
		}
		return 1; /* OK to remove the link from the db */
	}
	return(0); /* OK, but leave link in db */
}


/* create an interface given parameters from a link message, or move addresses
 * from the node to the link data and use them
 */
int
openvz_create_interface(struct core_node *node, struct link_ifparams *param)
{
	char ifname[16], hifname[16], ifstr[255], path[255];
	char  addr6str[INET6_ADDRSTRLEN];
	uint64_t *mac_addr, mac_addr_host;
	struct sockaddr *addr;
	struct sockaddr_in *addr4;
	struct sockaddr_in6 *addr6;
	int mask, err;

	wl_log("openvz_create_interface(node=%d, p=%p num=%d)\n",
		node->node_id, param, param->ifnum);
#if 0
	// remove this code for supporting addresses from the node message
	// use addresses found in link or interface messages instead
	if ((param->ifnum < 0) && (node->node_data.num_addrs > 0)) {
		/* default to 'eth0' */
		wl_log("Using %d addresses from node n%u for link (%d)\n",
		       node->node_data.num_addrs, node->node_id,
		       param->num_addrs);
		param->ifnum = 0;
		param->num_addrs = node->node_data.num_addrs;
		if (param->addrs) {
/*			wl_log("Warning: memory leak? param->addrs=%p / %p\n",
				param->addrs, node->node_data.addrs); */
		}
		param->addrs = node->node_data.addrs;
		node->node_data.num_addrs = 0;
		node->node_data.addrs = NULL;
	}
#endif

	snprintf(ifname, sizeof(ifname), "eth%u", param->ifnum);
	snprintf(hifname, sizeof(hifname), "veth%u.%u",
		 vznum(node->node_id), param->ifnum);

	/* get interface MAC address from link parameters */
	mac_addr = NULL;
	addr = core_link_param_get_addr_ptr(param, AF_LOCAL);
	if (addr) {
		mac_addr = (uint64_t*) addr->sa_data;
		mac_addr_host = *mac_addr | HOST_MAC_MASK;
	} else {
		wl_log("Unable to determine MAC address for node n%u.\n",
			node->node_id);
		return(-1);
	}

	/* check if interface exists */
	err = run_local_command_fmt(NULL, "/sbin/ifconfig %s > /dev/null 2>&1",
				    hifname);
	if (err == 1) {
		/* interface does not exist, create it */
		if (mac_addr) {
			sprintf(ifstr, "%s,%02x:%02x:%02x:%02x:%02x:%02x,%s,"
				"%02x:%02x:%02x:%02x:%02x:%02x",
				ifname, MAC2STR(*mac_addr), hifname, 
				MAC2STR(mac_addr_host));
		} else {
			sprintf(ifstr, "%s", ifname);
		}
		sprintf(path, "/usr/sbin/vzctl set %u --netif_add %s",
				vznum(node->node_id), ifstr);
		run_node_command(node, path, CORE_API_LOC_FLAG);
	}

	/* set the IPv4 address */
	addr4 = (struct sockaddr_in*) core_link_param_get_addr_ptr(param,
								   AF_INET);
	if (addr4) {
		mask = addr4->sin_port;
		if (mask==0) mask = 24; /* default /24 */
		run_node_command_fmt(node, "%s/addip.sh %s %u.%u.%u.%u/%d",
				     "/usr/local/sbin", ifname, 
				     NIPQUAD(addr4->sin_addr.s_addr), mask);
/*		run_node_command_fmt(node, "/sbin/ifconfig %s inet %u.%u.%u.%u"
				     "/%d", ifname,  
				     NIPQUAD(addr4->sin_addr.s_addr), mask);
*/
	} else {
		wl_log("No IPv4 address used for node n%u if %s\n",
		       node->node_id, ifname);
	}

	/* set the IPv6 address */
	addr6 = (struct sockaddr_in6*) core_link_param_get_addr_ptr(param,
								   AF_INET6);
	if (addr6 &&
	    inet_ntop(AF_INET6, SA2IP(addr6), addr6str, SALEN(addr6))) {
		mask = addr6->sin6_port;
		if (mask==0) mask = 64; /* default /64 */
		run_node_command_fmt(node, "%s/addip.sh %s %s/%d",
				     "/usr/local/sbin", ifname, addr6str, mask);
/*		run_node_command_fmt(node, "/sbin/ip -6 addr add %s/%d dev %s",
				     addr6str, mask, ifname);
		run_node_command_fmt(node, "/sbin/ifconfig %s inet6 add %s/%d",
				     ifname, addr6str, mask); 
*/
	} else {
		wl_log("No IPv6 address used for node n%u if %s\n",
		       node->node_id, ifname);
	}

	/* other interface setup */
	run_node_command_fmt(node, "sysctl -w net.ipv4.conf."
			     "%s.send_redirects=0", ifname);

	return(0);
}

/* link/unlink wirelessly; this is the equivalent of the Netgraph link/unlink
 * for the ng_wlan
 */
int
openvz_link_wlan(struct core_link *link, struct core_node *n1,
	struct core_node *n2, int unlink)
{
	int r;
	struct core_link_data *data = &link->link_data;

	r = openvz_ebtables(link->wlan, n1, data->if1.ifnum, n2,
			    data->if2.ifnum, unlink);
	if (r < 0)
		return(r);
	r = openvz_ebtables(link->wlan, n2, data->if2.ifnum, n1,
			    data->if1.ifnum, unlink);
	return(r);
}

/* add/delete a rule to unblock/block the given interfaces from forwarding
 * traffic across a bridge; commands are queued on the wlan node, and extra
 * locking is performed in coreexecd because of ebtables
 */
int
openvz_ebtables(struct core_node *wlan, struct core_node *node1, int if1num,
	struct core_node *node2, int if2num, int delete)
{
	int err;
	char cmd, ifstr_in[30], ifstr_out[30], br[64];

	if (!wlan || !node1 || !node2)
		return(-1);

	wl_log("openvz_ebtables() %u-%u del=%d\n", node1->node_id, 
	       node2 ? node2->node_id : -1, delete); // */

	cmd = delete ? 'D' : 'I';
	snprintf(br, sizeof(br), "vzbrn%u", wlan->node_id);

	if (node1->node_data.type == rj45)
		snprintf(ifstr_in, sizeof(ifstr_in), "%s",
			 (char *)node1->node_data.name);
	else
		snprintf(ifstr_in, sizeof(ifstr_in), "veth%u.%u",
			 vznum(node1->node_id), if1num);
	if (node2->node_data.type == rj45)
		snprintf(ifstr_out, sizeof(ifstr_out), "%s",
			 (char *)node2->node_data.name);
	else
		snprintf(ifstr_out, sizeof(ifstr_out), "veth%u.%u",
			 vznum(node2->node_id), if2num);

	err = run_local_command_fmt(wlan, "/sbin/ebtables -%c %s -i %s -o %s "
				    "-j ACCEPT", cmd, br, ifstr_in, ifstr_out);
/*	wl_log("openvz_ebtables() accept rule returns %d\n", err); // */
	return(err);
}

/* add a rule on node for the interface ifnum, blocking or unblocking using
 * the MAC address found in the ifp parameters
 * XXX note: this has been replaced with openvz_ebtables()
 */
int
openvz_iptables(struct core_node *node, int ifnum, struct link_ifparams *ifp,
	int delete)
{
	int err;
	char cmd, macstr[20], ifstr[20];
	uint64_t *macp, mac;
	struct sockaddr *addr;

	cmd = delete ? 'D' : 'I';
	
	/* get interface MAC address from link parameters 
 	 * can't use node ptr because we need MAC of a different node
 	 */
	macp = NULL;
	addr = core_link_param_get_addr_ptr(ifp, AF_LOCAL);
	if (addr) macp = (uint64_t*) addr->sa_data;
	if (!macp) {
		wl_log("openvz_iptables(): no MAC address for peer of node n%u"
		       "\n", node->node_id);
		return(-1);
	}
	mac = *macp;
	snprintf(macstr, sizeof(macstr), "%02x:%02x:%02x:%02x:%02x:%02x",
		 MAC2STR(mac));
	snprintf(ifstr, sizeof(ifstr), "eth%u", ifnum);

	err = run_node_command_fmt(node, "/sbin/iptables -t mangle -%c PREROUTI"
				   "NG -m mac --mac %s -i %s -j ACCEPT",
				   cmd, macstr, ifstr);
	err += run_node_command_fmt(node, "/sbin/ip6tables -t mangle -%c PREROU"
				   "TING -m mac --mac %s -i %s -j ACCEPT",
				   cmd, macstr, ifstr);
	return(err);
}

/*
 * Receive an execute message from cored, which came from the execution
 * server. This handles responses for commands that took some time to complete.
 */
int  openvz_exec(uint16_t flags, uint32_t node_id, uint32_t exec_id, 
	uint32_t exec_time, uint8_t *exec_cmd, uint8_t *exec_resp,
	uint32_t exec_result)
{
	uint8_t buf[256];
	const char startmsg[] = " is ready";
	/* const char startmsg[] = "Container start in progress"; */
	/* also "Container started successfully" "Starting VE" */
	const char stopmsg[] = "Container is unmounted";
	/* also "Stopping container" "Stopping VE" */
	int len, hdr_len;

	/* wl_log("openvz_exec() flags=0x%x node_id=%u exec_id=%u exec_time=%u "
	       "cmd='%s' resp='%s' res=%u\n", flags, node_id, exec_id,
	       exec_time, exec_cmd, exec_resp, exec_result); // */

	/* New flags: this message is informational only */
	flags = CORE_API_LOC_FLAG;
	if (exec_resp) {
		/* Check for start or stop message in the text response */
		if 	( strstr((char *)exec_resp, startmsg) )
			flags |= CORE_API_ADD_FLAG;
		else if ( strstr((char *)exec_resp, stopmsg) ) 
			flags |= CORE_API_DEL_FLAG;
		/* could also check exec_result here */
	}

	/* Send a node message to the GUI indicating that node creation
	 * is complete (or failed)
	 */
	hdr_len = len = core_api_create_message(buf, CORE_API_NODE_MSG, flags,
						0, NULL);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_NUMBER, node_id);
	if (flags & CORE_API_ADD_FLAG)
		len += core_api_create_tlv32(&buf[len], CORE_TLV_NODE_EMUID,
					     vznum(node_id));
	wl_log("Notifying GUI of node %u (flags=0x%x, %d bytes)\n", node_id,
	       flags, len);

	core_api_message_set_length(buf, len - hdr_len);
	if (forward_core(NULL, CORE_API_NODE_MSG, buf, len) < 0) {
		wl_log("openvz_exec() message not forwarded\n");
		return(-1);
	}
	return(0);
}
