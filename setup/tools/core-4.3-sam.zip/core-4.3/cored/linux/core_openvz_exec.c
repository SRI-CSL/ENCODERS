/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE execution server for OpenVZ VEs.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#include <signal.h>		/* signal() */
#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <sys/wait.h>		/* waitpid() */
#include <sys/stat.h>		/* file modes */
#include <sys/ioctl.h>		/* ioctl() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select(), execlp() */
#include <time.h>		/* ctime() */
#include <stdarg.h>		/* va_start() */
#include <fcntl.h>		/* open() */

#include <coreapi/coreapi.h>
#include <cored.h>
#include <coreconn.h>
#include "core_openvz_emu.h"
#include "core_openvz_exec.h"

/*
 * Globals.
 */
struct core_conn *conns=NULL;		/* linked-list of connections */
struct exec_queue_entry *exec_queue=NULL; /* sorted queue of exec jobs */
char node_status[NODE_STATUS_BUCKETS];	/* state of each node */
int  exec_sock = 0;
int  verbose_debug = 0;
int local_exec_id = 100000;		/* local exec nums taken from here */

/*
 * Main routine.
 */
int 
main(argc, argv)
int argc;
char **argv;
{
	char log_filename[255];
	pid_t pid;
	int log_opts, i;

	/*
	 * Initializations
	 */
	int do_daemon = 0, do_log = 0; /* options */
	struct sockaddr_in connect_addr;
	int core_sock;
	bzero(&connect_addr, sizeof(connect_addr));
	sprintf(log_filename, "%s", EXEC_DEFAULT_LOG);
	log_opts = 0;
	core_sock = 0;

	bzero(&node_status, sizeof(node_status));

	/*
	 * Parse command-line arguments.
	 */
	argv++, argc--;
	while (argc > 0) {
		if (strcmp(*argv, "-d") == 0) {
			do_daemon = 1;
			do_log = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-l") == 0) {
			argv++, argc--;
			do_log = 1;
			if (argc==0 || !argv) {
				ex_log("Error: please specify log file.\n");
				print_usage();
				exit(1);
			} else {
				strncpy(log_filename, *argv, 255);
				ex_log("Using the log file: %s\n",log_filename);
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-k") == 0) {
			ex_log("Preserving the log file.\n");
			log_opts = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-v") == 0) {
			verbose_debug = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-h") == 0) {
			print_usage();
			exit(0);
		}

		/* unknown arguments */
		print_usage();
		exit(1);
	}

	/*
         * Run as daemon.
         */	
	if (do_daemon) {
		/* check for PID file */
		if (ex_write_pid(EXEC_DEFAULT_PID, 0) < 0)
			exit(1);
		if ((pid = fork()) < 0) {
			ex_log("fork() error: %s\n", strerror(errno));
			exit(1);
		} else if (pid > 0) {
			i = ex_write_pid(EXEC_DEFAULT_PID, pid);
			if (i < 0) { /* PID file already exists, kill child */
				kill(pid, SIGTRAP);
				exit(1);
			}
			exit(0);
		}
		umask(0); /* change file mode mask */
		if (setsid() < 0) /* obtain a new process group */
			exit(1);
		if (chdir("/") < 0)
			exit(1);
	}
	if (do_log) { /* replace stdout/stderr/stdin */
		if (ex_open_log(log_filename, log_opts) < 0) {
			fprintf(stderr,
				"Error opening log file '%s' - %s, quitting.\n",
				log_filename, strerror(errno));
			exit(1);
		}
	}

	signal(SIGINT, exec_terminate);
	signal(SIGTERM, exec_terminate);
	signal(SIGPIPE, exec_signal_ignore);
	signal(SIGSEGV, exec_terminate);
	signal(SIGHUP, exec_signal_debug);

	print_banner();
	if (verbose_debug)
		ex_log("Verbose debugging enabled.\n");
	select_loop();
	return (0);
}

/*
 * Print or log a title message.
 */
void
print_banner()
{
	struct timeval t;
	gettimeofday(&t, NULL);
	ex_log("CORE Execution Server v.%.1f - %s",
		CORED_VER, ctime(&t.tv_sec));
}

/*
 * Prints command-line options.
 */
void
print_usage()
{
	print_banner();
	printf("Execution server for CORE emulations.");
	printf("\n");
	printf("usage: coreexecd [-d] [-l <log-file>] [-k] [-v]\n");
	printf("\t-d\t\tdaemonize:\trun in the background and output to\n");
	printf("\t\t\t\t\tlog file\n");
	printf("\t-l <log-file>\tlog output to specified file\n");
	printf("\t-k keep the log file, don't truncate if it exists\n");
	printf("\t-v enable verbose debugging\n");
	printf("\n");
}

/*
 * This is where the program spends all of its time.
 */
int
select_loop()
{
	int max, err, control_sock;
	fd_set read_fdset;
	struct timeval to, now, control_retry = {0, 0};
	struct core_conn *conn;

	/*
	 * Loop forever. A separate signal handler will 
         * catch CTRL+C or KILL signals.
	 */
	for (;;) {
		/* Set up for select() call */
		max = 0;
		control_sock = -1;
		FD_ZERO(&read_fdset);
		for (conn = conns; conn; conn = conn->next) {
			if (conn->sock == 0)
				continue;
			if (conn->type == CORE_CONNTYPE_CONTROL)
				control_sock = conn->sock;
			FD_SET((unsigned int)conn->sock, &read_fdset);
			if (conn->sock > max)
				max = conn->sock;
		}
		to.tv_sec = 0;
		to.tv_usec = 333400;

		/* Perform select() and dispatch to separate receive functions
		 * if there is any data. 
                 */
		if ((err = select(max+1, &read_fdset, NULL,NULL, &to)) < 0) {
			ex_log("select() error(%d): %s\n", 
				errno, strerror(errno));
			if (errno != EINTR)
				return(-errno);
		} else if (err == 0) {
			/* timeout */
			gettimeofday(&now, NULL);
			if ((control_sock < 0) &&
			    (now.tv_sec > control_retry.tv_sec))
				control_retry.tv_sec = now.tv_sec + 
						connect_core_daemon(&now);
			waitpid(0, &err, WNOHANG); /* cleanup zombies */
			process_exec_queue(&now, control_sock);
			process_ebtables_exec_queue(&now, control_sock);
		} else  {
			/* Check for data on all our sockets. */
			for (conn = conns; conn; conn = conn->next) {
				if (conn->sock == 0)
					continue;
				if (!FD_ISSET(conn->sock, &read_fdset))
					continue;
				/* FIFO containing exec output */
				if (conn->type == CORE_CONNTYPE_FIFO) {
					if (receive_exec_output(control_sock,
								conn->sock,
								NULL) < 0) {
						free_core_conn(conn);
						break;
					}
				/* CORE API socket */
				} else if (receive_core(conn) < 0) {
					free_core_conn(conn);
					break; /* exit loop: conn now invalid!*/
				}
			} /* end for each conn */

		/* end if select() */
		}
	/* end for (;;) */
	}

	if (verbose_debug)
		ex_log("unreached: exited select loop\n");
	return(0);
}


/* 
 * Perform socket(), bind(), and listen() calls in one function.
 */
#define MAX_INCOMING 200
int
socket_bind(protocol, addr, msg)
int protocol;
struct sockaddr *addr;
char *msg;
{
	int s, addrlen, err;
	int type = (protocol == IPPROTO_TCP) ? SOCK_STREAM : SOCK_DGRAM;

	/* open socket */
	if ((s = socket(addr->sa_family, type, protocol)) < 0) {
		ex_log("%s socket() error %d: %s\n", 
			msg, errno, strerror(errno));
		return(-1);
	}

	/* bind socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	if ((err = bind(s, addr, addrlen)) < 0) {
		ex_log("%s bind() error %d: %s\n", msg, errno, strerror(errno));
		closesocket(s);
		return(-1);
	}
	
	/* put socket into listening state if TCP */
	if (type == SOCK_STREAM) {
		if ((err = listen(s, MAX_INCOMING)) < 0) {
			ex_log("%s listen() error %d: %s\n ", 
				msg, errno, strerror(errno));
			closesocket(s);
			return(-1);
		}
	}

	return(s);
}


/* 
 * Perform socket() and connect() calls in one function.
 */
int
socket_connect(protocol, addr, flags)
int protocol;
struct sockaddr *addr;
int flags;
{
	int s, addrlen;
	char name[255];

	if (flags > 0) {
		sprintf(name, "%u.%u.%u.%u:%u", 
			NIPQUAD(((struct sockaddr_in*)addr)->sin_addr.s_addr),
			ntohs(((struct sockaddr_in*)addr)->sin_port));

		ex_log("Connecting to %s using %s...\n", name,
			(protocol == IPPROTO_TCP) ? "TCP" : "UDP");
	}

	/* open socket */	
	if ((s = socket(addr->sa_family, (protocol == IPPROTO_TCP) ? 
			SOCK_STREAM : SOCK_DGRAM, protocol)) < 0) {
		if (flags > 0)
			ex_log("socket() error %d: %s\n", 
				errno, strerror(errno));
		return(-1);
	}

	/* connect socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	/* else IPv6 set sin6_port */
	if (connect(s, addr, addrlen) < 0) {
		if (flags > 0)
			ex_log("connect() error %d: %s\n",
				errno, strerror(errno));
		closesocket(s);
		return(-1);
	}

	return(s);
}

/*
 * Connect to the CORE daemon, then register with it. Print messages on success
 * or failure. Returns the number of seconds until connect retry.
 */
int
connect_core_daemon(now)
struct timeval *now;
{
	struct sockaddr_in connect_addr;
	int core_sock;
	static int show_retry_msg=1;
	bzero(&connect_addr, sizeof(connect_addr));

	/*
	 * Connect to CORE daemon.
	 */
	connect_addr.sin_family = AF_INET;
	connect_addr.sin_port = htons(CORE_API_PORT);
	core_sock = socket_connect(IPPROTO_TCP, SA(&connect_addr),
				   show_retry_msg);
	if (core_sock < 0) {
		if (show_retry_msg) {
			ex_log("Couldn't connect to CORE daemon on port %d, "
			       "will retry every %d seconds - %s",
				CORE_API_PORT, CORE_CONTROL_RETRY,
				ctime(&now->tv_sec));
		}
		show_retry_msg = 0;
		return(CORE_CONTROL_RETRY);
	}
	ex_log("Connected to CORE daemon on port %d - %s",
		CORE_API_PORT, ctime(&now->tv_sec));
	show_retry_msg = 1;
	add_core_conn(core_sock, CORE_CONNTYPE_CONTROL);
	send_exec_register(core_sock);
	return(0);
}

/*
 * Register this Execution Server with the CORE daemon.
 */
int
send_exec_register(s)
int s;
{
	uint8_t buf[255];
	const uint8_t name[] = "coreexecd\0";
	int len, hdr_len, flags = 0;

	hdr_len = len = core_api_create_message(buf, CORE_API_REG_MSG, flags,
						0, NULL);
	len += core_api_create_tlv(&buf[len], CORE_TLV_REG_EXECSRV,
				   sizeof(name), (uint8_t *)name);
	core_api_message_set_length(buf, len - hdr_len);

	return send(s, buf, len, 0);
}


/*
 * Send a repsponse message for spawning an interactive terminal.
 */
int
send_exec_terminal(s, node_id, exec_num, cmd)
int s;
uint32_t node_id;
uint32_t exec_num;
uint8_t *cmd;
{
	uint8_t buf[512], term_cmd[255];
	int len, hdr_len, flags = 0;

	/* We don't use cmd string, which usually contains "bash", since
	 * 'vzctl exec 1001 bash' will not work.
	 */
	flags = CORE_API_TTY_FLAG;
	hdr_len = len = core_api_create_message(buf, CORE_API_EXEC_MSG, flags,
						0, NULL);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NODE, node_id);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NUM, exec_num);
	len += core_api_create_tlv(&buf[len], CORE_TLV_EXEC_CMD,
			           strlen((char *)cmd), cmd);
	snprintf((char *)term_cmd, sizeof(term_cmd), "/usr/sbin/vzctl enter %u",
		 vznum(node_id));
	len += core_api_create_tlv(&buf[len], CORE_TLV_EXEC_RESULT,
				   strlen((char *)term_cmd), term_cmd);
	core_api_message_set_length(buf, len - hdr_len);

	return send(s, buf, len, 0);
}


/*
 * Check for data waiting on FIFO
 */
int
check_exec_output(e)
struct exec_queue_entry *e;
{
	int err;
	fd_set read_fdset;
	struct timeval to;

	if (e->exec_fd <= 0)
		return(0);

	FD_ZERO(&read_fdset);
	FD_SET(e->exec_fd, &read_fdset);
	bzero(&to, sizeof(to)); /* don't block */

	err = select(e->exec_fd + 1, &read_fdset, NULL, NULL, &to);
	/* return true if there is data to read */	
	return(err == 1);
}

/*
 * Handle FIFO execution output activity
 */
int
receive_exec_output(control_sock, fd, e)
int control_sock;
int fd;
struct exec_queue_entry *e;
{
	int len, min_len, flags;
	uint8_t buf[EXEC_DEFAULT_BUF_SIZE];
	struct exec_queue_entry *prev=NULL;
	int do_delete = 1;

	len = sizeof(buf);
	flags = 0;
	bzero(buf, len);
	if (fd < 0) /* this may be called from del_exec_queue - prevent loop */
		do_delete = 0;

	/* if not supplied, get exec queue entry based on descriptor */
	if (e)
		fd = e->exec_fd;
	else
		e = find_exec_queue(fd, &prev);
	if (!e)
		return(-1); /* what job is this? */

	len = read(fd, (char *)buf, len); /* this should be non-blocking */
	if (len < 0) {
		ex_log("read() error(%d): %s fd=%d\n",
			errno, strerror(errno), fd);
		if (do_delete) del_exec_queue(control_sock, e, prev);
		return(-1);
	} else if (len == 0) { /* socket closed */
	/*	ex_log("node %u job %u socket closed, deleting from queue\n",
		       e->exec_node_id, e->exec_id); // */
		if (do_delete) del_exec_queue(control_sock, e, prev);
		return(-1);
	}

	min_len = e->exec_result_len + len + 1;
	if (min_len > e->exec_result_buf_len) {
		if (grow_exec_item_result(e, min_len) < 0) {
			ex_log("malloc() error\n");
			return(-1);
		}
	}
	memcpy(&e->exec_result[e->exec_result_len], buf, len);
	e->exec_result_len += len;
	e->exec_result[e->exec_result_len] = '\0';
	
	/*
	ex_log("got %d bytes from pid %u, job: ", len, e->exec_pid);;
	log_queue_entry(e);
	ex_log("\n");
	*/

	queue_entry_check_status(e);
	return(0);
}

/*
 * Check the status of the child process. Update exec_status if the process
 * is done.
 */
void
queue_entry_check_status(e)
struct exec_queue_entry *e;
{
	int status, err;
	if (!e)
		return;
/*	ex_log("node %u job %u pid %d check status\n",
		e->exec_node_id, e->exec_id, e->exec_pid); // */
	if (e->exec_pid <= 0)
		return;
	err = waitpid(e->exec_pid, &status, WNOHANG);
/*	ex_log("node %u job %u waitpid %d status=0x%x ret=%d\n",
		e->exec_node_id, e->exec_id, e->exec_pid, status, err); // */
	if (WIFEXITED(status)) { /* this causes the results to be sent back */
/*		if (verbose_debug)
			ex_log("queue_entry_check_status(): pid %d exited "
			       "with %d status %d->RESULTS\n", e->exec_pid,
				WEXITSTATUS(status), e->exec_status); // */
		e->exec_status = CORE_EXEC_STATUS_RESULTS;
		e->exec_exit_status = WEXITSTATUS(status);
		e->exec_pid = -1; /* done with this pid */
	}
}

/*
 * Handle CORE API socket activity
 */
int
receive_core(conn)
struct core_conn *conn;
{
	int len, buff_len_remain, flags, type, err=0;
	socklen_t addr_len;
	uint8_t *bufp;
	struct sockaddr_in addr;
	uint16_t msg_len;
	int s;

	if (!conn)
		return(-1);
	s = conn->sock;

	/* Allocate a new receive buffer or continue with existing buffer */
	bufp = get_core_conn_recv_buff(conn, 4096);
	if (!bufp) return(-1);
	buff_len_remain = conn->recv_buff_len - conn->recv_len;

	flags = 0;
	addr_len = sizeof(addr);
	len = recvfrom(s, (char *)bufp, buff_len_remain, flags,
		       SA(&addr), &addr_len);
	if (len < 0) {
		ex_log("recvfrom() error(%d): %s\n", errno, strerror(errno));
		return(-1);
	} else if (len == 0) { /* socket closed */
		ex_log("recvfrom() socket closed\n");
		return(-1);
	}
	/* ex_log("exec receive_core(): %d bytes\n", len); // */

	conn->recv_len += len;
	bufp = &conn->recv_buff[0]; /* look at start of receive buffer */
	while (conn->recv_len > 0) {
		/* parse CORE API message header */
		err = 0;
		msg_len = conn->recv_len;
		type = core_api_parse_message(bufp, &msg_len);
		if (type == -3) {
			/* Don't free the receive buffer, but allow more data
			 * to accumulate next time. */
			ex_log("receive_core(): truncated message at %d bytes, "
			       "waiting for more data\n", conn->recv_len);
			/* If we are in the middle of the buffer, move data
			 * to the start in preparation for the next read. */
			core_conn_reset_recv_buff(conn, bufp);
			return(0);
		} else if (type < 0) {
			ex_log("receive_core(): bad message, %d bytes "
				"discarded\n", conn->recv_len);
			break;
		}
		/* handle only CORE API Execute messages */
		switch (type) {
		case CORE_API_EXEC_MSG:
			err = receive_exec_msg(s, bufp, msg_len);
			break;
		case CORE_API_FILE_MSG:
			err = receive_file_msg(s, bufp, msg_len);
			break;
		default:
			err = -1;
			ex_log("warning: CORE API message type %d ignored "
				"by execution server.\n", type);
		}
		/* advance ptr */
		msg_len += sizeof(struct core_api_msg);
		bufp += msg_len;
		conn->recv_len -= msg_len;
		if (conn->recv_len < 0) {
			err = 0; /* don't hangup connection */
			ex_log("receive_core(): overflow %d %d\n", 
				conn->recv_len, msg_len);
			break;
		} else if (err < 0) {
			err = 0; /* don't hangup connection */
			ex_log("receive_core(): message type %d error\n", type);
			break;
		}
	}
	
	/* Here we are done with the receive buffer, so free it.
	 */
	core_conn_reset_recv_buff(conn, NULL);
	return(err);
}

/*
 * Parse a CORE API Execute message and put it into the execution queue.
 */
int
receive_exec_msg(core_sock, buf, length)
int core_sock;
uint8_t *buf;
uint16_t length;
{
	struct core_api_tlv *tlv;
	uint32_t node_id, exec_id, exec_time;
	uint8_t flags, cmd_str[255];
	memset(cmd_str, 0, sizeof(cmd_str));

	flags = core_api_message_get_flags(buf);

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_NODE);
	if (core_api_get_tlv_val32(tlv, &node_id) < 0)
		return(-1); /* node number is required */

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_NUM);
	if (core_api_get_tlv_val32(tlv, &exec_id) < 0)
		return(-1);

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_TIME);
	core_api_get_tlv_val32(tlv, &exec_time); /* default time is zero */ 

	tlv = core_api_get_tlv(buf, CORE_TLV_EXEC_CMD);
	if (!tlv)
		return(-1);
	if (core_api_get_tlv_string(tlv, cmd_str, sizeof(cmd_str)) < 0)
		return(-1);

	/* special exec message requests interactive terminal
	 * don't add to exec queue, but reply with terminal command */
	if (flags & CORE_API_TTY_FLAG)
		return(send_exec_terminal(core_sock, node_id, exec_id,
					  cmd_str));

	return(add_exec_queue(flags, node_id, exec_id, exec_time, cmd_str));

	return(0);
}

/*
 * Parse a CORE API File message and perform file creation.
 */
int
receive_file_msg(core_sock, buf, length)
int core_sock;
uint8_t *buf;
uint16_t length;
{
	struct core_api_tlv *tlv;
	uint8_t flags, is_local_file=1;
	char cmd_str[278], filename[270], tmp[255], *tlv_data;
	uint32_t node_id=0;
	uint16_t tlv_len;
	int err=0, len;
	FILE *fp;

	flags = core_api_message_get_flags(buf);

	/* Write a local file, unless the Node TLV is present. */
	tlv = core_api_get_tlv(buf, CORE_TLV_FILE_NODE);
	if (tlv) {
		is_local_file = 0;
		core_api_get_tlv_val32(tlv, &node_id);
	}

	/* File name is required */
	tlv = core_api_get_tlv(buf, CORE_TLV_FILE_NAME);
	if (!tlv)
		return(-1);
	if (core_api_get_tlv_string(tlv, (uint8_t *)tmp, sizeof(tmp)) < 0)
		return(-1);
	if (is_local_file) /* use pathname as is */
		strncpy(filename, tmp, sizeof(filename));
	else	/* use container private area as pathname */
		err = snprintf(filename, sizeof(filename), "/vz/private/%u%s",
			       vznum(node_id), tmp);
	if (err >= sizeof(filename)) {
		if (verbose_debug)
			ex_log("Node %u file '%s' pathname was truncated.\n",
			       vznum(node_id), filename);
		return(-1);
	}

	/* Delete a file */
	if (flags & CORE_API_DEL_FLAG) {
		if (verbose_debug) ex_log("Removing file '%s'\n", filename);
		err = unlink(filename);
		if (verbose_debug && (err < 0))
			ex_log("Error removing file '%s': %s\n", filename,
			       strerror(errno));
		/* we could also delete a file using 'vzctl exec %u rm %s',
		 * but this should be faster and doesn't require that the node
		 * be running */
		return(0);
	}

	/* Local file copy - queue up a cp command */
	tlv = core_api_get_tlv(buf, CORE_TLV_FILE_SRCNAME);
	if (tlv) {
		if (core_api_get_tlv_string(tlv, (uint8_t *)tmp, 
		    sizeof(tmp)) < 0)
			return(-1);
		err = snprintf(cmd_str, sizeof(cmd_str), "/bin/cp -f %s %s",
			       tmp, filename);
		if (err >= sizeof(cmd_str)) {
			if (verbose_debug)
				ex_log("Copy file '%s' to '%s' command was "
				       "truncated.\n", tmp, filename);
			return(-1);
		}
		flags = CORE_API_LOC_FLAG;
		return(add_exec_queue(flags, node_id, local_exec_id++, 
				      0, (uint8_t*)cmd_str));
	}
	/* File data included in message. */		
	tlv = core_api_get_tlv(buf, CORE_TLV_FILE_DATA);
	if (!tlv) { /* gzip compression; for now just use gzip -d */
		tlv = core_api_get_tlv(buf, CORE_TLV_FILE_CMPDATA);
		strncat(filename, ".gz", sizeof(filename) - 1);
	}
	if (tlv) {
		tlv_len = core_api_get_tlv_length(tlv);
		tlv_data = (char *) &tlv->value[ (tlv->length==0) ? 2 : 0 ];
		fp = fopen(filename, (flags & CORE_API_ADD_FLAG) ? "w" : "a");
		if (!fp) {
			if (verbose_debug) ex_log("Error writing file "
				"%s: %s\n", filename, strerror(errno));
			return(-1);
		}
		len = fwrite(tlv_data, 1, tlv_len, fp);
		fclose(fp);
		if ((len < 0) && verbose_debug) {
			ex_log("error writing file %s\n");
			return(-1);
		}
		if (tlv->type == CORE_TLV_FILE_CMPDATA) {
			snprintf(cmd_str, sizeof(cmd_str), "/sbin/gzip -d %s",
				 filename);
			flags = CORE_API_LOC_FLAG;
			return(add_exec_queue(flags, node_id, local_exec_id++,
					      0, (uint8_t*)cmd_str));
		}
	} else if (verbose_debug) {
		ex_log("file message is missing file data for file %s\n",
		       filename);
		return(-1);
	}

	return(0);
}


/*
 * Send a CORE API Execute message with results from the execution queue.
 */
int
send_exec_msg(s, e)
int s;
struct exec_queue_entry *e;
{
	int buf_len, len, hdr_len, err;
	uint8_t *buf;
	uint32_t val32;

	if (!e)
		return(-1);

/*	if (verbose_debug)
		ex_log("send_exec_msg(): result_len=%d status %d->DONE\n",
		       e->exec_result_len, e->exec_status); // */
	if (e->exec_status == CORE_EXEC_STATUS_DONE)
		return(0); /* results already sent */
	/* this should be the only place status is changed to done... */
	e->exec_status = CORE_EXEC_STATUS_DONE;
	if (e->exec_result_len < 1)
		return(0); /* no results */
	/* allocate a little extra buffer space for padding */
	buf_len = sizeof(struct core_api_msg) + 4*sizeof(struct core_api_tlv) + 
			6*sizeof(uint32_t) + e->exec_result_len + 8;
	if (e->exec_flags & CORE_API_STR_FLAG)
		buf_len += sizeof(struct core_api_tlv) + 2 + sizeof(uint32_t);
	buf = malloc(buf_len);
	if (!buf)
		return(-1); /* malloc error */

	hdr_len = len = core_api_create_message(buf, CORE_API_EXEC_MSG,
						e->exec_flags, 0, NULL);

	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NODE,
				     e->exec_node_id);
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_NUM,
				     e->exec_id);
	/* assume result time has already been updated... */
	len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_TIME,
				     e->exec_time);
	/* TODO: does e->exec_result_len exceed max? */
	len += core_api_create_tlv(&buf[len], CORE_TLV_EXEC_RESULT,
				   e->exec_result_len, e->exec_result);
	if (verbose_debug) {
		ex_log("node %u job %u sending result(%d):\n%s\n",
		       e->exec_node_id, e->exec_id, e->exec_result_len,
		       e->exec_result);
		
	}
	if (e->exec_flags & CORE_API_STR_FLAG) {
		val32 = (uint32_t) e->exec_exit_status;
		len += core_api_create_tlv32(&buf[len], CORE_TLV_EXEC_STATUS,
					     val32);
	}

	core_api_message_set_length(buf, len - hdr_len);
	err = send(s, buf, len, 0);
	if (err < 0)
		ex_log("send_exec_msg(): send() error: %s\n", strerror(errno));
	free(buf);
	return(err);
}

int
add_exec_queue(flags, node_id, exec_id, exec_time, cmd_str)
uint8_t  flags;
uint32_t node_id;
uint32_t exec_id;
uint32_t exec_time;
uint8_t *cmd_str;
{
	struct exec_queue_entry *e, *prev=NULL;
	int cmd_len;

	if (verbose_debug)
		ex_log("adding node %u job %u to the exec queue:\n\t'%s'\n",
		       node_id, exec_id, cmd_str);

	/* locate previous queue entry, if any */
	for (e = exec_queue; e; e = e->next) {
		if (e->exec_id == exec_id) {
			if (verbose_debug)
				ex_log("ignoring duplicate job %u\n", exec_id);
			return(-1); /* duplicate IDs not allowed! */
		}
		if (e->exec_time > exec_time)
			break;
		prev = e;
	}

	/* allocate a new queue item */
	cmd_len = strlen((char *)cmd_str) + 1; /* include NULL byte */
	e = (struct exec_queue_entry*) malloc(sizeof(struct exec_queue_entry));
	if (!e) return(-1); /* ENOMEM */
	e->exec_cmd = malloc(cmd_len);
	if (!e->exec_cmd) return(-1); /* ENOMEM */
	e->exec_time = exec_time;
	e->exec_node_id = node_id;
	e->exec_id = exec_id;
	strcpy((char *)e->exec_cmd, (char *)cmd_str);
	e->exec_result = NULL;
	e->exec_result_buf_len = 0;
	e->exec_result_len = 0;
	e->exec_status = CORE_EXEC_STATUS_NONE;
	e->exec_exit_status = -1;
	e->exec_pid = 0;
	e->exec_fd = -1;
	e->exec_flags = flags;
	e->next = NULL;

	/* link it into the queue */
	if (!prev) { 	/* new queue head */
		e->next = exec_queue;
		exec_queue = e;
	} else {
		e->next = prev->next;
		prev->next = e;
	}
	return(0);
}

/*
 * Remove an entry from the execution queue. If the previous entry is supplied,
 * this prevents scanning the entire queue. The control socket is supplied for
 * sending any results waiting in the queue.
 */
int
del_exec_queue(control_sock, e, prev)
int control_sock;
struct exec_queue_entry *e;
struct exec_queue_entry *prev;
{
	struct exec_queue_entry *tmp, *start;
	int len;
	char filename[30];

	if (!e)
		return(-1);
	if (prev)
		start = prev;
	else
		start = exec_queue;

	/* exec_fd is closed when conn freed */
	/* search the entire queue when prev not specified */
	prev = NULL;
	for (tmp = start; tmp; tmp = tmp->next) {
		if (tmp->exec_id == e->exec_id)
			break;
		prev = tmp;
	}
	if (!tmp)
		return(-1); /* not found in queue */

	/* node is now free to execute other jobs */
	node_status[e->exec_node_id] = CORE_NODE_STATUS_NONE;
	if (openvz_check_ebtables(e) == 1) { /* ebtables lock release */
		if (openvz_ebtables_lock(2))
			ex_log("node %u job %u cleanup failed to unlock "
			       "ebtables\n", e->exec_node_id, e->exec_id);
	}

	/* delete from queue */
	if (prev)
		prev->next = tmp->next;
	else
		exec_queue = tmp->next;

	/* should we send KILL? */
	queue_entry_check_status(tmp);

	/* read and send any available output data */
	if (check_exec_output(tmp))
		receive_exec_output(control_sock, -1, tmp);
	len = tmp->exec_result_len;
	send_exec_msg(control_sock, tmp);

	/* cleanup, destroy */
	if (verbose_debug) {
		ex_log("node %u cleaning up job number %u (status %d result "
		       "len %d)\n", tmp->exec_node_id, tmp->exec_id,
		       tmp->exec_exit_status, len);
		if ((tmp->exec_exit_status != 0) && (tmp->exec_result_len > 0))
			ex_log("node %u job %u result text: %s\n",
			       tmp->exec_node_id, tmp->exec_id,
			       tmp->exec_result);
	}
	sprintf(filename, "/tmp/coreexecd.%u", tmp->exec_id);
	unlink(filename);
	if (tmp->exec_cmd)
		free(tmp->exec_cmd);
	if (tmp->exec_result)
		free(tmp->exec_result);

	bzero(tmp, sizeof(tmp));
	free(tmp);
	return(0);
}

/*
 * Locate an execution queue entry given its file descriptor. Optionally return
 * the previous queue entry.
 */
struct exec_queue_entry *
find_exec_queue(fd, prev)
int fd;
struct exec_queue_entry **prev;
{
	struct exec_queue_entry *e;

	if (prev)
		*prev = NULL;
	for (e = exec_queue; e; e = e->next) {
		if (e->exec_fd == fd)
			break; /* found */
		if (prev)
			*prev = e;
	}
	return(e); /* may be NULL, not found */
}

void
log_queue_entry(e)
struct exec_queue_entry *e;
{
	if (!e) {
		ex_log("<null>");
		return;
	}
	ex_log("(time: %u, node: %u, execid: %u, cmd='%s', result=(%d bytes), "
		"status=%d, pid=%u, fd=%d)", e->exec_time, e->exec_node_id,
		e->exec_id, e->exec_cmd, e->exec_result_len, e->exec_status,
		e->exec_pid, e->exec_fd);
}

/*
 * Run jobs on the queue. This function may modify the queue and/or the
 * connection list.
 */
void
process_exec_queue(now, control_sock)
struct timeval *now;
int control_sock;
{
	struct exec_queue_entry *e, *prev;
	struct core_conn *conn;
	int do_cleanup = 0, count = 0, r;

#if 0
	for (e = exec_queue; e; e = e->next) {
		if (strncmp((char *)e->exec_cmd, "/sbin/ebtables", 14) != 0)
			continue;
		count++;
	}
	if (verbose_debug && (count > 0))
		ex_log("%d ebtables jobs in execution queue at %s",
		       count, now ? ctime(&now->tv_sec) : "<null>\n" );
	count = 0;
#endif

	for (e = exec_queue; e; e = e->next) {
		count++;
		queue_entry_check_status(e); /* update status if pid */
		switch(e->exec_status) {
		case CORE_EXEC_STATUS_NONE:
			/* start a maximum number of jobs here? */
			if (now->tv_sec < e->exec_time)
				continue; /* not time yet */
			if (node_status[e->exec_node_id] == 
				CORE_NODE_STATUS_BUSY) {
/*				if (verbose_debug)
					ex_log("node %u busy, deferring job "
					       "%u\n", e->exec_node_id,
					       e->exec_id);*/
				continue; /* node is busy running another job */
			} else if (check_openvz_lock(e)) {
/*				if (verbose_debug)
					ex_log("node %u locked, deferring job "
					       "%u\n", e->exec_node_id,
					       e->exec_id); */
				continue; /* node is locked */
			}
			r = openvz_check_ebtables(e);
			if (r == 2) { /* batch process elsewhere */
				continue;
			} else if ((r == 1) && (openvz_ebtables_lock(0))) {
				if (verbose_debug)
					ex_log("node %u ebtables locked, defer"
					       "ring job %u\n", e->exec_node_id,
					       e->exec_id);
				continue; /* node is locked */
			}
			run_exec_item(e);
			break;
		/* This is for sending real-time results, but this fn needs
		 * to be modified to NOT change the status to DONE */
/*		case CORE_EXEC_STATUS_RESULTS:
			send_exec_msg(control_sock, e);
			break;
*/
		case CORE_EXEC_STATUS_DONE:
			do_cleanup = 1;
			break;
		case CORE_EXEC_STATUS_RUNNING:
		default:
			break;
		}
	}

	if (verbose_debug && (count > 0))
		ex_log("%d jobs in execution queue at %s",
		       count, now ? ctime(&now->tv_sec) : "<null>\n" );

	if (!do_cleanup)
		return;
	/* after we're done processing the queue, go back for cleanup */
	prev = NULL;
	for (e = exec_queue; e; e = e->next) {
		/* log_queue_entry(e); */ /* debug */
		/* this modifies the queue, so we only delete one item; if there
		 * are more entries to prune, just get them next time */
		if (e->exec_status == CORE_EXEC_STATUS_DONE) {
			conn = find_core_conn(e->exec_fd, CORE_CONNTYPE_FIFO);
			if (conn) free_core_conn(conn);
			if (verbose_debug)
				ex_log("node %u job %u has status done, remov"
				       "ing it from the queue\n",
				       e->exec_node_id, e->exec_id);
			del_exec_queue(control_sock, e, prev);
			break;
		}
		prev = e;
	}
}

/*
 * Batch run certain ebtables jobs in the queue. 
 * This function may modify the queue and/or the connection list.
 */
int
process_ebtables_exec_queue(now, control_sock)
struct timeval *now;
int control_sock;
{
	struct exec_queue_entry *e, *prev, *next;
	int count = 0, error_count = 0;
	const char atomic_pathname[] = "/tmp/core.ebtables.tmp";
	int err;
	char cmd[255];

	/* save time by first checking the ebtables lock */
	if (openvz_ebtables_lock(0))
		return(0);

	/* count all ebtables commands in the queue
	 * exit if there are other pending ebtables jobs, because they
	 * may add and remove chains that we need
	 */
	for (e = exec_queue; e; e = e->next) {
		if (node_status[e->exec_node_id] == CORE_NODE_STATUS_BUSY)
			continue;
		/* check for ebtables jobs requiring batch processing */
		err = openvz_check_ebtables(e);
		if (err == 1) { /* other ebtables jobs take precedence here */
			ex_log("deferring ebtables jobs due to job %u at %s",
				e->exec_id, ctime(&now->tv_sec));
			return(0); /* there are other ebtables cmds to run... */
		} else 	if (err == 2) {
			count++;
		}
	}
	if (count == 0)
		return(0);
	if (verbose_debug)
		ex_log("%d ebtables jobs in execution queue at %s",
			count, ctime(&now->tv_sec));

	/* check the ebtables lock, and acquire it */
	if (openvz_ebtables_lock(1)) {
		ex_log("ebtables batch processing couldn't acquire the "
		       "ebtables lock\n");
		return(-1);
	}

	/* save the current ebtables kernel table */
	sprintf(cmd, "/sbin/ebtables --atomic-file %s --atomic-save",
		atomic_pathname);
	err = system(cmd);
	if (err != 0) {
		ex_log("warning: ebtables atomic save exited with %d\n", err);
	}
	prev = NULL;
	e = exec_queue;
	while (e) {
		next = e->next;
		if ((node_status[e->exec_node_id] == CORE_NODE_STATUS_BUSY) ||
		    (e->exec_status != CORE_EXEC_STATUS_NONE) ||
		    (openvz_check_ebtables(e) != 2)) {
			e = next;
			continue;
		}
		sprintf(cmd, "/sbin/ebtables --atomic-file %s %s",
			atomic_pathname, &e->exec_cmd[15]);
		err = system(cmd);
		if (err != 0) error_count++;
		e->exec_exit_status = err;
		e->exec_status = CORE_EXEC_STATUS_DONE;
		ex_log("node %u job %u added to ebtables commit, removing "
		       "it from the queue\n", e->exec_node_id, e->exec_id);
		del_exec_queue(control_sock, e, prev);
		e = next;
	}
	ex_log("ebtables commit %d rules (%d rule errors)\n",
	       count, error_count);
	sprintf(cmd, "/sbin/ebtables --atomic-file %s --atomic-commit",
		atomic_pathname);
	err = system(cmd);
	if (err != 0) {
		ex_log("warning: ebtables atomic commit exited with %d\n", err);
	}
	unlink(atomic_pathname);
	openvz_ebtables_lock(2);

	return(count);
}

/*
 * Grow the result buffer of an execution queue entry.
 */
int
grow_exec_item_result(e, min_size)
struct exec_queue_entry *e;
int min_size;
{
	int new_size, n=1;
	uint8_t *old_result;

	/* grow the buffer by a factor of 2048 */
	do {
		new_size = EXEC_DEFAULT_BUF_SIZE * n;
		n++;
	} while (new_size < min_size);

	if (new_size <= e->exec_result_buf_len)
		return(0); /* already big enough */

	/* allocate the new buffer */
	old_result = e->exec_result;
	e->exec_result = malloc(new_size);
	if (!e->exec_result)
		return(-1); /* malloc() error */
	e->exec_result_buf_len = new_size;
	memset(e->exec_result, 0, new_size);

	/* preserve the old result in the new buffer */
	if (old_result) {
		memcpy(e->exec_result, old_result, e->exec_result_len);
		free(old_result);
	}
	return(0);
}

/*
 * Execute an entry from the execution queue. This forks a child process that
 * reassigns stdout/stderr to a fifo.
 */
int
run_exec_item(e)
struct exec_queue_entry *e;
{
	char filename[30];
	int fd, flags;
	pid_t pid;
	uint32_t node_id;
	char cmd[512];
	mode_t mode;

	if (!e) return(-1);
	
	node_id = e->exec_node_id;
	if (verbose_debug)
		ex_log("node %u starting job=%u (flags=0x%x)\n", node_id,
		       e->exec_id, e->exec_flags);

	/* kill existing process */
	if (e->exec_flags & CORE_API_DEL_FLAG) {
		// TODO: delete a process here
		return(0);
	/* job is for local execution */
	} else if (e->exec_flags & CORE_API_LOC_FLAG) {
		/* ebtables lock acquisition */
		if ((openvz_check_ebtables(e) > 0) && openvz_ebtables_lock(1)) {
			ex_log("node %u failed to lock ebtables\n", node_id);
			return(-1);
		}
		node_status[node_id] = CORE_NODE_STATUS_BUSY;
		node_id = -1;
	}

	strncpy(cmd, (char *)e->exec_cmd, sizeof(cmd));
	sprintf(filename, "/tmp/coreexecd.%u", e->exec_id);
	mkfifo(filename, S_IRUSR | S_IWUSR);
	flags = O_RDONLY | O_NONBLOCK;
	fd = open(filename, flags);
	if (fd < 0) {
		ex_log("warning: open(%s) error: %s\n", filename, 
			strerror(errno));
		return(-1);
	}
	if (verbose_debug)
		ex_log("node %u created %s pipe %s\n", e->exec_node_id,
		       (node_id == -1) ? "local": "node", filename);

	pid = fork();

	/* child process */
	if (pid == 0) {
		close(fd);
		flags = O_CREAT | O_TRUNC | O_WRONLY;
		mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
		fd = open(filename, flags, mode);
		if (fd < 0) {
			perror("child open()");
		}
		if (verbose_debug)
			ex_log("child running, opened pipe %s with cmd="
			       "\n\t'%s'\n", filename, cmd);
		dup2(fd, fileno(stdout)); /* replace stdout */
		close(fd); /* close original, it has been duplicated */
		if (!verbose_debug) { /* errors go to parent */
			dup2(fd, fileno(stderr)); /* replace stderr */
			close(fd); /* close original, it has been duplicated */
		}
		do_child(node_id, cmd);
		return(0); /* shouldn't get here */
	}

/*	if (verbose_debug)
		ex_log("node %u job %u pid %d status %d->RUN\n",
		       e->exec_node_id, e->exec_id, pid, e->exec_status); // */
	e->exec_pid = pid;
	e->exec_status = CORE_EXEC_STATUS_RUNNING; /* child is running */
	e->exec_fd = fd;
	add_core_conn(fd, CORE_CONNTYPE_FIFO);
	return(0);
}

/*
 * This routine is executed by the child process. It switches to the vimage
 * based on the given node number, and passes control onto the given command.
 */
void
do_child(node_id, cmd_str)
uint32_t node_id;
char *cmd_str;
{
	int argc=0;
	char *args[32], *cmd, *p, node_str[8];
	char vzctl_bin[] = "/usr/sbin/vzctl\0", vzctl_cmd[] = "exec\0";

	/* TODO:  vz_chroot(), vz_env_create_ioctl() */

	bzero(args, sizeof(args));
	/* command is executed locally if special node_id is used */
	if (node_id != -1) {
		sprintf(node_str, "%u", vznum(node_id));
		args[argc++] = vzctl_bin;
		args[argc++] = vzctl_cmd;
		args[argc++] = node_str;
	}
	/* build array of null-terminated strings; spaces separate arguments
	 * and quoting is not supported here */
	cmd = (char *)cmd_str;
	if (cmd_str[strlen(cmd_str)-1] == ' ') /* ending space causes problems*/
		cmd_str[strlen(cmd_str)-1] = '\0';
	args[argc++] = cmd;
	/* this has the side effect of cmd_str ending with ' ' will have an
	 * extra NULL argument... may want to detect and fix that
 	 */
	p = index(cmd, ' ');
	while (p && (argc < 32)) {
		*p = '\0';	/* NULL-terminate this argument */
		args[argc++] = ++p;
		p = index(p, ' ');
	}
	/* fprintf(stderr, "going to execute '%s' with %d arguments\n",
		args[0], argc); // */
	execvp(args[0], args);
	/* not reached, unless execlp error */
	ex_log("execvp error(%d): %s\n", errno, strerror(errno));
	exit(1);
}


/*
 * Returns 1 if the /vz/lock/nnnn.lck file exists for the given node
 * (i.e. during node creation), and 0 otherwise.
 */
int
check_openvz_lock(e)
struct exec_queue_entry *e;
{
	int err;
	char path[255];
	struct stat st;

	if (!e) return(0);

	snprintf(path, sizeof(path), "%s/%u.lck",
		 OPENVZ_LOCK_DIR, vznum(e->exec_node_id));
	err = stat(path, &st);

	if (err < 0)
		return(0);
	if (S_ISREG(st.st_mode))
		return(1);
	return(0);
}


/*
 * Returns 1 if the /tmp/core.ebtables.lck file exists and 0 otherwise.
 * The purpose of this function is to provide some locking with ebtables as
 * more than one ebtables command may not be run at once.
 * cmd: 0 = lock check, 1 = get lock, 2 = release lock
 */
int
openvz_ebtables_lock(cmd)
int cmd;
{
	int err, len;
	char path[255], buf[16];
	struct stat st;
	FILE *fp;

	snprintf(path, sizeof(path), "%s/core.ebtables.lck", OPENVZ_LOCK_DIR);
	
	if (cmd == 2) { /* release the ebtables lock */
		err = unlink(path);
		if (err < 0)
			return(1);
		else
			return(0);
	}
	
	/* check if the ebtables lock exists */
	err = stat(path, &st);
	if ((err < 0) && (cmd == 0))
		return(0);	/* lock check only - not locked */
	if (S_ISREG(st.st_mode))
		return(1);	/* lock already exists */
	if (cmd != 1)
		return(0);	/* lock check only - not locked */

	/* acquire the ebtables lock */
	fp = fopen(path, "w");
	if (!fp) {
		ex_log("error writing ebtables lock file '%s'\n", path);
		return(1);
	}
	sprintf(buf, "locked");
	len = strlen(buf);
	if (fwrite(buf, 1, len, fp) != len)
		ex_log("Warning: couldn't write to ebtables lock file\n");
	fclose(fp);
	return(0);
}


/*
 * Returns 1 if this is an ebtables job and 2 if it is one that should be
 * batch processed using the --atomic-file parameter (these are insert/delete
 * commands having the veth1***.* strings.) Returns 0 for other commands.
 */
int
openvz_check_ebtables(e)
struct exec_queue_entry *e;
{
	char *cp;

	if (!e || !e->exec_cmd)
		return(0);
	/* ebtables commands can only be local commands */
	if (!(e->exec_flags & CORE_API_LOC_FLAG))
		return(0);
	/* only check ebtables commands */
	if (strncmp((char *)e->exec_cmd, "/sbin/ebtables", 14) != 0)
		return(0);

	/* example command strings:
	 * /sbin/ebtables -I FORWARD --logical-out vzbrn13 -j vzbrn13
	 *    (return 1 -- don't batch process this command)
	 * /sbin/ebtables -I vzbrn13 -i veth1000.0 -o veth1004.0 -j ACCEPT
	 *    (return 2 -- batch process this command)
	 */

	/* check insert/delete commands for veth1***.* */
	/* assume command -I/-D is always at this fixed location */
	if (e->exec_cmd[16] == 'I' || e->exec_cmd[16] == 'D') {
		/* look for string veth1*** after byte 28  */
		if ((cp = strchr( (char *)&e->exec_cmd[28], 'v'))) {
			if (strncmp(cp, "veth1", 5) == 0)
				/* this ebtables job needs batch processing */
				return(2); 
		}
	}
	return(1); /* this is an ebtables job */
}

/*
 * Print or log messages.
 */
void
ex_log(char *fmt, ...)
{
	va_list ap;
	
	va_start(ap, fmt);
	vfprintf(stdout, fmt, ap);
	va_end(ap);
	fflush(stdout);
}

/*
 * Open log file.
 */
int
ex_open_log(filename, opts)
char *filename;
int opts;
{
	if (!freopen("/dev/null", "r", stdin))
		return(-1);

	if (!freopen(filename, (opts == 1) ? "a" : "w", stdout))
		return(-1);

	if (!freopen(filename, "a", stderr)) /* /dev/null ? */
		return(-1);

	return(0);
}

/*
 * Close log file.
 */
void
ex_close_log()
{
	fflush(stdout);
	fflush(stderr);
	fclose(stdout);
	fclose(stderr);
}

/*
 * Write PID to PID file, unless it already exists.
 */
int
ex_write_pid(filename, pid)
char *filename;
pid_t pid;
{
	char buf[16];
	FILE *fp;
	int len;

	fp = fopen(filename, "r");
	if (fp) {
		len = sizeof(buf);
		bzero(buf, len);
		if (fread(buf, len, 1, fp) == 0)
			fprintf(stderr, "Warning: unable to read PID file.\n");
		buf[strlen(buf) - 1 ] = '\0';
		fprintf(stderr, "CORE execution server already running (%s), "
			"or PID file '%s' needs to be removed.\n",
			buf, filename);
		fclose(fp);
		return(-1);
	}

	if (pid == 0) /* don't write a file, just check */
		return(0);

	fp = fopen(filename, "w");
	if (!fp) {
		fprintf(stderr, "Error opening PID file '%s' - %s, quitting.\n",
			filename, strerror(errno));
		return(-1);
	} else {
		sprintf(buf, "%d\n", pid);
		len = strlen(buf);
		if (fwrite(buf, 1, len, fp) != len)
			fprintf(stderr, "Warning: unable to write to PID "
				"file.\n");
		fclose(fp);
	}

	return(0);
}

/*
 * Signal handler for program termination.
 */
void
exec_signal_ignore(signal)
int signal;
{
	ex_log("\n(ignoring signal %d)\n");
}

/*
 * Signal handler for status debugging.
 */
void
exec_signal_debug(signal)
int signal;
{
	int count=0;
	struct timeval t;
	struct exec_queue_entry *e;

	gettimeofday(&t, NULL);
	ex_log("\n----- CORE Execution server debug ----- %s",
	       ctime(&t.tv_sec));
	if (exec_queue)
		ex_log("Current jobs in exec queue:\n");
	for (e = exec_queue; e; e = e->next) {
		log_queue_entry(e);
		count++;
	}
	ex_log("----- %d jobs total -----\n", count);
}

/*
 * Signal handler for program termination.
 */
void
exec_terminate(signal)
int signal;
{
	struct timeval t;

	gettimeofday(&t, NULL);
	ex_log("\nCORE execution server shutting down (with signal %d%s) - "
		"%s\n", signal, 
		signal==SIGHUP ? " SIGHUP" :
		signal==SIGINT ? " SIGINT" :
		signal==SIGTERM ? " SIGTERM" :
		signal==SIGSEGV ? " SIGSEGV" : "",
		ctime(&t.tv_sec)
		);
	free_core_conns();
	ex_close_log();
	unlink(EXEC_DEFAULT_PID);
	exit(signal);
}
