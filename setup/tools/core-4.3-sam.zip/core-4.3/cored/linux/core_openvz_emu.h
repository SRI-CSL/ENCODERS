/*
 * CORE
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * core_openvz_emu.h
 * 
 */

#ifndef CORE_OPENVZ_EMU_H
#define CORE_OPENVZ_EMU_H

#define OPENVZ_NODENUM 1000
#define vznum(a) (OPENVZ_NODENUM + a)

#define OPENVZ_CONF_DIR "/etc/vz/conf"
#define OPENVZ_LOCK_DIR "/vz/lock"
/* #define OPENVZ_DEF_TEMPL "fedora-9-i386-minimal" */
#define OPENVZ_DEF_TEMPL "centos-5-i386-quagga"
#define OPENVZ_DEF_CONF "core" /* ve-core.conf-sample */

struct core_node;
struct core_node_data;
struct core_link;
struct core_link_data;
struct link_ifparams;

int  init_openvz_emulation();

int  openvz_init();
int  openvz_node(uint16_t flags, uint32_t node,
	struct core_node_data *data);
int  openvz_layer2_node(uint16_t flags, struct core_node *node);
int  openvz_link(uint16_t flags, uint32_t node1, uint32_t node2,
	struct core_link_data *data);
int  openvz_create_link(struct core_node *node1, struct core_node *node2,
	struct core_link_data *data);
int  openvz_set_link_params(struct core_node *, int, struct link_params *);
int  openvz_shutdown_link(struct core_link *link, struct core_node *node);
int  openvz_create_interface(struct core_node *node,
	struct link_ifparams *param);
int  openvz_link_wlan(struct core_link *link, struct core_node *n1, struct core_node *n2, int unlink);
int  openvz_ebtables(struct core_node *wlan, struct core_node *node1,
	int if1num, struct core_node *node2, int if2num, int delete);
int  openvz_iptables(struct core_node *node, int ifnum, 
	struct link_ifparams *ifp, int delete);
int  openvz_exec(uint16_t flags, uint32_t node_id, uint32_t exec_id, 
	uint32_t exec_time, uint8_t *exec_cmd, uint8_t *exec_resp,
	uint32_t exec_result);

#endif /* CORE_OPENVZ_EMU_H */
