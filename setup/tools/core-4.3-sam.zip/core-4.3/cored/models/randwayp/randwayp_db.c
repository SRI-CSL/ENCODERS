/* 
 * CORE
 * (c)2009 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Random waypoint node DB.
 */

#include <stdlib.h> /* malloc */
#include <stdio.h>  /* sprintf */
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>	/* timercmp() */
#include <sys/socket.h> /* for cored.h */
#include <inttypes.h>
#include <errno.h>	/* errno */

#include <cored.h> 
#include "randwayp.h"
#include "randwayp_db.h"

struct randwayp_net *randwayp_net_list;

void
init_randwayp_db()
{
	randwayp_net_list = NULL;
}

struct randwayp_net *get_randwayp_net(uint32_t net_id, struct randwayp_net **prev)
{
	struct randwayp_net *net;
	
	if (prev)
		*prev = NULL;
	for (net = randwayp_net_list; net; net = net->next) {
		if (net->net_id == net_id)
			return(net); /* found */
		if (prev)
			*prev = net;
	}
	return(NULL);
}

struct randwayp_net *new_randwayp_net(uint32_t net_id, struct randwayp_net *prev)
{
	struct randwayp_net *net;

	/* allocate and initialize */
	net = malloc(sizeof(struct randwayp_net));
	if (!net)
		return NULL;
	bzero(net, sizeof(struct randwayp_net));
	net->net_id = net_id;
	net->conf.min_x = 0;
	net->conf.min_y = 0;
	net->conf.max_x = 900; /* corresponds to gui_canvas_x */
	net->conf.max_y = 620; /* corresponds to gui_canvas_y */
	net->conf.velocity_min = 2.5;
	net->conf.velocity_max = 20.0;
	net->conf.wait_time_min = 1.0;
	net->conf.wait_time_max = 7.5;
	net->conf.start_time = 0;
	net->conf.stop_time = 0;
	net->conf.resolution = 0.4;
	net->node_list = malloc(sizeof(struct randwayp_node));
	bzero(net->node_list, sizeof(struct randwayp_node));

	/* link it to list */
	if (prev)
		prev->next = net;
	else
		randwayp_net_list = net;
	return(net);
}

void
flush_randwayp_nets()
{
	struct randwayp_net *net, *next_net;

	net = randwayp_net_list;
	while (net) {
		next_net = net->next;
		free_randwayp_net(net);
		net = next_net;
	}
	randwayp_net_list = NULL;
}

struct
randwayp_node *get_randwayp_node_list(uint32_t net_id)
{
	struct randwayp_net *net, *prev;

	net = get_randwayp_net(net_id, &prev);	
	if (!net) { /* net not found, add to the list */
		net = new_randwayp_net(net_id, prev);
		if (!net) return NULL;
	}

	return(net->node_list);
}

void
flush_randwayp_node_list(uint32_t net_id)
{
	struct randwayp_net *net, *prev;

	net = get_randwayp_net(net_id, &prev);
	if (!net) /* net not found */
		return;

	if (prev) prev->next = net->next;
	else randwayp_net_list = NULL;
	free_randwayp_net(net);
}

void
free_randwayp_net(struct randwayp_net *net)
{
	struct randwayp_node *node, *next_node;

	node = net->node_list;
	while (node) {
		next_node = node->next;
		free(node);
		node = next_node;
	}
	bzero(net, sizeof(struct randwayp_net));
	free(net);
}

struct
randwayp_node *find_randwayp_node(struct randwayp_net *net, uint32_t id)
{
	struct randwayp_node *n;
	for (n = net->node_list; n; n = n->next) {
		if (n->node_id == id)
			break;
	}
	return (n);
}

struct
randwayp_node *update_randwayp_node_db(uint32_t net, uint32_t id,
	uint32_t emuid, uint32_t x, uint32_t y)
{
	struct randwayp_node *node, *prev, *node_list;

	prev = NULL;
	node_list = get_randwayp_node_list(net);
	/* ASSERT(node_list) */
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) { /* not found - create new */
		/* emu_id==0 indicates no node (empty list) */
		if ((prev == node_list) && (node_list->emu_id==0)) { 
			/* first in list */
			node = node_list;
		} else {
			node = (struct randwayp_node *)
				malloc(sizeof(struct randwayp_node));
			if (!node) return(NULL);
			bzero(node, sizeof(struct randwayp_node));
			prev->next = node;
		}
		node->node_id = id;
		node->emu_id = emuid;
	}
	node->emu_id = emuid;
	node->x = (double)x;
	node->y = (double)y;
	node->dest_x = node->x;
	node->dest_y = node->y;
	node->speed_x = 0.0;
	node->speed_y = 0.0;
	return(node);
}

int
remove_randwayp_node_db(uint32_t net, uint32_t id)
{
	struct randwayp_node *node, *prev, *next, *node_list;

	prev = NULL;
	node_list = get_randwayp_node_list(net);
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) /* not found */
		return(-1);
	if (node == node_list) { /* don't delete the first node */
		if (node->next) {
			next = node->next;
			memcpy(node_list, next, sizeof(struct randwayp_node));
			bzero(next, sizeof(struct randwayp_node));
			free(next);
		} else {
			bzero(node_list, sizeof(struct randwayp_node));
		}
	} else {
		prev->next = node->next;
		bzero(node, sizeof(struct randwayp_node));
		free(node);
	}
	
	return(0);
}

void
debug_randwayp_db(int periodic)
{
	static char dbuf[1024] = { 0 };
	char buf[1024], tmp[16];
	struct randwayp_net *net;
	struct randwayp_node *node;
	
	bzero(buf, sizeof(buf));

	for (net = randwayp_net_list; net; net = net->next) {
		if (!net->node_list)
			continue;
		sprintf(tmp, "net 0x%x (", net->net_id);
		strncat(buf, tmp, sizeof(buf) - 1);
		for (node = net->node_list; node; node = node->next) {
			/*sprintf(tmp, "0x%x(%u,%u) ", node->node_id, 
				node->x, node->y);*/
			sprintf(tmp, "0x%x ", node->node_id);
			strncat(buf, tmp, sizeof(buf) - 1);
		}
		strncat(buf, ") ", sizeof(buf) - 1);
	}

	if (!periodic) {
		wl_log("randwayp_db: %s\n", buf);
		return;
	}

	/* only print output when something has changed */
	if (strncmp(dbuf, buf, sizeof(dbuf))) { /* might be expensive */
		strncpy(dbuf, buf, sizeof(dbuf));
		wl_log("randwayp_db: %s\n", dbuf);
	}
}

