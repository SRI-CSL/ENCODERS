/* 
 * CORE
 * (c)2009 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Random waypoint implementation. 
 */
#include <stdio.h>
#include <stdlib.h>	/* abs() */
#include <strings.h>	/* bzero */
#include <string.h>	/* strlen() */
#include <sys/types.h>  /* for cored.h */
#include <sys/socket.h> /* for cored.h */
#include <sys/time.h>	/* gettimeofday() */
#include <time.h>	/* ctime() */
#include <math.h>	/* modff() */
#include <errno.h>	/* errno */
#include <netinet/in.h> /* htonl() in core_api.h */
#include <cored.h> 
#include <coreapi/coreapi.h> /* reqd for handling config messages */
#include <models/model.h>
#include "randwayp.h"
#include "randwayp_db.h"

struct core_wlan_model randwayp_model = {
	.model_name = "random_waypoint",
	.model_type = MODEL_TYPE_MOBILITY,
	.model_state = MODEL_STATE_UNINIT,
	.init = init_randwayp,
	.conf = config_randwayp,
	.flush = randwayp_flush_nodes,
	.update = randwayp_update_node,
	.remove = randwayp_remove_node,
	.periodic = randwayp_periodic,
	.debug = debug_randwayp,
	.link = link_nodes,	/* from cored */
	.unlink = unlink_nodes,	/* from cored */
	.model_next = NULL,
};

extern int control_sock;
extern struct randwayp_net *randwayp_net_list;

/* local functions */
int  randwayp_rand_seed(uint32_t seed);
int  randwayp_config_to_string(struct randwayp_net_config *c, uint8_t *to);
int  string_to_randwayp_config(uint8_t *, int, struct randwayp_net_config *);
void log_randwayp_config(struct randwayp_net_config *c);
int  link_randwayp_nodes(uint32_t net_id, struct randwayp_node *a, 
	struct randwayp_node *b, struct link_params *params);
int unlink_randwayp_nodes(uint32_t, struct randwayp_node *, uint32_t, uint32_t);
int  randwayp_move_nodes(struct randwayp_net *, struct timeval *);
void randwayp_new_destination(struct randwayp_net *, struct randwayp_node *);
void randwayp_new_velocity(struct randwayp_net *, struct randwayp_node *);
double random_double();


void
init_randwayp()
{
	init_randwayp_db();
	randwayp_model.model_state = MODEL_STATE_INIT;
	randwayp_rand_seed(0);

	wl_log("Random waypoint model loaded.\n");
}

int
randwayp_rand_seed(uint32_t seed)
{
	FILE *fp;
	int seed_with_time = 0;
	struct timeval now;

	if (seed > 0) {
		srandom(seed);
		return 0;
	}
	/* seed the random number generator */
	fp = fopen("/dev/urandom", "r");
	if (!fp) {
		seed_with_time = 1;
	} else {
		if (fread(&seed, sizeof(seed), 1, fp) != 1)
			seed_with_time = 1;
		fclose(fp);
	}

	if (seed_with_time) {
		wl_log("Random waypoint: error reading /dev/urandom, using"
			"time to seed the random number generator.\n");
		gettimeofday(&now, NULL);
		seed = now.tv_usec;
	}
	srandom(seed);
	return(seed_with_time);
}

int
config_randwayp(uint16_t flags, uint8_t *config_data, uint16_t config_len)
{
	struct randwayp_net *net, *net2, *prev;
	struct core_api_tlv *tlv;
	uint32_t wlan_node_num, wlan_id;
	uint16_t len = config_len;
	uint16_t types[10] = RANDWAYP_NET_DATA_INIT;
	uint8_t data[400], capt[135] = RANDWAYP_NET_CAPTIONS;
	int data_len;

	/* WLAN node number used as net id */
	core_api_parse_message(config_data, &len);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NODE);
	if (core_api_get_tlv_val32(tlv, &wlan_node_num) < 0)
		return(-1);

	/* use node ID to store config data */
	net = get_randwayp_net(wlan_node_num, &prev);	
	if (!net) { /* net not found, add new one to the list */
		net = new_randwayp_net(wlan_node_num, prev);
		if (!net) return -1;
	}

	/* receive node ID -> netgraph ID mapping and return */
	if (flags & CONF_TYPE_FLAGS_UPDATE) {
		/* use netgraph ID instead of node ID */
		tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NETID);
		if (core_api_get_tlv_val32(tlv, &wlan_id) < 0)
			return(-1);
		net2 = get_randwayp_net(wlan_id, &prev);	
		if (!net2) {
			net2 = new_randwayp_net(wlan_id, prev);
			if (!net2) return -1;
		}
		memcpy(&net2->conf, &net->conf, sizeof(net->conf));
		net->emu_id = net2->emu_id = wlan_id;
		gettimeofday(&net2->start_time, NULL);
		net2->start_time.tv_sec += net->conf.start_time;
		wl_log("Random waypoint will start for wlan 0x%x at time: %s",
			wlan_id, ctime(&net2->start_time.tv_sec));
		return(0);
	}

	/* provide configuration parameters and return */
	if (flags & CONF_TYPE_FLAGS_REQUEST) {	
		wl_log("Random waypoint model, handling config request for wlan"
			"%d...\n", wlan_node_num);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_DATA_TYPES, 
				sizeof(types), (uint8_t*)&types);
		data_len = randwayp_config_to_string(&net->conf, data);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_VALUES, 
				data_len, (uint8_t*)data);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_CAPTIONS, 
				strlen((char*)capt), capt);
		core_api_message_set_length(config_data, 
				len - sizeof(struct core_api_msg));
		wl_log("Sending the config: ");
		log_randwayp_config(&net->conf);
		wl_log("\n");		
		/* returns the length of bytes used in the new TLV */
		return len;
	}

	/* parse configuration parameters */
	wl_log("Random waypoint model, handling config data for wlan%d...\n",
		wlan_node_num);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_DATA_TYPES);
	if (!tlv) return(-1);
	if (memcmp(tlv->value, &types, sizeof(types))!=0) return(-1);

	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_VALUES);
	if (!tlv) return(-1);
	string_to_randwayp_config(tlv->value, tlv->length, &net->conf);

	wl_log("Accepted random waypoint config for wlan%d: ", wlan_node_num);
	log_randwayp_config(&net->conf);
	wl_log("\n");
	
	return 0;
}

/* convert the config struct to a '|' delimited string */
int
randwayp_config_to_string(struct randwayp_net_config *c, uint8_t *to)
{
	return sprintf((char*)to,
			"%u,%u|%u,%u|%.3f|%.3f|%.3f|%.3f|%.3f|%.3f|%.3f|%u",
			c->min_x, c->min_y, c->max_x, c->max_y,
			c->velocity_min, c->velocity_max, c->wait_time_min,
			c->wait_time_max, c->start_time, c->stop_time,
			c->resolution, c->random_seed);
}

/* convert the '|' delimited string to a config struct */
int
string_to_randwayp_config(uint8_t *from, int from_len, 
			struct randwayp_net_config *c)
{
	int ret;

	ret = sscanf((char *)from,
			"%u,%u|%u,%u|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%u",
			&c->min_x, &c->min_y, &c->max_x, &c->max_y,
			&c->velocity_min, &c->velocity_max, &c->wait_time_min,
			&c->wait_time_max, &c->start_time, &c->stop_time,
			&c->resolution, &c->random_seed);
	if (ret != 12) {
		wl_log("string_to_randwayp_config() warning: expected 12 items,"
		       " got %d\n", ret);
		return(-1);
	}
	return(0);
}

void
log_randwayp_config(struct randwayp_net_config *c)
{
	if (!c) {
		wl_log("<null>");
		return;
	}
	wl_log("[minx,y=%u,%u maxx,y=%u,%u vel %.3f-%.3f wait %.3f-%.3f "
		"start %.3f stop %.3f res %.3f seed %u]",
			c->min_x, c->min_y, c->max_x, c->max_y,
			c->velocity_min, c->velocity_max, c->wait_time_min,
			c->wait_time_max, c->start_time, c->stop_time,
			c->resolution, c->random_seed);
}

void
randwayp_flush_nodes(uint16_t flags, uint32_t net_id)
{
	if (flags & FLUSH_FLAGS_ALL_NODES)
		flush_randwayp_nets();
	else
		flush_randwayp_node_list(net_id);
}

int
randwayp_update_node (uint16_t flags, uint32_t net_id, uint32_t id,
	uint32_t emu_id, uint32_t x, uint32_t y) 
{
	struct randwayp_net *net;
	struct randwayp_node *node;

	wl_log("randwayp_update_node(net=%x, id=%x, emu=%x, %u, %u)\n",
		net_id, id, emu_id, x, y); // */
	node = update_randwayp_node_db(net_id, id, emu_id, x, y);
	if (!node)
		return(-1);

	net = get_randwayp_net(net_id, NULL);
	if (!net)
		return(-1);

	return(0);
}

int
randwayp_remove_node (uint32_t net_id, uint32_t id)
{
	int err = remove_randwayp_node_db(net_id, id);
	/* TODO: remove links */
	return(err);
}

void
randwayp_periodic(struct timeval *now)
{
	struct randwayp_net *net;
	struct timeval script_time;
	double script_timed;
	
	for (net = randwayp_net_list; net; net = net->next) {
		if (!net->emu_id ||  (net->node_list &&
			!net->node_list->next && !net->node_list->emu_id ))
			continue; /* emulation not started yet */
		timersub(now, &net->start_time, &script_time);
		TV2D(&script_time, script_timed);
		if ((net->conf.start_time > 0.0) && 
		    (script_timed < net->conf.start_time)) {
			wl_log("randwayp: not time for net %u (now=%.3f, "
				"start=%.3f)\n", script_timed,
				net->conf.start_time);
			continue; /* don't start moving nodes yet */
		}
		if ((net->conf.stop_time > 0.0) &&
		    (script_timed >= net->conf.stop_time)) {
			wl_log("randwayp: net %u is done (now=%.3f, "
				"start=%.3f)\n", script_timed,
				net->conf.stop_time);
			continue; /* we're done! */
		}
		randwayp_move_nodes(net, &script_time);
	}
}

void
debug_randwayp(int periodic)
{
	struct randwayp_net *net;
	uint8_t buf[512];

	debug_randwayp_db(periodic);
	if (periodic)
		return;

	/* more verbose debugging here */
	for (net = randwayp_net_list; net; net = net->next) {
		memset(buf, 0, sizeof(buf));
		randwayp_config_to_string(&net->conf, buf);
		wl_log("net %u: %s\n", net->net_id, buf);
	}

}

int
link_randwayp_nodes(uint32_t net_id, struct randwayp_node *a,
	struct randwayp_node *b, struct link_params *params)
{
	return(randwayp_model.link(net_id, a->node_id, b->node_id,
		a->emu_id, b->emu_id, params));
}

int
unlink_randwayp_nodes(uint32_t net_id, struct randwayp_node *a, uint32_t b_id,
	uint32_t b_emuid)
{
	return(randwayp_model.unlink(net_id, a->node_id, b_id, 
		a->emu_id, b_emuid));
}


int
randwayp_move_nodes(struct randwayp_net *net, struct timeval *script_time)
{
	struct randwayp_node *node;
	struct timeval elapsed;
	double dt, dx, dy, dist_x, dist_y;

	timersub(script_time, &net->last_time, &elapsed);
	TV2D(&elapsed, dt);

	/* wl_log("randwayp_move_nodes(): elapsed time %.3f resolution %.3f\n",
		dt, net->conf.resolution); // */
	if (dt < net->conf.resolution)
		return(0);

	net->last_time.tv_sec = script_time->tv_sec;
	net->last_time.tv_usec = script_time->tv_usec;

	for (node = net->node_list; node; node=node->next) {
		/* node has reached its destination */
		if (node->x == node->dest_x && node->y == node->dest_y) {
			/* node is waiting for new destination */
			if (node->wait_time.tv_sec > 0 ||
			    node->wait_time.tv_usec > 0) {
				timersub(&node->wait_time, &elapsed,
					&node->wait_time);
				if (node->wait_time.tv_sec < 0)
					node->wait_time.tv_usec = 0;
				wl_log("node %u is waiting (wait time=%u.%u)\n",
					node->node_id,
					node->wait_time.tv_sec, 
					node->wait_time.tv_usec);
				continue;
			}
			/*
			wl_log("node %d has reached destination <%.3f, %.3f>\n",
				node->node_id, node->x, node->y);
			*/
			randwayp_new_destination(net, node);
			randwayp_new_velocity(net, node);
		}
		/* move node towards desintation */
		dx = node->speed_x * dt;
		dy = node->speed_y * dt;
		dist_x = node->x - node->dest_x;
		dist_y = node->y - node->dest_y;
		node->x = (fabs(dist_x) <= fabs(dx)) ? node->dest_x : \
							node->x + dx;
		node->y = (fabs(dist_y) <= fabs(dy)) ? node->dest_y : \
							node->y + dy;
		/* very verbose!
		wl_log("moving node %d <%.3f, %.3f>\n",
			node->node_id, node->x, node->y); */

		send_node_message(randwayp_model.model_name, 0,
			node->node_id, net->net_id, node->emu_id,
			(uint32_t)lrint(node->x), (uint32_t)lrint(node->y));
	}
	return(0);
}

/* pick a new random destination and wait time */
void
randwayp_new_destination(struct randwayp_net *net, struct randwayp_node *node)
{
	double range_x, range_y, range_wait, wait;

	range_x = net->conf.max_x - net->conf.min_x;
	range_y = net->conf.max_y - net->conf.min_y;

	node->dest_x = net->conf.min_x + (random_double() * range_x);
	node->dest_y = net->conf.min_y + (random_double() * range_y);
/*
	wl_log("node %d has new destination <%.3f, %.3f>\n",
		node->node_id, node->dest_x, node->dest_y);
// */

	range_wait = net->conf.wait_time_max - net->conf.wait_time_min;
	if (range_wait <= 0.0) {
		if (net->conf.wait_time_min <= net->conf.resolution)
			return; /* don't bother setting a wait time */
		D2TV(net->conf.wait_time_min, &node->wait_time);
		return;
	}
	wait = net->conf.wait_time_min + (random_double() * range_wait);
	D2TV(wait, &node->wait_time);
	wl_log("node %d has new destination <%.3f, %.3f> wait %.3f\n",
		node->node_id, node->dest_x, node->dest_y, wait);
}


/* pick a new random velocity */
void
randwayp_new_velocity(struct randwayp_net *net, struct randwayp_node *node)
{
	double speed, range, alpha, dist_x, dist_y;

	range = net->conf.velocity_max - net->conf.velocity_min;
	if (range > 0.0)
		speed = net->conf.velocity_min + (random_double() * range);
	else
		speed = net->conf.velocity_min;


	dist_x = node->x - node->dest_x;
	dist_y = node->y - node->dest_y;
	if (dist_x == 0.0) { /* no divide by zero */
		node->speed_y = (dist_y < 0.0) ? -speed : speed;
		return;
	}
	alpha = atan(dist_y / dist_x); /* angle to destination */
	if (node->dest_x < node->x) /* correct negative values */
		alpha += 2*acos(0);
	node->speed_x = speed * cos(alpha); /* x component of random speed */
	node->speed_y = speed * sin(alpha); /* y component of random speed */
/*	wl_log("node %d has new a velocity of %.3f <%3f, %.3f>\n",
		node->node_id, speed, node->speed_x, node->speed_y); 
 */
}

/* random double between 0.0-1.0 */
double
random_double()
{
	double r;
	/* most docs suggest NOT using rand() or drand48() */
	long int ri = random();
	
	r = (double)ri / (double)RAND_MAX;
	return(r);
}
