/* 
 * CORE
 * (c)2009 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Random waypoint definitions.
 */
#ifndef RANDWAYP_H
#define RANDWAYP_H

#include "../model.h"

extern struct core_wlan_model randwayp_model;

void init_randwayp();
int config_randwayp(uint16_t flags, uint8_t *config_data, uint16_t config_len);
void randwayp_flush_nodes(uint16_t flags, uint32_t net_id);
int randwayp_update_node(uint16_t, uint32_t, uint32_t, uint32_t, uint32_t,
		uint32_t);
int randwayp_remove_node(uint32_t net, uint32_t id);
void randwayp_periodic(struct timeval *now);
void debug_randwayp();

#define TV2D(tv, d) d = (double)(tv)->tv_sec + ((double)(tv)->tv_usec*0.000001)
#define D2TV(d, tv) { (tv)->tv_sec = (time_t)d; (tv)->tv_usec = d * 1000000; }

#endif /* RANDWAYP_H */
