/* 
 * CORE
 * (c)2009 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Random waypoing DB definitions.
 */
#ifndef RANDWAYP_DB_H
#define RANDWAYP_DB_H

#define MIN_BUCKETS 512
#define RANDWAYP_DB_HASH(a, b)  ((a | (b << 16)) % MIN_BUCKETS)

struct randwayp_net_config {
	uint32_t min_x;
	uint32_t min_y;
	uint32_t max_x;
	uint32_t max_y;
	double   velocity_min;
	double   velocity_max;
	double   wait_time_min;
	double   wait_time_max;
	double   start_time;
	double   stop_time;
	double   resolution;
	uint32_t random_seed;
};

struct randwayp_net {
	uint32_t net_id;
	uint32_t emu_id;
	struct timeval start_time;
	struct timeval last_time;
	struct randwayp_node *node_list;
	struct randwayp_net *next;
	struct randwayp_net_config conf;
};

/*				min x,y,  max x,y     \
 *				vmin, vmax, wmin, wmax,
 *				start, stop, res			*/
#define RANDWAYP_NET_DATA_INIT { htons(10), htons(10), \
				htons(10), htons(10), htons(10), htons(10), \
				htons(10), htons(10), htons(10), htons(3) }
#define RANDWAYP_NET_CAPTIONS "min x,y|max x,y|min velocity|max velocity|min wait time|max wait time|start time|stop_time|resolution|random seed\0"

struct randwayp_node {
	uint32_t node_id;
	uint32_t emu_id;
	double x;
	double y;
	double dest_x;
	double dest_y;
	double speed_x;
	double speed_y;
	struct timeval wait_time; 
	struct randwayp_node *next;
};

void init_randwayp_db();
struct randwayp_net *get_randwayp_net(uint32_t, struct randwayp_net **);
struct randwayp_net *new_randwayp_net(uint32_t, struct randwayp_net *);
void flush_randwayp_nets();
struct randwayp_node *get_randwayp_node_list(uint32_t);
void flush_randwayp_node_list(uint32_t);
void free_randwayp_net(struct randwayp_net *);
struct randwayp_node *find_randwayp_node(struct randwayp_net *, uint32_t);
struct randwayp_node *update_randwayp_node_db(uint32_t, uint32_t, uint32_t,
	uint32_t, uint32_t);
int  remove_randwayp_node_db(uint32_t, uint32_t);
void debug_randwayp_db(int);
#endif /* RANDWAYP_DB_H */
