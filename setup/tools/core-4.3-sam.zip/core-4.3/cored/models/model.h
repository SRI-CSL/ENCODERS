/*
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * model.h
 * 
 * Generic structure for implementing wireless models.
 */
#ifndef _MODEL_H_
#define _MODEL_H_

#include <sys/types.h> /* uint32_t */

struct link_params;
struct timeval;

struct core_wlan_model {
	char model_name[255];
	int model_type;
	int model_state;
	void (*init)();
	int  (*conf)(uint16_t flags, uint8_t *data, uint16_t data_len);
	void (*flush)(uint16_t flags, uint32_t net);
	int (*update)(uint16_t flags, uint32_t net, uint32_t node,
		      uint32_t emuid, uint32_t x, uint32_t y);
	int (*remove)(uint32_t net, uint32_t node);
	void (*periodic)(struct timeval *now);
	void (*debug)(int periodic);
	int (*link)(uint32_t, uint32_t , uint32_t, uint32_t, uint32_t,
		     struct link_params *);
	int (*unlink)(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
	struct core_wlan_model *model_next;
};

extern struct core_wlan_model *g_models;

enum model_types {
	MODEL_TYPE_UNSPEC,
	MODEL_TYPE_WIRELESS=1,
	MODEL_TYPE_MOBILITY,
	MODEL_TYPE_UTILITY,
};

enum model_states {
	MODEL_STATE_UNINIT=0,
	MODEL_STATE_INIT,
	MODEL_STATE_DISABLED,
	MODEL_STATE_ENABLED,
};

#define add_model(m, list, add ) 	\
	if (!list) { list = add; }	\
	else { 	for (m = list; m->model_next; m = m->model_next);	\
		m->model_next = add; } 

#define for_each_model(a, list)		\
	for (a = list; a; a = a->model_next)

#endif /* _MODEL_H_ */
