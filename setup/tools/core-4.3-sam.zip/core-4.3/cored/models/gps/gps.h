/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * GPS model.
 */

#ifndef GPS_H
#define GPS_H

#include "../model.h"

#define GPS_DEFAULT_LAT1  4758.02   /* 47 34'48.64" N */
#define GPS_DEFAULT_LONG1 -12212.96  /* 122 07'46.66" W */
#define GPS_DEFAULT_LAT2  4757.64   /* 13.52s ~900 ft. south of LAT1 */
#define GPS_DEFAULT_LONG2 -12212.79  /* 6.12s ~620 ft. east of LONG1*/
#define GPS_DEFAULT_SPEED 0.0
#define GPS_DEFAULT_TRUE  0.0
#define GPS_DEFAULT_VAR   0.0
#define GPS_DEFAULT_DEV_NAME "/tmp/e0_n%u/gpsdev0"
#define GPS_DEFAULT_BITMAP "icons/normal/gps-diagram.xbm\0"

extern struct core_wlan_model gps_model;

void init_gps();
int  config_gps(uint16_t flags, uint8_t *config_data, uint16_t config_len);
void flush_gps_nodes(uint16_t flags, uint32_t net_id);
int  update_gps_node (uint16_t, uint32_t, uint32_t, uint32_t, uint32_t,
		uint32_t);
int  remove_gps_node (uint32_t net_id, uint32_t id);
void update_gps_periodic(struct timeval *t);
void debug_gps(int periodic);

#endif /* GPS_H */
