/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * GPS model.
 */
#include <stdio.h>
#include <stdlib.h>	/* abs() */
#include <strings.h>	/* bzero() */
#include <string.h>	/* strlen() */
#include <fcntl.h>	/* open() */
#include <unistd.h>	/* close() */
#include <errno.h>	/* errno */
#include <sys/types.h>  /* for cored.h */
#include <sys/socket.h> /* for cored.h */
#include <sys/stat.h>	/* mkfifo() */
#include <netinet/in.h> /* htonl() in core_api.h */
#include <math.h>
#include <time.h>	/* gmtime() */
#include <cored.h>
#include <coreapi/coreapi.h> /* reqd for handling config messages */
#include <models/model.h>
#include "gps.h"
#include "gps_db.h"

extern void nmea_add_checksum(char *);

struct core_wlan_model gps_model = {
	.model_name = "GPS",
	.model_type = MODEL_TYPE_UTILITY,
	.model_state = MODEL_STATE_UNINIT,
	.init = init_gps,
	.conf = config_gps,
	.flush = flush_gps_nodes,
	.update = update_gps_node,
	.remove = remove_gps_node,
	.periodic = update_gps_periodic,
	.debug = debug_gps,
	.link = NULL,
	.unlink = NULL,
	.model_next = NULL,
};

int gps_config_to_string(struct gps_config *c, uint8_t *to);
int string_to_gps_config(uint8_t *from, int from_len, struct gps_config *c);
void log_gps_config(struct gps_config *c);
void do_gps_output(struct gps_region *, struct gps_node *, char *, int);
int make_gps_str(char *dst, struct gps_region *r, struct gps_node *n);
void make_gps_devname(char *dst, uint32_t id, char *src, int size);

void
init_gps()
{
	init_gps_db();
	gps_model.model_state = MODEL_STATE_INIT;
	wl_log("GPS location model loaded.\n");
}

int
config_gps(uint16_t flags, uint8_t *config_data, uint16_t config_len)
{
	struct gps_region *r, *r2, *prev;
	struct core_api_tlv *tlv;
	uint32_t wlan_node_num, wlan_id;
	uint16_t data_len, len = config_len;
	uint16_t types[8] = GPS_DATA_INIT;
	uint8_t data[255], capt[80] = GPS_CAPTIONS;
	uint8_t bmp[32] = GPS_DEFAULT_BITMAP;

	/* WLAN node number used as net id */
	core_api_parse_message(config_data, &len);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NODE);
	if (core_api_get_tlv_val32(tlv, &wlan_node_num) < 0)
		return(-1);

	r = get_region(wlan_node_num, &prev);
	if (!r) {
		r = new_region(wlan_node_num, prev);
		if (!r) return -1;
	}

	/* receive node ID -> netgraph ID mapping and return */
	if (flags & CONF_TYPE_FLAGS_UPDATE) {
		/* use netgraph ID instead of node ID */
		tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NETID);
		if (core_api_get_tlv_val32(tlv, &wlan_id) < 0)
			return(-1);
		r2 = get_region(wlan_id, &prev);	
		if (!r2) {
			r2 = new_region(wlan_id, prev);
			if (!r2) return -1;
		}
		memcpy(&r2->conf, &r->conf, sizeof(r->conf));
		/* flag that we should generate GPS data for this region */
		r2->active = 1;
		return(0);
	}

	/* provide configuration parameters and return */
	if (flags & CONF_TYPE_FLAGS_REQUEST) {
		wl_log("GPS location model, handling config request for wlan"
			"%d...\n", wlan_node_num);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_DATA_TYPES, 
				sizeof(types), (uint8_t*)&types);
		data_len = gps_config_to_string(&r->conf, data);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_VALUES, 
				data_len, data); 
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_CAPTIONS, 
				strlen((char*)capt), capt);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_BITMAP, 
				strlen((char*)bmp), bmp);
		core_api_message_set_length(config_data, 
				len - sizeof(struct core_api_msg));
		wl_log("Sending the config: ");
		log_gps_config(&r->conf);
		wl_log("\n");		
		/* returns the length of bytes used in the new TLV */
		return len;
	}

	/* parse configuration parameters */
	wl_log("GPS location model, handling config data for wlan%d...\n",
		wlan_node_num);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_DATA_TYPES);
	if (!tlv) return(-1);
	if (memcmp(tlv->value, &types, sizeof(types))!=0) return(-1);

	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_VALUES);
	if (!tlv) return(-1);
	string_to_gps_config(tlv->value, tlv->length, &r->conf);

	wl_log("Accepted GPS config for wlan%d: ", wlan_node_num);
	log_gps_config(&r->conf);
	wl_log("\n");

	return 0;
}

/* convert the config struct to a '|' delimited string */
int
gps_config_to_string(struct gps_config *c, uint8_t *to)
{
	/* field specifiers:         lt1  lg1  lt2  lg2  sp   tr   var dev */
	return sprintf((char *)to, "%.2f|%.2f|%.2f|%.2f|%.2f|%.2f|%.2f|%s",
			c->lat1, c->long1, c->lat2, c->long2,
			c->speed, c->truecourse, c->variation, c->devname);
}

/* convert the '|' delimited string to a config struct */
int
string_to_gps_config(uint8_t *from, int from_len, struct gps_config *c)
{
	char *devname;
	int devlen;

	devname = rindex((char *)from, '|') + 1;
	devlen = from_len - (devname - (char*)from);
	if (devlen >= sizeof(c->devname)) devlen = sizeof(c->devname) - 1;
	bzero(c->devname, sizeof(c->devname));
	memcpy(c->devname, devname, devlen);

	/* field specifiers:       lt1lg1lt2lg2 sp tr var */
	return 1+sscanf((char*)from, "%f|%f|%f|%f|%f|%f|%f|",
			&c->lat1, &c->long1, &c->lat2, &c->long2,
			&c->speed, &c->truecourse, &c->variation);
}

void
log_gps_config(struct gps_config *c)
{
	if (!c) {
		wl_log("<null>");
		return;
	}
	wl_log("[(%.2f,%.2f)(%.2f,%.2f),%f,%f,%f,%s]",
		c->lat1, c->long1, c->lat2, c->long2,
		c->speed, c->truecourse, c->variation, c->devname);
}

void
flush_gps_nodes(uint16_t flags, uint32_t rid)
{
	/* wl_log("flush_gps_nodes(%u, %u)\n", flags, rid); */
	if (flags & FLUSH_FLAGS_ALL_NODES)
		flush_gps_regions();
	else
		flush_gps_node_list(rid);
}

int
update_gps_node (uint16_t flags, uint32_t rid, uint32_t id, uint32_t emuid,
	uint32_t x, uint32_t y) 
{
	/* emuid (Netgraph ID) is ignored */
	/* wl_log("update_gps_node(%u, %u, %u, %u)\n", rid, id, x, y); */
	update_gps_node_db(rid, id, x, y);
	return(0);
}

int
remove_gps_node (uint32_t rid, uint32_t id)
{
	/* wl_log("remove_gps_node(%u, %u)\n", rid, id); */
	int err = remove_gps_node_db(rid, id);
	/* TODO: remove FIFO? */
	return(err);
}

void
update_gps_periodic(struct timeval *now)
{
	struct gps_region *r = NULL;
	struct gps_node *n;
	struct tm t;
	char ts[10], ds[10], gpsstr[512];
	int gpsstr_len;
	static time_t last = 0;
/*	struct timeval mynow;

	now = &mynow;
	gettimeofday(now, NULL);*/
	if ((now->tv_sec - last) < 1) /* execute this @ 1Hz */
		return;
	last = now->tv_sec;
	
	/* generate timestamp and datestamp once for this tick */
	gmtime_r(&now->tv_sec, &t);
	sprintf(ts, "%02d%02d%02d", t.tm_hour, t.tm_min, t.tm_sec);
	sprintf(ds, "%02d%02d%02d", t.tm_mday, t.tm_mon+1, t.tm_year-100);

	/* generate GPS output for active regions */
	while ((r = get_next_active_region(r))) {
	/*	wl_log("update_gps_periodic(%u) region=%u\n", 
			now->tv_sec, r->id);*/
		strncpy(r->ts, ts, sizeof(r->ts));
		strncpy(r->ds, ds, sizeof(r->ds));
		n = r->node_list;
		while (n) {
			gpsstr_len = make_gps_str(gpsstr, r, n);
			do_gps_output(r, n, gpsstr, gpsstr_len);
			n = n->next;
		}

		if (!r->next) /* end of list */
			break;
		/* continue looping with next region */
		r = r->next;
	}
}

void
debug_gps(int periodic)
{
	debug_gps_db();
}

void do_gps_output(struct gps_region *r, struct gps_node *n, char *gpsstr,
	int gpsstr_len)
{
	char devname[255];
	int len;

	make_gps_devname(devname, n->node_id, r->conf.devname, sizeof(devname));
	/*wl_log("do_gps_output(%u, %u, %s) dev=%s\n", 
		r->id, n->node_id, gpsstr, devname); // */

	/* open serial device */
	if (n->gps_fd < 0) {
		n->gps_fd = open(devname, O_WRONLY|O_NONBLOCK);
		/* No such file or directory */
		if ((n->gps_fd < 0) && (errno == ENOENT)) {
			/* create the FIFO and try again*/
			if (mkfifo(devname, ACCESSPERMS) < 0) {
				/*wl_log("node %u mkfifo() error (%d): %s\n",
					n->node_id, errno, strerror(errno));//*/
				return;
			}
			n->gps_fd = open(devname, O_WRONLY|O_NONBLOCK);
			/*if (n->gps_fd < 0)
				wl_log("node %u (2) open() error (%d): %s\n",
					n->node_id, errno, strerror(errno));//*/
		/* Device not configured */
		} else if ((n->gps_fd < 0) && (errno == ENXIO)) {
			/* waiting for gpsd to connect */
			/*wl_log("node %u gps disconnected\n", n->node_id);// */
			return;
		/* print other errors */
		/*} else if (n->gps_fd < 0) {
			wl_log("node %u open() error (%d): %s\n",
				n->node_id, errno, strerror(errno)); // */
		}
	}
	/* write GPS string to device */
	if (n->gps_fd > 0) {
		len = write(n->gps_fd, gpsstr, gpsstr_len);
		if (len < 0) {
			/*wl_log("node %u write() error (%d): %s\n",
				n->node_id, errno, strerror(errno)); // */
			close(n->gps_fd);
			n->gps_fd = -1; /* retry open() next tick */
		}
	}
}

int make_gps_str(char *dst, struct gps_region *r, struct gps_node *n)
{
	char ns, ew, vew, *gprmc, *gpgga;
	int len;

	gprmc = dst;
	ns = (n->node_lat > 0.0) ? 'N' : 'S';
	ew = (n->node_lat > 0.0) ? 'W' : 'E';
	vew = (r->conf.variation > 0.0) ? 'W' : 'E';
	sprintf(gprmc, "$GPRMC,%s,A,%.2f,%c,%.2f,%c,%.1f,%.1f,%s,%.1f,%c*",
		r->ts, fabsf(n->node_lat), ns, fabsf(n->node_long), ew,
		r->conf.speed, r->conf.truecourse, r->ds,
		r->conf.variation, vew);
	nmea_add_checksum(gprmc);
    /* $GPRMC,hhmmss.ss,A,llll.ll,a,yyyyy.yy,a,x.x,x.x,ddmmyy,x.x,a*hh
       $GPGGA,hhmmss.ss,llll.ll,a,yyyyy.yy,a,x,xx,x.x,x.x,M,x.x,M,x.x,xxxx  */
	len = strlen(gprmc);
	gpgga = &gprmc[len];
	/* GPS Fix Data */
	sprintf(gpgga,
		"$GPGGA,%s,%.2f,%c,%.2f,%c,1,08,0.0,0.0,M,0.0,M,,*",
		r->ts, fabsf(n->node_lat), ns, fabsf(n->node_long), ew);
	nmea_add_checksum(gpgga);
	return(strlen(dst));
}

/* device name source string is used as the format to snprintf() */
void make_gps_devname(char *dst, uint32_t id, char *src, int size)
{
	char *pct = index(src, '%');
	if (!pct || ( *(pct+1) != 'u'))
		sprintf(dst, "dev_name_error");
	snprintf(dst, size, src, id);
}
