/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * GPS location node database 
 */

#include <stdlib.h> /* malloc */
#include <stdio.h>  /* sprintf */
#include <unistd.h> /* close() */
#include <string.h>
#include <sys/types.h>
#include <inttypes.h>

#include <cored.h> /* wl_log() */
#include "gps.h"
#include "gps_db.h"

static struct gps_region *region_list;

void
init_gps_db()
{
	region_list = NULL;
}

struct gps_region *get_next_active_region(struct gps_region *start)
{
	struct gps_region *r;
	
	if (start == NULL)
		start = region_list;

	for (r = start; r; r = r->next) {
		if (r->active)
			return(r);
	}
	return NULL;
}

struct gps_region *get_region(uint32_t rid, struct gps_region **prev)
{
	struct gps_region *net;
	
	if (prev)
		*prev = NULL;
	for (net = region_list; net; net = net->next) {
		if (net->id == rid)
			return(net); /* found */
		if (prev)
			*prev = net;
	}
	return(NULL);
}

struct gps_region *new_region(uint32_t rid, struct gps_region *prev)
{
	struct gps_region *r;

	/* allocate and initialize */
	r = malloc(sizeof(struct gps_region));
	if (!r)
		return NULL;
	bzero(r, sizeof(struct gps_region));
	r->id = rid;
	r->active = 0;
	r->node_list = malloc(sizeof(struct gps_node));
	bzero(r->node_list, sizeof(struct gps_node));
	r->conf.lat1 =  GPS_DEFAULT_LAT1;
	r->conf.long1 = GPS_DEFAULT_LONG1;
	r->conf.lat2 =  GPS_DEFAULT_LAT2;
	r->conf.long2 = GPS_DEFAULT_LONG2;
	r->conf.speed = GPS_DEFAULT_SPEED;
	r->conf.truecourse = GPS_DEFAULT_TRUE;
	r->conf.variation = GPS_DEFAULT_VAR;
	snprintf(r->conf.devname, sizeof(r->conf.devname),
		"%s", GPS_DEFAULT_DEV_NAME);

	/* link it to list */
	if (prev)
		prev->next = r;
	else
		region_list = r;
	return(r);
}

void
flush_gps_regions()
{
	struct gps_region *net, *next_net;
	struct gps_node *node, *next_node;

	net = region_list;
	while (net) {
		next_net = net->next;
		node = net->node_list;
		while (node) {
			next_node = node->next;
			if (node->gps_fd > 0)
				close(node->gps_fd);
			free(node);
			node = next_node;
		}
		bzero(net, sizeof(struct gps_region));
		free(net);
		net = next_net;
	}
	region_list = NULL;
}

struct
gps_node *get_gps_node_list(uint32_t rid, struct gps_region **reg)
{
	struct gps_region *r, *prev;

	r = get_region(rid, &prev);	
	if (reg)
		*reg = NULL;
	if (!r) { /* r not found, add to the list */
		r = new_region(rid, prev);
		if (!r) return NULL;
	}

	if (reg) /* return region if ptr supplied */
		*reg = r;
	return(r->node_list);
}

void
flush_gps_node_list(uint32_t rid)
{
	struct gps_region *r, *prev;
	struct gps_node *node, *next_node;

	r = get_region(rid, &prev);
	if (!r) /* region not found */
		return;

	node = r->node_list;
	while (node) {
		next_node = node->next;
		if (node->gps_fd > 0)
			close(node->gps_fd);
		free(node);
		node = next_node;
	}

	if (prev) {
		prev->next = r->next;
		bzero(r, sizeof(struct gps_region));
		free(r);
	} else {
		bzero(r, sizeof(struct gps_region));
		free(r);
		region_list = NULL;
	}
	
}

struct
gps_node *update_gps_node_db(uint32_t rid, uint32_t id, uint32_t x, uint32_t y)
{
	struct gps_node *node, *prev, *node_list;
	struct gps_region *reg;

	prev = NULL;
	node_list = get_gps_node_list(rid, &reg);
	/* ASSERT(node_list) */
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) { /* not found - create new */
		if ((prev == node_list) && GPS_NODE_UNUSED(node_list)) {
			/* first in list */
			node = node_list;
		} else {
			node = (struct gps_node *)
				malloc(sizeof(struct gps_node));
			if (!node) return(NULL);
			bzero(node, sizeof(struct gps_node));
			prev->next = node;
		}
		/* insert new node initialization here */
		node->node_id = id;
		node->gps_fd = -1;
	}
	if (translate_coords_to_latlong(reg, x, y, &node->node_lat, 
					&node->node_long) < 0)
		return(NULL);

	return(node);
}

int
remove_gps_node_db(uint32_t rid, uint32_t id)
{
	struct gps_node *node, *prev, *next, *node_list;

	prev = NULL;
	node_list = get_gps_node_list(rid, NULL);
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) /* not found */
		return(-1);
	if (node->gps_fd > 0)
		close(node->gps_fd);
	if (node == node_list) { /* don't delete the first node */
		if (node->next) {
			next = node->next;
			memcpy(node_list, next, sizeof(struct gps_node));
			bzero(next, sizeof(struct gps_node));
			free(next);
		} else {
			bzero(node_list, sizeof(struct gps_node));
		}
	} else {
		prev->next = node->next;
		bzero(node, sizeof(struct gps_node));
		free(node);
	}
	
	return(0);
}

void
debug_gps_db()
{
	static char dbuf[1024] = { 0 };
	char buf[1024], tmp[16];
	struct gps_region *net;
	struct gps_node *node;
	
	bzero(buf, sizeof(buf));

	for (net = region_list; net; net = net->next) {
		if (!net->node_list)
			continue;
		sprintf(tmp, "rid 0x%x (", net->id);
		strncat(buf, tmp, sizeof(buf) - 1);
		for (node = net->node_list; node; node = node->next) {
			/*sprintf(tmp, "0x%x(%u,%u) ", node->node_id, 
				node->x, node->y);*/
			sprintf(tmp, "0x%x ", node->node_id);
			strncat(buf, tmp, sizeof(buf) - 1);
		}
		strncat(buf, ") ", sizeof(buf) - 1);
	}

	/* only print output when something has changed */
	if (strncmp(dbuf, buf, sizeof(dbuf))) { /* might be expensive */
		strncpy(dbuf, buf, sizeof(dbuf));
		wl_log("gps_db: %s\n", dbuf);
	}
}

int translate_coords_to_latlong(struct gps_region *r, uint32_t x, uint32_t y,
	float *lt, float *lg)
{
	if (!r || !lt || !lg)
		return(-1);

	/* currently assume default canvas width 900x620 */
	*lt = r->conf.lat1 + (y * (r->conf.lat2 - r->conf.lat1) / 620.0);
	*lg = r->conf.long1 + (x * (r->conf.long2 - r->conf.long1) / 900.0);

	/* no error */
	return 0;
}
