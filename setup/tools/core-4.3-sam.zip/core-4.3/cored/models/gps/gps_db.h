/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Simple range node DB definitions.
 */
#ifndef GPS_DB_H
#define GPS_DB_H

#define MIN_BUCKETS 512
#define GPS_DB_HASH(a, b)  ((a | (b << 16)) % MIN_BUCKETS)

/* GPS database has regions and nodes. Coordinates are lat/long floats.
 * region - has a config with upper-left and lower-right coords
 *          generally, one region per WLAN (different WLANs can be 
 *	    geographically separate)
 * node   - just keeps track of current node coords
 */

struct gps_config {
	float lat1;
	float long1;
	float lat2;
	float long2;
	float speed;
	float truecourse;
	float variation;
	char devname[255];
};

struct gps_region {
	uint32_t id;
	int active;
	char ts[7];
	char ds[7];
	struct gps_node *node_list;
	struct gps_region *next;
	struct gps_config conf;
};

struct gps_node {
	uint32_t node_id;
	float    node_lat;
	float    node_long;
	int	 gps_fd;
	struct gps_node *next;
};

#define GPS_DATA_INIT { htons(10), htons(10), htons(10), htons(10), \
			htons(9), htons(9), htons(9), htons(10), \
		      }
#define GPS_CAPTIONS "Lat1|Long1|Lat2|Long2|speed (knots)|true course|variation|gps dev name\0"

#define GPS_NODE_UNUSED(a) ((a->node_id ==0) && (a->gps_fd = -1) && \
				(a->node_lat==0.0) && (a->node_long==0.0))

void init_gps_db();
struct gps_region *get_next_active_region(struct gps_region *start);
struct gps_region *get_region(uint32_t id, struct gps_region **prev);
struct gps_region *new_region(uint32_t id, struct gps_region *prev);
void   flush_gps_regions();
struct gps_node *get_gps_node_list(uint32_t id, struct gps_region **reg);
void   flush_gps_node_list(uint32_t id);
struct gps_node *update_gps_node_db(uint32_t, uint32_t, uint32_t, uint32_t);
int    remove_gps_node_db(uint32_t rid, uint32_t id);
void   debug_gps_db();
int translate_coords_to_latlong(struct gps_region *r, uint32_t x, uint32_t y,
	float *lt, float *lg);


#endif /* GPS_DB_H */
