/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Scripted node DB definitions.
 */
#ifndef SCRIPTED_DB_H
#define SCRIPTED_DB_H

#define MIN_BUCKETS 512
#define SCRIPTED_DB_HASH(a, b)  ((a | (b << 16)) % MIN_BUCKETS)

enum scripted_event_types {
	scripted_event_type_node,
	scripted_event_type_link,
	scripted_event_type_wlan,
};

struct scripted_event {
	struct timeval event_time;
	int event_type;
	void *event_data;
	struct scripted_event *next;
};

struct scripted_event_node {
	uint32_t node_id;
	uint32_t x;
	uint32_t y;
};

struct link_params;
struct scripted_event_link {
	uint32_t node1_id;
	uint32_t node2_id;
	struct link_params params;
};

struct scripted_event_wlan {
	uint16_t mburst;
	uint16_t mer;
};

struct scripted_net_config {
	int loop_script; 
	int startup_delay;
	int prefetch_seconds;
	char script_filename[255];
};

struct scripted_net {
	uint32_t net_id;
	uint32_t emu_id;
	FILE *script_fp;
	struct timeval start_time;
	struct timeval script_time_next;
	struct scripted_event *events;
	struct scripted_node *node_list;
	struct scripted_net *next;
	struct scripted_net_config conf;
};

#define SCRIPTED_NET_DATA_INIT { htons(2), htons(2), htons(2), htons(10), }
#define SCRIPTED_NET_CAPTIONS "loop script|startup delay|prefetch seconds|script filename\0"

struct scripted_node {
	uint32_t node_id;
	uint32_t emu_id;
	uint32_t x;
	uint32_t y;
	struct scripted_node *next;
};

void init_scripted_db();
struct scripted_net *get_scripted_net(uint32_t, struct scripted_net **);
struct scripted_net *new_scripted_net(uint32_t, struct scripted_net *);
void flush_scripted_nets();
struct scripted_node *get_scripted_node_list(uint32_t);
void flush_scripted_node_list(uint32_t);
void free_scripted_net(struct scripted_net *);
struct scripted_node *find_scripted_node(struct scripted_net *, uint32_t);
struct scripted_node *update_scripted_node_db(uint32_t, uint32_t, uint32_t,
	uint32_t, uint32_t);
int  remove_scripted_node_db(uint32_t, uint32_t);
void debug_scripted_db();
int scripted_add_net_event(struct scripted_net*, struct timeval*, int, void*);
int scripted_add_node_event(struct scripted_net *, struct timeval *);
int scripted_add_link_event(struct scripted_net *, struct timeval *);
int scripted_add_wlan_event(struct scripted_net *, struct timeval *);
#endif /* SCRIPTED_DB_H */
