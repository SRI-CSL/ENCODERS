/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Scripted node DB.
 */

#include <stdlib.h> /* malloc */
#include <stdio.h>  /* sprintf */
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>	/* timercmp() */
#include <sys/socket.h> /* for cored.h */
#include <inttypes.h>
#include <errno.h>	/* errno */

#include <cored.h> 
#include "scripted.h"
#include "scripted_db.h"

struct scripted_net *scripted_net_list;

void
init_scripted_db()
{
	scripted_net_list = NULL;
}

struct scripted_net *get_scripted_net(uint32_t net_id, struct scripted_net **prev)
{
	struct scripted_net *net;
	
	if (prev)
		*prev = NULL;
	for (net = scripted_net_list; net; net = net->next) {
		if (net->net_id == net_id)
			return(net); /* found */
		if (prev)
			*prev = net;
	}
	return(NULL);
}

struct scripted_net *new_scripted_net(uint32_t net_id, struct scripted_net *prev)
{
	struct scripted_net *net;

	/* allocate and initialize */
	net = malloc(sizeof(struct scripted_net));
	if (!net)
		return NULL;
	bzero(net, sizeof(struct scripted_net));
	net->net_id = net_id;
	net->conf.loop_script = 0; /* no looping */
	net->conf.startup_delay = 2;
	net->conf.prefetch_seconds = 30;
	sprintf(net->conf.script_filename, "sample_script.csv");
	net->node_list = malloc(sizeof(struct scripted_node));
	bzero(net->node_list, sizeof(struct scripted_node));

	/* link it to list */
	if (prev)
		prev->next = net;
	else
		scripted_net_list = net;
	return(net);
}

void
flush_scripted_nets()
{
	struct scripted_net *net, *next_net;

	net = scripted_net_list;
	while (net) {
		next_net = net->next;
		free_scripted_net(net);
		net = next_net;
	}
	scripted_net_list = NULL;
}

struct
scripted_node *get_scripted_node_list(uint32_t net_id)
{
	struct scripted_net *net, *prev;

	net = get_scripted_net(net_id, &prev);	
	if (!net) { /* net not found, add to the list */
		net = new_scripted_net(net_id, prev);
		if (!net) return NULL;
	}

	return(net->node_list);
}

void
flush_scripted_node_list(uint32_t net_id)
{
	struct scripted_net *net, *prev;

	net = get_scripted_net(net_id, &prev);
	if (!net) /* net not found */
		return;

	if (prev) prev->next = net->next;
	else scripted_net_list = NULL;
	free_scripted_net(net);
}

void
free_scripted_net(struct scripted_net *net)
{
	struct scripted_node *node, *next_node;
	struct scripted_event *event, *next_event;

	if (net->script_fp)
		fclose(net->script_fp);
	event = net->events;
	while (event) {
		next_event = event->next;
		free(event);
		event = next_event;
	}
	node = net->node_list;
	while (node) {
		next_node = node->next;
		free(node);
		node = next_node;
	}
	bzero(net, sizeof(struct scripted_net));
	free(net);
}

struct
scripted_node *find_scripted_node(struct scripted_net *net, uint32_t id)
{
	struct scripted_node *n;
	for (n = net->node_list; n; n = n->next) {
		if (n->node_id == id)
			break;
	}
	return (n);
}

struct
scripted_node *update_scripted_node_db(uint32_t net, uint32_t id,
	uint32_t emuid, uint32_t x, uint32_t y)
{
	struct scripted_node *node, *prev, *node_list;

	prev = NULL;
	node_list = get_scripted_node_list(net);
	/* ASSERT(node_list) */
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) { /* not found - create new */
		/* emu_id==0 indicates no node (empty list) */
		if ((prev == node_list) && (node_list->emu_id==0)) { 
			/* first in list */
			node = node_list;
		} else {
			node = (struct scripted_node *)
				malloc(sizeof(struct scripted_node));
			if (!node) return(NULL);
			bzero(node, sizeof(struct scripted_node));
			prev->next = node;
		}
		node->node_id = id;
		node->emu_id = emuid;
	}
	node->emu_id = emuid;
	node->x = x;
	node->y = y;
	return(node);
}

int
remove_scripted_node_db(uint32_t net, uint32_t id)
{
	struct scripted_node *node, *prev, *next, *node_list;

	prev = NULL;
	node_list = get_scripted_node_list(net);
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) /* not found */
		return(-1);
	if (node == node_list) { /* don't delete the first node */
		if (node->next) {
			next = node->next;
			memcpy(node_list, next, sizeof(struct scripted_node));
			bzero(next, sizeof(struct scripted_node));
			free(next);
		} else {
			bzero(node_list, sizeof(struct scripted_node));
		}
	} else {
		prev->next = node->next;
		bzero(node, sizeof(struct scripted_node));
		free(node);
	}
	
	return(0);
}

void
debug_scripted_db()
{
	static char dbuf[1024] = { 0 };
	char buf[1024], tmp[16];
	struct scripted_net *net;
	struct scripted_node *node;
	
	bzero(buf, sizeof(buf));

	for (net = scripted_net_list; net; net = net->next) {
		if (!net->node_list)
			continue;
		sprintf(tmp, "net 0x%x (", net->net_id);
		strncat(buf, tmp, sizeof(buf) - 1);
		for (node = net->node_list; node; node = node->next) {
			/*sprintf(tmp, "0x%x(%u,%u) ", node->node_id, 
				node->x, node->y);*/
			sprintf(tmp, "0x%x ", node->node_id);
			strncat(buf, tmp, sizeof(buf) - 1);
		}
		strncat(buf, ") ", sizeof(buf) - 1);
	}

	/* only print output when something has changed */
	if (strncmp(dbuf, buf, sizeof(dbuf))) { /* might be expensive */
		strncpy(dbuf, buf, sizeof(dbuf));
		wl_log("scripted_db: %s\n", dbuf);
	}
}

int
scripted_add_net_event(struct scripted_net *net, struct timeval *when, 
	int event_type, void *event_data)
{
	struct scripted_event *e, *i, *prev;

	/* wl_log("scripted_add_net_event(%p, %u.%u, %d. %p)\n", 
		net, when->tv_sec, when->tv_usec, event_type, event_data); */
	/* allocate a new event */
	e = (struct scripted_event *) malloc(sizeof(struct scripted_event));
	if (!e) {
		free(event_data);
		return(-1);
	}
	e->event_time.tv_sec = when->tv_sec;
	e->event_time.tv_usec = when->tv_usec;
	e->event_type = event_type;
	e->event_data = event_data;

	/* add it to the event list, sorted by time and insertion order  */
	prev = NULL;
	for (i = net->events; i; i = i->next) {
		if (timercmp(when, &i->event_time, <))
			break;
		prev = i;
	}

	if (i) { /* event e occurs before i */
		e->next = i;
		if (prev) prev->next = e;
		else net->events = e;
	} else {
		if (prev) { /* event e occurs at end of list */
			e->next = NULL;
			prev->next = e;
		} else { /* event e occurs at start of list */
			e->next = net->events;
			net->events = e;
		}
	}
	return(0);
}

int
scripted_add_node_event(struct scripted_net *net, struct timeval *when)
{
	char *cp;
	enum { type_token, type_node, type_x, type_y };
	int next = type_node;
	uint32_t node_id = 0, x = 0, y = 0;
	struct scripted_event_node *node_event;

	if (!net || !when)
		return(-1);

	/* parse using strtok() call that was started earlier */
	while(( cp = strtok(NULL, " ") )) {
		switch (next) {
		case type_node:
			errno = 0;
			node_id = strtoul(cp, NULL, 10);
			if (errno == EINVAL) /* node num is required */
				return(-1);
			next = type_token;
			break;
		case type_token:
			if (*cp == 'x')
				next = type_x;
			else if (*cp == 'y')
				next = type_y;
			else if (*cp == '\n')
				break;
			else
				wl_log("warning: unknown node token '%s'\n",
				       cp);
			break;
		case type_x:
			x = strtoul(cp, NULL, 10);
			next = type_token;
			break;
		case type_y:
			y = strtoul(cp, NULL, 10);
			next = type_token;
			break;
		default:
			wl_log("warning: unknown node token '%s'\n", cp);
			break;
		}
	}

	/* add to the db */
	node_event = (struct scripted_event_node *)malloc(
					sizeof(struct scripted_event_node));
	if (!node_event)
		return(-1); /* ENOMEM */
	node_event->node_id = node_id;
	node_event->x = x;
	node_event->y = y;

	return(scripted_add_net_event(net, when, scripted_event_type_node,
				      node_event));
}

int
scripted_add_link_event(struct scripted_net *net, struct timeval *when)
{
	char *cp;
	enum { type_token, type_node, type_delay, type_bw, type_per,
		type_dup, type_jitter, type_burst };
	int next = type_node;
	struct scripted_event_link *le;

	if (!net || !when)
		return(-1);

	le = (struct scripted_event_link *) malloc(
					sizeof(struct scripted_event_link));
	if (!le) return(-1);
	memset(le, 0, sizeof(struct scripted_event_link));

	/* parse using strtok() call that was started earlier */
	while(( cp = strtok(NULL, " ") )) {
		switch (next) {
		case type_node:
			errno = 0;
			le->node1_id = strtoul(cp, NULL, 10);
			if (errno == EINVAL) /* node num is required */
				goto scripted_add_link_event_error;
			cp = strtok(NULL, " ");
			if (!cp)
				goto scripted_add_link_event_error;
			le->node2_id = strtoul(cp, NULL, 10);
			next = type_token;
			break;
		case type_token:
			if (*cp == 'd')
				next = (*(cp+1) == 'u') ? type_dup : type_delay;
			else if (*cp == 'b')
				next = (*(cp+1) == 'u') ? type_burst : type_bw;
			else if (*cp == 'p') next = type_per;
			else if (*cp == 'j') next = type_jitter;
			else if (*cp == '\n')
				break;
			else
				wl_log("warning: unknown node token '%s'\n",
				       cp);
			break;
		case type_delay:
			le->params.delay = strtoull(cp, NULL, 10);
			next = type_token;
			break;
		case type_bw:
			le->params.bw = strtoull(cp, NULL, 10);
			next = type_token;
			break;
		case type_per:
			le->params.per = (uint16_t)
					 strtoul(cp, NULL, 10) & 0xFFFF;
			next = type_token;
			break;
		case type_dup:
			le->params.dup = (uint16_t)
					 strtoul(cp, NULL, 10) & 0xFFFF;
			next = type_token;
			break;
		case type_jitter:
			le->params.jitter = strtoul(cp, NULL, 10);
			next = type_token;
			break;
		case type_burst:
			le->params.burst = (uint16_t)
					   strtoul(cp, NULL, 10) & 0xFFFF;
			next = type_token;
			break;
		default:
			wl_log("warning: unknown link token '%s'\n", cp);
		}
	}

	/* add to the db */
	return(scripted_add_net_event(net, when, scripted_event_type_link, le));
scripted_add_link_event_error:
	free(le);
	return(-1);
}

int
scripted_add_wlan_event(struct scripted_net *net, struct timeval *when)
{
	char *cp;
	enum { type_token, type_wlan, type_mburst, type_mer };
	int next = type_token;
	struct scripted_event_wlan *we;

	uint16_t mburst = 0, mer = 0;
	if (!net || !when)
		return(-1);

	/* parse using strtok() call that was started earlier */
	while(( cp = strtok(NULL, " ") )) {
		switch (next) {
		case type_token:
		        if (*cp == 'm')
			   	next = (*(cp+1)=='b') ? type_mburst : type_mer;
			else if (*cp == '\n')
				break;
			else
				wl_log("warning: unknown node token '%s'\n",
				       cp);
			break;
		case type_mer:
			mer = (uint16_t) strtoul(cp, NULL, 10) & 0xFFFF;
			next = type_token;
			break;
		case type_mburst:
			mburst = (uint16_t) strtoul(cp, NULL, 10) & 0xFFFF;
			next = type_token;
			break;
		default:
			wl_log("warning: unknown node token '%s'\n", cp);
			break;
		}
	}
	/* add to the db */
	we = (struct scripted_event_wlan *) malloc(
					sizeof(struct scripted_event_wlan));
	if (!we)
		return(-1); /* ENOMEM */
	we->mburst = mburst;
	we->mer = mer;

	return(scripted_add_net_event(net, when, scripted_event_type_wlan, we));
}

