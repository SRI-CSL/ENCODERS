/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Scripted definitions.
 */
#ifndef SCRIPTED_H
#define SCRIPTED_H

#include "../model.h"

extern struct core_wlan_model scripted_model;

void init_scripted();
int config_scripted(uint16_t flags, uint8_t *config_data, uint16_t config_len);
void scripted_flush_nodes(uint16_t flags, uint32_t net_id);
int scripted_update_node(uint16_t, uint32_t, uint32_t, uint32_t, uint32_t,
		uint32_t);
int scripted_remove_node(uint32_t net, uint32_t id);
void scripted_periodic(struct timeval *now);
void debug_scripted(int periodic);

#endif /* SCRIPTED_H */
