/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Scripted definitions.
 */
#include <stdio.h>
#include <stdlib.h>	/* abs() */
#include <strings.h>	/* bzero */
#include <string.h>	/* strlen() */
#include <sys/types.h>  /* for cored.h */
#include <sys/socket.h> /* for cored.h */
#include <sys/time.h>	/* gettimeofday() */
#include <time.h>	/* ctime() */
#include <math.h>	/* modff() */
#include <errno.h>	/* errno */
#include <netinet/in.h> /* htonl() in core_api.h */
#include <cored.h> 
#include <coreapi/coreapi.h> /* reqd for handling config messages */
#include <models/model.h>
#include "scripted.h"
#include "scripted_db.h"

struct core_wlan_model scripted_model = {
	.model_name = "scripted",
	.model_type = MODEL_TYPE_MOBILITY,
	.model_state = MODEL_STATE_UNINIT,
	.init = init_scripted,
	.conf = config_scripted,
	.flush = scripted_flush_nodes,
	.update = scripted_update_node,
	.remove = scripted_remove_node,
	.periodic = scripted_periodic,
	.debug = debug_scripted,
	.link = link_nodes,	/* from cored */
	.unlink = unlink_nodes,	/* from cored */
	.model_next = NULL,
};

/* -std=c99 */
#ifndef strtof
#ifdef FREEBSD411
#define strtof strtod
#else
extern float strtof(const char *nptr, char **endptr);
#endif
#endif
extern int control_sock;
extern struct scripted_net *scripted_net_list;
#ifdef FREEBSD
extern int send_wlan_mer(int, uint32_t, uint16_t, uint16_t); /* bsd/core_netgraph.c */
#endif /* FREEBSD */


/* local functions */
int scripted_config_to_string(struct scripted_net_config *c, uint8_t *to);
int string_to_scripted_config(uint8_t *, int, struct scripted_net_config *);
void log_scripted_config(struct scripted_net_config *c);
int link_scripted_nodes(uint32_t net_id, struct scripted_node *a, 
	struct scripted_node *b, struct link_params *params);
int unlink_scripted_nodes(uint32_t, struct scripted_node *, uint32_t, uint32_t);

int scripted_read_file(struct scripted_net *net, struct timeval *now);
int scripted_do_events(struct scripted_net *net, struct timeval *now);
void
init_scripted()
{
	init_scripted_db();
	scripted_model.model_state = MODEL_STATE_INIT;
	wl_log("Scripted model loaded.\n");
}

int
config_scripted(uint16_t flags, uint8_t *config_data, uint16_t config_len)
{
	struct scripted_net *net, *net2, *prev;
	struct core_api_tlv *tlv;
	uint32_t wlan_node_num, wlan_id;
	uint16_t len = config_len;
	uint16_t types[4] = SCRIPTED_NET_DATA_INIT;
	uint8_t data[255], capt[135] = SCRIPTED_NET_CAPTIONS;
	int data_len;

	/* WLAN node number used as net id */
	core_api_parse_message(config_data, &len);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NODE);
	if (core_api_get_tlv_val32(tlv, &wlan_node_num) < 0)
		return(-1);

	/* use node ID to store config data */
	net = get_scripted_net(wlan_node_num, &prev);	
	if (!net) { /* net not found, add new one to the list */
		net = new_scripted_net(wlan_node_num, prev);
		if (!net) return -1;
	}

	/* receive node ID -> netgraph ID mapping and return */
	if (flags & CONF_TYPE_FLAGS_UPDATE) {
		/* use netgraph ID instead of node ID */
		tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NETID);
		if (core_api_get_tlv_val32(tlv, &wlan_id) < 0)
			return(-1);
		net2 = get_scripted_net(wlan_id, &prev);	
		if (!net2) {
			net2 = new_scripted_net(wlan_id, prev);
			if (!net2) return -1;
		}
		memcpy(&net2->conf, &net->conf, sizeof(net->conf));
		net->emu_id = net2->emu_id = wlan_id;
		gettimeofday(&net2->start_time, NULL);
		net2->start_time.tv_sec += net->conf.startup_delay;
		wl_log("Script started for wlan 0x%x at time: %s", wlan_id,
		       ctime(&net2->start_time.tv_sec));
		return(0);
	}

	/* provide configuration parameters and return */
	if (flags & CONF_TYPE_FLAGS_REQUEST) {	
		wl_log("Scripted model, handling config request for wlan"
			"%d...\n", wlan_node_num);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_DATA_TYPES, 
				sizeof(types), (uint8_t*)&types);
		data_len = scripted_config_to_string(&net->conf, data);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_VALUES, 
				data_len, (uint8_t*)data);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_CAPTIONS, 
				strlen((char*)capt), capt);
		core_api_message_set_length(config_data, 
				len - sizeof(struct core_api_msg));
		wl_log("Sending the config: ");
		log_scripted_config(&net->conf);
		wl_log("\n");		
		/* returns the length of bytes used in the new TLV */
		return len;
	}

	/* parse configuration parameters */
	wl_log("Scripted model, handling config data for wlan%d...\n",
		wlan_node_num);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_DATA_TYPES);
	if (!tlv) return(-1);
	if (memcmp(tlv->value, &types, sizeof(types))!=0) return(-1);

	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_VALUES);
	if (!tlv) return(-1);
	string_to_scripted_config(tlv->value, tlv->length, &net->conf);

	wl_log("Accepted config for wlan%d: ", wlan_node_num);
	log_scripted_config(&net->conf);
	wl_log("\n");
	
	return 0;
}

/* convert the config struct to a '|' delimited string */
int
scripted_config_to_string(struct scripted_net_config *c, uint8_t *to)
{
	return sprintf((char*)to, "%u|%u|%u|%s", c->loop_script,
		       c->startup_delay, c->prefetch_seconds,
		       c->script_filename);
}

/* convert the '|' delimited string to a config struct */
int
string_to_scripted_config(uint8_t *from, int from_len, 
			struct scripted_net_config *c)
{
	int ret, filename_offset;

	ret = sscanf((char *)from, "%d|%d|%d|%n", 
		     &c->loop_script,&c->startup_delay,
		     &c->prefetch_seconds, &filename_offset);
	if (ret != 3) {
		wl_log("string_to_scripted_config() warning: expected 3 items,"
		       " got %d\n", ret);
		return(-1);
	}
	if (filename_offset == 0 || from_len - filename_offset < 1)
		return(-1); /* invalid filename */
	bzero(c->script_filename, sizeof(c->script_filename));
	memcpy(c->script_filename, (char *)from + filename_offset,
	       from_len - filename_offset);
	return(0);
}

void
log_scripted_config(struct scripted_net_config *c)
{
	if (!c) {
		wl_log("<null>");
		return;
	}
	wl_log("[loop=%u delay=%u, prefetch=%u, script file: %s]",
	       c->loop_script ,c->startup_delay, c->prefetch_seconds,
	       c->script_filename);
}

void
scripted_flush_nodes(uint16_t flags, uint32_t net_id)
{
	if (flags & FLUSH_FLAGS_ALL_NODES)
		flush_scripted_nets();
	else
		flush_scripted_node_list(net_id);
}

int
scripted_update_node (uint16_t flags, uint32_t net_id, uint32_t id,
	uint32_t emu_id, uint32_t x, uint32_t y) 
{
	struct scripted_net *net;
	struct scripted_node *node;

	/* wl_log("scripted_update_node(net=%x, id=%x, emu=%x, %u, %u)\n",
		net_id, id, emu_id, x, y); // */
	node = update_scripted_node_db(net_id, id, emu_id, x, y);
	if (!node)
		return(-1);

	net = get_scripted_net(net_id, NULL);
	if (!net)
		return(-1);

	return(0);
}

int
scripted_remove_node (uint32_t net_id, uint32_t id)
{
	int err = remove_scripted_node_db(net_id, id);
	/* TODO: remove links */
	return(err);
}

void
scripted_periodic(struct timeval *now)
{
	struct scripted_net *net;
	struct timeval script_time;
	
	for (net = scripted_net_list; net; net = net->next) {
		if (!net->emu_id ||  (net->node_list &&
			!net->node_list->next && !net->node_list->emu_id ))
			continue; /* emulation not started yet */
		timersub(now, &net->start_time, &script_time);	
		scripted_read_file(net, &script_time);
		scripted_do_events(net, &script_time);
	}
}

void
debug_scripted(int periodic)
{
	debug_scripted_db();
}

int
link_scripted_nodes(uint32_t net_id, struct scripted_node *a,
	struct scripted_node *b, struct link_params *params)
{
	return(scripted_model.link(net_id, a->node_id, b->node_id,
		a->emu_id, b->emu_id, params));
}

int
unlink_scripted_nodes(uint32_t net_id, struct scripted_node *a, uint32_t b_id,
	uint32_t b_emuid)
{
	return(scripted_model.unlink(net_id, a->node_id, b_id, 
		a->emu_id, b_emuid));
}

#define SCRIPTED_LINE_SIZE 512

int
scripted_read_file(struct scripted_net *net, struct timeval *now)
{
	char line[SCRIPTED_LINE_SIZE], *cp, *type;
	float float_tmp, float_sec, float_usec;
	struct timeval script_time, fetch_time;
	fpos_t pos;

	/* prepare the script file for reading */
	if (!net->script_fp) {
		net->script_fp = fopen(net->conf.script_filename, "r");
		if (!net->script_fp) {
			wl_log("Error opening script file '%s': %s\n",
			       net->conf.script_filename, strerror(errno));
			net->emu_id = 0; /* stop trying */
			return(-1);
		}
	}

	/* script looping */ 
	if ((feof(net->script_fp)) && (net->conf.loop_script))
	{
		if (net->events) /* still have events to process */
			return(0);
		/* no more events: set a new start time, script time is 0  */
		gettimeofday(&net->start_time, NULL);
		now->tv_sec = now->tv_usec = 0;
		net->script_time_next.tv_sec = 0;
		net->script_time_next.tv_usec = 0;
		rewind(net->script_fp);
		return (0);
	}

	/* the time for the next event has not happened yet */
	if (timercmp(&net->script_time_next, now, >)) {
		return(0);
	}
	fetch_time.tv_sec = now->tv_sec + net->conf.prefetch_seconds;
	fetch_time.tv_usec = now->tv_usec;

	if (fgetpos(net->script_fp, &pos) < 0)
		wl_log("Error getting script position: %s\n",
			strerror(errno));
				       
	/* read more events from the scriptfile */
	while (fgets(line, SCRIPTED_LINE_SIZE, net->script_fp)) {
		/* ignore comments and empty lines in the script file */
		if ((line[0] == '#') || (line[0] == '\n') || (line[0] == ' '))
		  	continue;
		
		/* first token specifies time */
		cp = strtok(line, " ");
		if (!cp) break; /* no more tokens remain */
		type = strtok(NULL, " ");

		/* convert floating point time to struct timeval */
		float_tmp = strtof(cp, NULL);
		float_usec = modff(float_tmp, &float_sec) * 1000000.0;
		script_time.tv_sec = (long)float_sec;
		script_time.tv_usec = (long)float_usec;
		/* stop when the script event goes beyond now + prefetch */
		if (timercmp(&script_time, &fetch_time, >)) {
			if (fsetpos(net->script_fp, &pos) < 0)
				wl_log("Error setting script position: %s\n",
				       strerror(errno));
			/* wl_log("waiting for next event at %lu.%lu\n",
			       script_time.tv_sec, script_time.tv_usec); */
			net->script_time_next.tv_sec = script_time.tv_sec;
			net->script_time_next.tv_usec = script_time.tv_usec;
			break;
		}
		
		if (strcmp(type, "node") == 0) {
			/* wl_log("node: time %lu.%lu\n",
			       script_time.tv_sec, script_time.tv_usec); */
			scripted_add_node_event(net, &script_time);
		} else if (strcmp(type, "link") == 0) {
			/* wl_log("link: time %lu.%lu\n",
			       script_time.tv_sec, script_time.tv_usec); */
			scripted_add_link_event(net, &script_time);
		} else if (strcmp(type, "wlan") == 0) {
			/* wl_log("link: time %lu.%lu\n",
			       script_time.tv_sec, script_time.tv_usec); */
			scripted_add_wlan_event(net, &script_time);				
		} else {
			wl_log("warning: skipping script line of type '%s' at "
			       "time %lu.%lu\n", type, script_time.tv_sec,
			       script_time.tv_usec);
		}
		/* get the current file position, pointing to the previous
		 * event if we reach the end of the prefetch epoch */
		if (fgetpos(net->script_fp, &pos) < 0) {
			wl_log("Error reading script position: %s\n",
			       strerror(errno));
			return(-1);
		}
		
	} /* end while */
	return(0);
}

int
scripted_do_events(struct scripted_net *net, struct timeval *now)
{
	struct scripted_event *e, *next;
	struct scripted_event_node *ne;
	struct scripted_event_link *le;
	struct scripted_event_wlan *we;
	struct scripted_node *node1, *node2;

	e = net->events;
	while (e) {
		next = e->next;
		/* not time for this event yet; requires a sorted list */
		if (timercmp(&e->event_time, now, >))
			break;

		/* wl_log("== link event: time %u.%u now %u.%u\n",
			e->event_time.tv_sec, e->event_time.tv_usec,
			now->tv_sec, now->tv_usec); */
		if (e->event_type == scripted_event_type_node) {
			ne = (struct scripted_event_node *)e->event_data;
			if (send_node_message(NULL, 0, ne->node_id, net->net_id,
						0, ne->x, ne->y) < 0)
				break;
		} else if (e->event_type == scripted_event_type_link) {
			le = (struct scripted_event_link *)e->event_data;
			node1 = find_scripted_node(net, le->node1_id);
			node2 = find_scripted_node(net, le->node2_id);
			if (!node1 || !node2) {
				wl_log("node%c doesn't exist, skipping event\n",
				       (!node1) ? '1' : '2');
			} else if (le->params.per >= 100) {
				if (unlink_scripted_nodes(net->emu_id, node1,
					     node2->node_id, node2->emu_id) < 0)
					break;
			} else if (link_scripted_nodes(net->emu_id, node1,
						      node2, &le->params) < 0) {
				break;
			}
		} else if (e->event_type == scripted_event_type_wlan) {
			we = (struct scripted_event_wlan *)e->event_data;
#ifdef FREEBSD
			if (send_wlan_mer(control_sock, net->emu_id,
					  we->mer, we->mburst) < 0) {
				wl_log("Error setting multicast error rate.\n");
				break;
			}
#endif /* FREEBSD */
		}
		free(e->event_data);
		free(e);
		e = next;
	}
	net->events = e;
	return(0);
}

