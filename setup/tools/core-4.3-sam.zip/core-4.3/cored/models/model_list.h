/*
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * model.h
 * 
 * Generic structure for implementing wireless models.
 */
#ifndef _MODEL_LIST_H_
#define _MODEL_LIST_H_

#ifdef GPS_MODEL
#include "gps/gps.h"
#endif
#ifdef SIMPLE_MODEL
#include "simple/simple.h"
#endif
#ifdef SCRIPTED_MODEL
#include "scripted/scripted.h"
#endif
#ifdef RANDWAYP_MODEL 
#include "randwayp/randwayp.h"
#endif

#endif /* _MODEL_LIST_H_ */
