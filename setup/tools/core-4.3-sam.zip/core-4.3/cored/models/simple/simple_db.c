/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Simple range node DB.
 */

#include <stdlib.h> /* malloc */
#include <stdio.h>  /* sprintf */
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> /* for cored.h */
#include <inttypes.h>

#include <cored.h> 
#include "simple.h"
#include "simple_db.h"

static struct simple_net *net_list;

void
init_simple_db()
{
	net_list = NULL;
}

struct simple_net *get_net(uint32_t net_id, struct simple_net **prev)
{
	struct simple_net *net;
	
	if (prev)
		*prev = NULL;
	for (net = net_list; net; net = net->next) {
		if (net->net_id == net_id)
			return(net); /* found */
		if (prev)
			*prev = net;
	}
	return(NULL);
}

struct simple_net *new_net(uint32_t net_id, struct simple_net *prev)
{
	struct simple_net *net;

	/* allocate and initialize */
	net = malloc(sizeof(struct simple_net));
	if (!net)
		return NULL;
	bzero(net, sizeof(struct simple_net));
	net->net_id = net_id;
	net->node_list = malloc(sizeof(struct simple_node));
	bzero(net->node_list, sizeof(struct simple_node));
	net->conf.min_range = DEFAULT_MIN_RANGE;
	net->conf.max_range = DEFAULT_MAX_RANGE;
	net->conf.motion_threshhold = DEFAULT_MOTION_TRESHHOLD;
	net->conf.min_delay = DEFAULT_MIN_DELAY;
	net->conf.max_delay = DEFAULT_MAX_DELAY;
	net->conf.min_loss = DEFAULT_MIN_LOSS;
	net->conf.max_loss = DEFAULT_MAX_LOSS;
	net->conf.jitter   = DEFAULT_JITTER;
	net->conf.burst    = DEFAULT_BURST;
	net->conf.mc_loss  = DEFAULT_MC_LOSS;
	net->conf.mc_burst = DEFAULT_MC_BURST;
	/* link it to list */
	if (prev)
		prev->next = net;
	else
		net_list = net;
	return(net);
}

void
flush_nets()
{
	struct simple_net *net, *next_net;
	struct simple_node *node, *next_node;

	net = net_list;
	while (net) {
		next_net = net->next;
		node = net->node_list;
		while (node) {
			next_node = node->next;
			free_peers(node);
			free(node);
			node = next_node;
		}
		bzero(net, sizeof(struct simple_net));
		free(net);
		net = next_net;
	}
	net_list = NULL;
}

struct
simple_node *get_node_list(uint32_t net_id)
{
	struct simple_net *net, *prev;

	net = get_net(net_id, &prev);	
	if (!net) { /* net not found, add to the list */
		net = new_net(net_id, prev);
		if (!net) return NULL;
	}

	return(net->node_list);
}

void
flush_node_list(uint32_t net_id)
{
	struct simple_net *net, *prev;
	struct simple_node *node, *next_node;

	net = get_net(net_id, &prev);
	if (!net) /* net not found */
		return;

	node = net->node_list;
	while (node) {
		next_node = node->next;
		free_peers(node);
		free(node);
		node = next_node;
	}

	if (prev) {
		prev->next = net->next;
		bzero(net, sizeof(struct simple_net));
		free(net);
	} else {
		bzero(net, sizeof(struct simple_net));
		free(net);
		net_list = NULL;
	}
	
}

struct
simple_node *update_node_db(uint32_t net, uint32_t id, uint32_t emuid,
	uint32_t x, uint32_t y)
{
	struct simple_node *node, *prev, *node_list;

	prev = NULL;
	node_list = get_node_list(net);
	/* ASSERT(node_list) */
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) { /* not found - create new */
		/* emu_id==0 indicates no node (empty list) */
		if ((prev == node_list) && (node_list->emu_id==0)) { 
			/* first in list */
			node = node_list;
		} else {
			node = (struct simple_node *)
				malloc(sizeof(struct simple_node));
			if (!node) return(NULL);
			bzero(node, sizeof(struct simple_node));
			prev->next = node;
		}
		node->node_id = id;
		node->emu_id = emuid;
		node->peers = NULL;
	}
	node->emu_id = emuid;
	node->x = x;
	node->y = y;
	return(node);
}

int
remove_node_db(uint32_t net, uint32_t id)
{
	struct simple_node *node, *prev, *next, *node_list;

	prev = NULL;
	node_list = get_node_list(net);
	for (node = node_list; node; node = node->next) {
		if (node->node_id == id)
			break; /* found */
		prev = node;
	}

	if (!node) /* not found */
		return(-1);
	if (node == node_list) { /* don't delete the first node */
		free_peers(node_list);
		if (node->next) {
			next = node->next;
			memcpy(node_list, next, sizeof(struct simple_node));
			bzero(next, sizeof(struct simple_node));
			free(next);
		} else {
			bzero(node_list, sizeof(struct simple_node));
		}
	} else {
		prev->next = node->next;
		free_peers(node);
		bzero(node, sizeof(struct simple_node));
		free(node);
	}
	
	return(0);
}

void
debug_simple_db()
{
	static char dbuf[1024] = { 0 };
	char buf[1024], tmp[16];
	struct simple_net *net;
	struct simple_node *node;
	
	bzero(buf, sizeof(buf));

	for (net = net_list; net; net = net->next) {
		if (!net->node_list)
			continue;
		sprintf(tmp, "net 0x%x (", net->net_id);
		strncat(buf, tmp, sizeof(buf) - 1);
		for (node = net->node_list; node; node = node->next) {
			/*sprintf(tmp, "0x%x(%u,%u) ", node->node_id, 
				node->x, node->y);*/
			sprintf(tmp, "0x%x ", node->node_id);
			strncat(buf, tmp, sizeof(buf) - 1);
		}
		strncat(buf, ") ", sizeof(buf) - 1);
	}

	/* only print output when something has changed */
	if (strncmp(dbuf, buf, sizeof(dbuf))) { /* might be expensive */
		strncpy(dbuf, buf, sizeof(dbuf));
		wl_log("simple_db: %s\n", dbuf);
	}
}

void flag_all_peers(struct simple_node *node, uint32_t flags)
{
	struct simple_node_link *n;

	for (n = node->peers; n; n=n->next) {
		if (n->flags != LINK_FLAG_UNLINKED)
			n->flags = flags;
	}
}

int add_peer(struct simple_node *node, struct simple_node *p, uint32_t flags)
{
	struct simple_node_link *peer, *prev;

	prev = NULL;
	for (peer = node->peers; peer; peer = peer->next) {
		/* peer exists, flag and exit */
		if (peer->node_id == p->node_id) {
			peer->emu_id = p->emu_id;
			peer->flags = flags;
			return(0);
		}
		prev = peer;
	}

	/* peer does not exist */
	peer = malloc(sizeof(struct simple_node_link));
	if (!peer) return(-1);
	peer->node_id = p->node_id;
	peer->emu_id = p->emu_id;
	peer->flags = flags;
	peer->next = NULL;
	if (prev) {
		prev->next = peer;
	} else {
		node->peers = peer;	
	}
	return(0);
}

void free_peers(struct simple_node *node)
{
	struct simple_node_link *peer, *next;
	peer = node->peers;
	while (peer) {
		next = peer->next;
		free(peer);
		peer = next;
	}
}

