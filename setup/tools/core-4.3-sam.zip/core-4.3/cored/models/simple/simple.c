/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Simple range definitions.
 */
#include <stdio.h>
#include <stdlib.h>	/* abs() */
#include <strings.h>	/* bzero */
#include <string.h>	/* strlen() */
#include <inttypes.h>	/* PRIu64 */
#include <sys/types.h>  /* for cored.h */
#include <sys/socket.h> /* for cored.h */
#include <netinet/in.h> /* htonl() in core_api.h */
#include <math.h>
#include <cored.h>
#include <coreapi/coreapi.h> /* reqd for handling config messages */
#include <models/model.h> 
#include "simple.h"
#include "simple_db.h"

struct core_wlan_model simple_model = {
	.model_name = "simple",
	.model_type = MODEL_TYPE_WIRELESS,
	.model_state = MODEL_STATE_UNINIT,
	.init = init_simple,
	.conf = config_simple,
	.flush = simple_flush_nodes,
	.update = simple_update_node,
	.remove = simple_remove_node,
	.periodic = NULL,
	.debug = debug_simple,
	.link = link_nodes,	/* from cored */
	.unlink = unlink_nodes,	/* from cored */
	.model_next = NULL,
};

extern int control_sock;
int send_wlan_mer(int, uint32_t, uint16_t, uint16_t); /* bsd/core_netgraph.c */

/* local functions */
int simple_config_to_string(struct simple_net_config *c, uint8_t *to);
int string_to_simple_config(uint8_t *, int, struct simple_net_config *);
void log_simple_config(struct simple_net_config *c);
int link_simple_nodes(uint32_t net_id, struct simple_node *a, 
	struct simple_node *b, struct link_params *params);
int unlink_simple_nodes(uint32_t, struct simple_node *, uint32_t, uint32_t);
uint32_t distance_between_nodes(struct simple_node *a, struct simple_node *b);
uint64_t delay_between_nodes(struct simple_net *net, uint32_t distance);
uint16_t loss_between_nodes(struct simple_net *net, uint32_t distance);
void simple_set_wlan_mer(struct simple_net *net);


void
init_simple()
{
	init_simple_db();
	simple_model.model_state = MODEL_STATE_INIT;
	wl_log("Simple range model loaded.\n");
}

int
config_simple(uint16_t flags, uint8_t *config_data, uint16_t config_len)
{
	struct simple_net *net, *net2, *prev;
	struct core_api_tlv *tlv;
	uint32_t wlan_node_num, wlan_id;
	uint16_t len = config_len;
	uint16_t types[12] = SIMPLE_NET_DATA_INIT;
	uint8_t data[255], capt[135] = SIMPLE_NET_CAPTIONS;
	uint8_t bmp[32] = SIMPLE_NET_BITMAP;
	int data_len;

	/* WLAN node number used as net id */
	core_api_parse_message(config_data, &len);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NODE);
	if (core_api_get_tlv_val32(tlv, &wlan_node_num) < 0) {
		wl_log("config_simple(): missing node number\n");
		return(-1);
	}

	/* use node ID to store config data */
	net = get_net(wlan_node_num, &prev);	
	if (!net) { /* net not found, add new one to the list */
		net = new_net(wlan_node_num, prev);
		if (!net) {
			wl_log("config_simple(): unable to add new net\n");
			return(-1);
		}
	}

	/* receive node ID -> netgraph ID mapping and return */
	if (flags & CONF_TYPE_FLAGS_UPDATE) {
		/* use netgraph ID instead of node ID */
		tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_NETID);
		if (core_api_get_tlv_val32(tlv, &wlan_id) < 0) {
			wl_log("config_simple(): conf update missing netid\n");
			return(-1);
		}
		net2 = get_net(wlan_id, &prev);	
		if (!net2) {
			net2 = new_net(wlan_id, prev);
			if (!net2) {
				wl_log("config_simple(): unable to add new "
					"net2\n");
				return(-1);
			}
		}
		memcpy(&net2->conf, &net->conf, sizeof(net->conf));
		net->emu_id = net2->emu_id = wlan_id;
		/* if multicast loss was configured, attempt to set it here */
		simple_set_wlan_mer(net2);
		return(0);
	}

	/* provide configuration parameters and return */
	if (flags & CONF_TYPE_FLAGS_REQUEST) {
		wl_log("Simple range model, handling config request for wlan"
			"%d...\n", wlan_node_num);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_DATA_TYPES, 
				sizeof(types), (uint8_t*)&types);
		data_len = simple_config_to_string(&net->conf, data);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_VALUES, 
				data_len, (uint8_t*)data);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_CAPTIONS, 
				strlen((char*)capt), capt);
		len += core_api_create_tlv(&config_data[len],
				CORE_TLV_CONF_BITMAP, 
				strlen((char*)bmp), bmp);
		core_api_message_set_length(config_data, 
				len - sizeof(struct core_api_msg));
		wl_log("Sending the config: ");
		log_simple_config(&net->conf);
		wl_log("\n");		
		/* returns the length of bytes used in the new TLV */
		return len;
	}

	/* parse configuration parameters */
	wl_log("Simple range model, handling config data for wlan%d...\n",
		wlan_node_num);
	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_DATA_TYPES);
	if (!tlv) {
		wl_log("config_simple(): missing data types\n");
		return(-1);
	}
	if (memcmp(tlv->value, &types, sizeof(types))!=0) {
		wl_log("config_simple(): data types wrong size\n");
		return(-1);
	}

	tlv = core_api_get_tlv(config_data, CORE_TLV_CONF_VALUES);
	if (!tlv) {
		wl_log("config_simple(): missing data values\n");
		return(-1);
	}
	string_to_simple_config(tlv->value, tlv->length, &net->conf);

	wl_log("Accepted config for wlan%d: ", wlan_node_num);
	log_simple_config(&net->conf);
	wl_log("\n");
	/* try to update multicast loss in case it has changed */
	if ((net->emu_id > 0) && (net2 = get_net(net->emu_id, &prev))) {
		net2->conf.mc_loss = net->conf.mc_loss; /* use new value */
		net2->conf.mc_burst = net->conf.mc_burst;
		simple_set_wlan_mer(net2);
	}
	
	return 0;
}

/* convert the config struct to a '|' delimited string */
int
simple_config_to_string(struct simple_net_config *c, uint8_t *to)
{
	return sprintf((char*)to, "%u|%u|%u|%" PRIu64 "|%" PRIu64 
			"|%u|%u|%u|%u|%u|%u|%u",
			c->min_range, c->max_range, c->motion_threshhold,
			c->min_delay, c->max_delay, c->min_loss, c->max_loss,
			c->burst, c->dup, c->jitter,
			c->mc_loss, c->mc_burst);
}

/* convert the '|' delimited string to a config struct */
int
string_to_simple_config(uint8_t *from, int from_len, 
			struct simple_net_config *c)
{
	return sscanf((char*)from, 
			"%u|%u|%u|%" PRIu64 "|%" PRIu64 
			"|%hu|%hu|%hu|%hu|%u|%hu|%hu",
			&c->min_range, &c->max_range, &c->motion_threshhold,
			&c->min_delay, &c->max_delay, &c->min_loss,
			&c->max_loss, &c->burst, &c->dup, &c->jitter,
			&c->mc_loss, &c->mc_burst);
}

void
log_simple_config(struct simple_net_config *c)
{
	if (!c) {
		wl_log("<null>");
		return;
	}
	wl_log("[range: %u-%u, thresh: %u, delay: %llu-%llu, loss: %u-%u burst:"
		" %u dup: %u jitter: %u mer: %u mburst: %u]",
		c->min_range, c->max_range, c->motion_threshhold,
		c->min_delay, c->max_delay, c->min_loss, c->max_loss, c->burst,
		c->dup, c->jitter, c->mc_loss, c->mc_burst);
}

void
simple_flush_nodes(uint16_t flags, uint32_t net_id)
{
	if (flags & FLUSH_FLAGS_ALL_NODES)
		flush_nets();
	else
		flush_node_list(net_id);
}

int
simple_update_node (uint16_t flags, uint32_t net_id, uint32_t id,
	uint32_t emu_id, uint32_t x, uint32_t y) 
{
	struct simple_net *net;
	struct simple_node *node, *peer;
	struct simple_node_link *lpeer;
	struct link_params params;
	uint32_t d;

	wl_log("simple_update_node(net=%x, id=%x, emu=%x, %u, %u)\n",
		net_id, id, emu_id, x, y); // */
	node = update_node_db(net_id, id, emu_id, x, y);
	if (!node)
		return(-1);

	net = get_net(net_id, NULL);
	if (!net)
		return(-1);

	/* compare old x,y and calculate only if above threshold */
	if ( !(flags & CORE_API_CRI_FLAG) &&
	     ( (abs(x - node->prev_x) + abs(y - node->prev_y))
	     < net->conf.motion_threshhold) )
		return(0); /* assume update not needed */
	node->prev_x = x;
	node->prev_y = y;

	flag_all_peers(node, LINK_FLAG_UNLINK_PENDING);

	for (peer = get_node_list(net_id); peer; peer = peer->next) {
		if (node == peer)
			continue;
		d = distance_between_nodes(node, peer);
		if (d <= net->conf.max_range) {
			bzero(&params, sizeof(params));
			params.delay = delay_between_nodes(net, d);
			params.bw = 0; /* currently unused */
			params.per = loss_between_nodes(net, d);
			params.dup = net->conf.dup; /* static params */
			params.jitter = net->conf.jitter;
			params.burst = net->conf.burst;
			/* this incurs a malloc for the first encounter */
			add_peer(node, peer, LINK_FLAG_LINKED);
			link_simple_nodes(net_id, node, peer, &params);
		}
		// if unidirectional, calculate (peer, node)
	}

	for (lpeer = node->peers; lpeer; lpeer = lpeer->next) {
		/* we never free peers from this list, only flag them */
		if (lpeer->flags == LINK_FLAG_UNLINK_PENDING) {
			unlink_simple_nodes(net_id, node, lpeer->node_id, 
				lpeer->emu_id);
			lpeer->flags = LINK_FLAG_UNLINKED;
		}
	}
	return(0);
}

int
simple_remove_node (uint32_t net_id, uint32_t id)
{
	int err = remove_node_db(net_id, id);
	/* TODO: remove links */
	return(err);
}

void
debug_simple(int periodic)
{
	debug_simple_db();
}

int
link_simple_nodes(uint32_t net_id, struct simple_node *a,
	struct simple_node *b, struct link_params *params)
{
	uint32_t lt_id, gt_id, lt_emu_id, gt_emu_id;
	/* TODO: don't sort nodes here if links are asymmetric */
	if (a->node_id < b->node_id) {
		lt_id = a->node_id;
		lt_emu_id = a->emu_id;
		gt_id = b->node_id;
		gt_emu_id = b->emu_id;
	} else {
		lt_id = b->node_id;
		lt_emu_id = b->emu_id;
		gt_id = a->node_id;
		gt_emu_id = a->emu_id;
	}
	return(simple_model.link(net_id, lt_id, gt_id, lt_emu_id, gt_emu_id,
		params));
}

int
unlink_simple_nodes(uint32_t net_id, struct simple_node *a, uint32_t b_id,
	uint32_t b_emu_id)
{
	uint32_t lt_id, gt_id, lt_emu_id, gt_emu_id;
	/* TODO: don't sort nodes here if links are asymmetric */
	if (a->node_id < b_id) {
		lt_id = a->node_id;
		lt_emu_id = a->emu_id;
		gt_id = b_id;
		gt_emu_id = b_emu_id;
	} else {
		lt_id = b_id;
		lt_emu_id = b_emu_id;
		gt_id = a->node_id;
		gt_emu_id = a->emu_id;
	}
	return(simple_model.unlink(net_id, lt_id, gt_id, lt_emu_id, gt_emu_id));
}

/* FreeBSD 4.11 doesn't have lrint() */
#if 0
#define lrint rint
#endif

uint32_t
distance_between_nodes(struct simple_node *a, struct simple_node *b)
{
	double dx, dy, dist;
	if (!a || !b)
		return(0);
	dx = (double)a->x - (double)b->x;
	dy = (double)a->y - (double)b->y;
	dist = hypot(dx, dy);
	return ( (uint32_t) lrint(dist) );
}

uint64_t
delay_between_nodes(struct simple_net *net, uint32_t distance)
{
	uint64_t min_delay, max_delay;
	uint32_t range_min, range_max;
	double delay, factor;

	min_delay = net->conf.min_delay;
	max_delay = net->conf.max_delay;
	range_min = net->conf.min_range;
	range_max = net->conf.max_range;

	if (distance < range_min)
		return(min_delay);
	if (range_max == range_min) /* avoid div by zero */
		return(max_delay);
	
	factor = (double)(distance - range_min)/(double)(range_max - range_min);
	delay = min_delay + (factor * (max_delay - min_delay));
	return( (uint64_t)delay);
}

uint16_t
loss_between_nodes(struct simple_net *net, uint32_t distance)
{
	uint16_t min_loss, max_loss;
	uint32_t range_min, range_max;
	double loss, factor;

	min_loss = net->conf.min_loss;
	max_loss = net->conf.max_loss;
	range_min = net->conf.min_range;
	range_max = net->conf.max_range;

	if (distance < range_min)
		return(min_loss);
	if (range_max == range_min) /* avoid div by zero */
		return(max_loss);
	
	factor = (double)(distance - range_min)/(double)(range_max - range_min);
	loss = min_loss + (factor * (max_loss - min_loss));
	return( (uint16_t)loss);
}

void
simple_set_wlan_mer(struct simple_net *net)
{
	if (!net || net->conf.mc_loss == 0)
		return;
	if (net->emu_id == 0) 
		return;
#ifdef FREEBSD
	if (send_wlan_mer(control_sock, net->emu_id, net->conf.mc_loss,
				net->conf.mc_burst) < 0)
		wl_log("Error setting multicast error rate.\n");
	else
#endif /* FREEBSD */
		wl_log("Setting multicast error rate to %d%% burst %d%%% for "
			"WLAN 0x%x\n",
			net->conf.mc_loss, net->conf.mc_burst, net->emu_id);
}
