/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Simple range node DB definitions.
 */
#ifndef SIMPLE_DB_H
#define SIMPLE_DB_H

#define MIN_BUCKETS 512
#define SIMPLE_DB_HASH(a, b)  ((a | (b << 16)) % MIN_BUCKETS)

struct simple_net_config {
	uint32_t min_range;
	uint32_t max_range;
	uint32_t motion_threshhold;
	uint64_t min_delay;
	uint64_t max_delay;
	uint16_t min_loss;
	uint16_t max_loss;
	uint16_t burst;
	uint16_t dup;
	uint32_t jitter;
	uint16_t mc_loss;
	uint16_t mc_burst;
};

struct simple_net {
	uint32_t net_id;
	uint32_t emu_id;
	struct simple_node *node_list;
	struct simple_net *next;
	struct simple_net_config conf;
};

#define SIMPLE_NET_DATA_INIT { htons(3), htons(3), htons(3), \
				htons(4), htons(4), htons(2), htons(2), \
				htons(2), htons(2), htons(3), htons(2), \
				htons(2) \
				}
#define SIMPLE_NET_CAPTIONS "min range|max range|motion threshhold|min delay|max delay|min loss|max loss|burst|duplicates|jitter|multicast loss|multicast burst\0"

#define SIMPLE_NET_BITMAP "icons/normal/simple.xbm\0"

struct simple_node {
	uint32_t node_id;
	uint32_t emu_id;
	uint32_t x;
	uint32_t y;
	uint32_t prev_x;
	uint32_t prev_y;
	struct simple_node_link *peers;
	struct simple_node *next;
};

#define LINK_FLAG_NONE 0
#define LINK_FLAG_LINKED 1
#define LINK_FLAG_UNLINKED 2
#define LINK_FLAG_UNLINK_PENDING 3

struct simple_node_link {
	uint32_t node_id;
	uint32_t emu_id;
	uint32_t flags;
	struct simple_node_link *next;
};

void init_simple_db();
struct simple_net *get_net(uint32_t net_id, struct simple_net **prev);
struct simple_net *new_net(uint32_t net_id, struct simple_net *prev);
void flush_nets();
struct simple_node *get_node_list(uint32_t net_id);
void flush_node_list(uint32_t net_id);
struct simple_node *update_node_db(uint32_t, uint32_t, uint32_t, uint32_t,
	uint32_t);
int  remove_node_db(uint32_t net, uint32_t id);
void debug_simple_db();
void flag_all_peers(struct simple_node *node, uint32_t flags);
int  add_peer(struct simple_node *, struct simple_node *, uint32_t);
void free_peers(struct simple_node *node);

#endif /* SIMPLE_DB_H */
