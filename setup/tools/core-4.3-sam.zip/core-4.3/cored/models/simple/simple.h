/* 
 * CORE WLAN
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Simple range definitions.
 */
#ifndef SIMPLE_H
#define SIMPLE_H

#include "../model.h"

#define DEFAULT_MIN_RANGE 200
#define DEFAULT_MAX_RANGE 350
#define DEFAULT_MOTION_TRESHHOLD 5
#define DEFAULT_MIN_DELAY 50000		/* 50ms  */
#define DEFAULT_MAX_DELAY 500000	/* 500ms */
#define DEFAULT_MIN_LOSS 0		/* 0%    */
#define DEFAULT_MAX_LOSS 15		/* 15%   */
#define DEFAULT_DUP 0			/* 0ms   */
#define DEFAULT_BURST 0			/* 0%    */
#define DEFAULT_JITTER 0		/* 0ms   */
#define DEFAULT_MC_LOSS 0		/* 0%    */
#define DEFAULT_MC_BURST 0		/* 0%    */

extern struct core_wlan_model simple_model;

void init_simple();
int config_simple(uint16_t flags, uint8_t *config_data, uint16_t config_len);
void simple_flush_nodes(uint16_t flags, uint32_t net_id);
int simple_update_node(uint16_t, uint32_t, uint32_t, uint32_t, uint32_t,
		uint32_t);
int simple_remove_node(uint32_t net, uint32_t id);
void debug_simple(int periodic);

#endif /* SIMPLE_H */
