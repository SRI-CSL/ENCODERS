/*
 * CORE 
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * core_emu.h
 * 
 * Generic structure for implementing emulation functions.
 */
#ifndef _CORE_EMU_H_
#define _CORE_EMU_H_

#include <inttypes.h> /* uint32_t, etc */

struct core_node_data;
struct core_link_data;

struct core_emu {
	char *name;
	int  (*init)();
	int  (*node)(uint16_t flags, uint32_t node,
			struct core_node_data *data);
	int  (*link)(uint16_t flags, uint32_t node1, uint32_t node2,
			struct core_link_data *data);
	int  (*exec)(uint16_t flags, uint32_t node, uint32_t exec_id, 
			uint32_t exec_time, uint8_t *exec_cmd,
			uint8_t *exec_resp, uint32_t exec_result);
};

extern struct core_emu *g_emu;

#endif /* _CORE_EMU_H_ */
