/*
 * CORE Span
 * (c)2010 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * spantap.h
 *
 * Functions for managing the TUN/TAP virtual interface.
 *
 */
#ifndef _SPAN_TAP_H_
#define _SPAN_TAP_H_

#ifdef FREEBSD
#define DEFAULT_TAP_NAME "tap"
#else
#define DEFAULT_TAP_NAME "core"
#endif
#define DEFAULT_TAP_ADDR "10.253.0.1"
#define DEFAULT_TAP_NET  "24"

#ifdef WIN32
typedef unsigned _int64 __u64;
typedef unsigned long uint32_t;
extern int readsp[2];
extern HANDLE hTAP32;
#endif 

/* function declarations */
int init_tap(char *tapname, char *ipnet);

#endif /* _SPAN_TAP_H_ */
