/*
 * CORE Span
 * (c)2010 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * spantap.c
 *
 * Functions for managing the TUN/TAP virtual interface.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#ifndef WIN32
#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <sys/ioctl.h>		/* ioctl() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select() */
#include <fcntl.h>		/* open() */
#endif /* !WIN32 */
#ifdef FREEBSD
#include <net/if.h>		/* TAP support */
#else /* FREEBSD */
#ifdef WIN32
#include <windows.h>		/* WIN32 types */
#include <windowsx.h>
#include <Winsock2.h>		/* htonl() */
#include <WinIoCtl.h>		/* for TAP macros */
#include <iprtrmib.h>		/* RIB entries */
#include <process.h>		/* _beginthread() */
#include "win32/openvpn-common.h"
#define REG_INTERFACES_KEY \
	"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces"
#else /* WIN32 */
#include <linux/if.h>		/* TAP support */
#include <linux/if_tun.h>	/* TAP support */
#endif /* WIN32 */
#endif /* FREEBSD */

#include "span.h"
#include "spantap.h"

/* convert a.b.c.d/n to IP and netmask */
int ipnet_to_ipmask(char *ipnet, char *ip, char *mask, int len) 
{
	char *cp;
	int net;
	uint32_t net_bits;

	memset(ip, 0, len);
	memset(mask, 0, len);

	/* build IP string */
	cp = strchr(ipnet, '/');
	if (!cp)
		return(-1);
	if ((cp - ipnet) > len)
		return(-1);
	strncpy(ip, ipnet, (cp - ipnet));

	/* build a netmask string from the given net (/24 = 255.255.255.0) */
	sscanf(cp+1, "%d", &net);
	if ((net < 1) || (net > 32)) {
		net = 32;
	}
	for (net_bits = 0; net > 0; net--) net_bits = (net_bits << 1) | 1;
	sprintf(mask, "%u.%u.%u.%u", NIPQUAD(net_bits));
	return(0);
}


#ifndef WIN32
/*
 * Linux/FreeBSD TAP initialization
 */
int
init_tap(char *tapname, char *ipnet)
{
	int tap, err;
	char cmd[255], sIP[17], sMask[17];

#ifdef FREEBSD
	if ((tap = open("/dev/tap0", O_RDWR)) < 0) {
		sp_log("Could not open the TAP device. Do you have the kernel");
		sp_log(" module loaded (kldload if_tap)?\n");
		return(-1);
	}
#else
	struct ifreq ifr;

	if ((tap = open("/dev/net/tun", O_RDWR)) < 0) {
		sp_log("Could not open the TAP device. Do you have the kernel");
		sp_log(" module loaded (modprobe tun)?\n");
		return(-1);
	}

        /* setup address */
        memset(&ifr, 0, sizeof(ifr));
        ifr.ifr_flags = IFF_TAP;        /* TAP device */
        ifr.ifr_flags |= IFF_NO_PI;     /* Do not provide packet information */
        sprintf(ifr.ifr_name, "%s", tapname);

        /* set TAP status to connected */
        if ((err = ioctl(tap, TUNSETIFF, (void*)&ifr)) < 0) {
                close(tap);
                sp_log("Error setting TAP parameters.\n");
                return(-1);
        }

#endif /* FREEBSD */

	if (ipnet) { /* setup the given address */
		if (ipnet_to_ipmask(ipnet, sIP, sMask, sizeof(sIP)) < 0) {
			sp_log("Invalid address specified: %s\n", ipnet);
			return(-1);
		}
		sprintf(cmd, "/sbin/ifconfig %s %s netmask %s up\n", 
			tapname, sIP, sMask);
	} else { /* no address supplied */
		sprintf(cmd, "/sbin/ifconfig %s up\n", tapname);
	}

	if ((err = system(cmd)) != 0)
		sp_log("Error running '%s'.\n", cmd);
	/* we're not using RTNETLINK here since it doesn't exist on FreeBSD */

	sp_log("Using TAP device %s with address %s.\n", tapname, 
		ipnet ? ipnet : "<none>" );
	return tap;
}

#else /* WIN32 */

struct tap32_data  /* data type used for tunreader argument */
{
	HANDLE hTAP32;	/* handle for scheduling receive events */
	int tapfd;	/* one end of the socketpair for writing data */
};
HANDLE hTAP32 = INVALID_HANDLE_VALUE;
static __inline unsigned __int64 __hton64( unsigned __int64 i )
{
        return ((unsigned __int64)(htonl((unsigned int)(i) & 0xffffffff)) << 32)
                | htonl((unsigned int)(((i) >> 32) & 0xffffffff ));
}
#define hton64(i)   __hton64( i )
#define ntoh64(i)   __hton64( i )

extern int socketpair(int d, int type, int protocol, unsigned int *sp);
void tunreader(void *arg);
int check_and_set_tun_address(char *devid, char *ipnet);
__u64 gid_to_mac(char *data);
void sp_WinError(int code);

/*
 * Windows TAP initialization
 */
int init_tap(char *tapname, char *ipnet)
{
	HKEY key;
	int enum_index;
	char devid[1024], devname[1024];
	long len;
	ULONG status = TRUE;
	unsigned int tunreader_thrd;
	int readsp[2] = { -1, -1 };
	struct tap32_data tap32d;
	/* MIB_IPFORWARDROW route; */


	/* Prepare to iterate through the Network Adapters key
	 */
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, NETWORK_CONNECTIONS_KEY, 0, 
	    KEY_READ, &key)) {
		sp_log("Unable to read Network Adapters from registry!\n");
		return -1;
	}

	/* find the next available adapter where we can open a device having
	 * the name:
	 *  \\.\Global\devid.tap 
	 */
	for (enum_index = 0; ; enum_index++) {
		len = sizeof(devid);
		if(RegEnumKeyEx(key, enum_index, devid, &len, 
				0, 0, 0, NULL) != ERROR_SUCCESS) {
			RegCloseKey(key);
			sp_log("Couldn't find available TAP-Win32 adapter for "
				"%s\n", tapname);
			return -1;
		}
	
		sprintf(devname, USERMODEDEVICEDIR "%s" TAPSUFFIX, devid);
		hTAP32 = CreateFile(devname, GENERIC_WRITE | GENERIC_READ,
			    0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM, 0);
		
		if(hTAP32 != INVALID_HANDLE_VALUE) {
			RegCloseKey(key);
			CloseHandle(hTAP32);
			break;
		}
	}
	
#if 0
	/* Get the MAC address of the TAP-Win32 
	 * which is of the form 00:FF:{GID} 
	 */
	g_tap_mac = gid_to_mac(devid+1);
#endif

	if (ipnet && (check_and_set_tun_address(devid, ipnet) < 0)) {
		sp_log("TAP-Win32 setup failed for %s with address %s.\n",
			tapname, ipnet);
		return -1;
	}

	/* Open TAP-Win32 device */
	hTAP32 = CreateFile(devname, GENERIC_WRITE|GENERIC_READ, 0, 0,
		    OPEN_EXISTING, 
		    FILE_ATTRIBUTE_SYSTEM | FILE_FLAG_OVERLAPPED, 0);
	if (hTAP32 == INVALID_HANDLE_VALUE) {
		sp_log("Could not open Windows tap device %s\n", tapname);
		return -1;
	}

	/* set TAP-32 status to connected */
	if (!DeviceIoControl (hTAP32, TAP_IOCTL_SET_MEDIA_STATUS,
			&status, sizeof (status),
			&status, sizeof (status), &len, NULL)) {
		sp_log("failed to set TAP-Win32 status as 'connected' for "
			"device %s.\n", tapname);
		return -1;
	}
	
	/* also add route for 1.0.0.0/8 to TAP-Win32 */
#if 0
	memset(&route, 0, sizeof(route));
	route.dwForwardDest = htonl(0x01000000L);
	route.dwForwardMask = htonl(0xFF000000L);
	CreateIpForwardEntry(&route);
#endif
	/* This is the name that the peer uses in sh->dst to locate the
	 * TAP connection "core0", not the actual device name such as 
	 * "Local Area Connection 2"
	 */

	/* Create socketpair so we can process in select_loop() */
	if (socketpair(AF_UNIX, SOCK_DGRAM, PF_UNIX, readsp)) {
		sp_log("socketpair() failed\n");
		return -1;
	}

	/* Create thread to handle overlapped events and write to socketpair */
	tap32d.hTAP32 = hTAP32;
	tap32d.tapfd = readsp[0];
	if (!(tunreader_thrd = _beginthread(tunreader, 0, (void *)&tap32d))) {
		sp_log("failed to create tunreader thread.\n");
		return -1;
	}

	sp_log("Using TAP device %s with address %s.\n", tapname,
		ipnet ? ipnet : "<none>" );

	return readsp[1];
}

/*
 * Check the static IP address for the TAP device and set it if necessary.
 */
int check_and_set_tun_address(char *devid, char *ipnet)
{
	HKEY interface_key, key;
	DWORD dwVal, dwKeyType, dwBufLen;
	char path[1024], value[512], sIP[17], sMask[17];
	int enum_index, need_setup = 0;
	long len;

	if (ipnet_to_ipmask(ipnet, sIP, sMask, sizeof(sIP)) < 0) {
		sp_log("Invalid address specified: %s\n", ipnet);
		return(-1);
	}

	/*
	 * Check registry values for 
	 * IPAddress, SubnetMask, and EnableDHCP
	 */
	sprintf (path, "%s\\%s", REG_INTERFACES_KEY, devid);
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, path, 0, KEY_READ, &interface_key)
		!= ERROR_SUCCESS) {
		sp_log("Error opening registry key: %s", path);
		return(-1);
	}
	dwBufLen = sizeof(value);
	if (RegQueryValueEx(interface_key, "IPAddress", NULL, &dwKeyType,
		value, &dwBufLen) != ERROR_SUCCESS) {
		sp_log("Unable to read IP address, doing setup.\n");
		need_setup = 1;
	}
	if ((dwKeyType != REG_MULTI_SZ) || 
	    (strncmp(value, sIP, strlen(sIP)+2) != 0)) {
		need_setup = 1;
	}
	dwBufLen = sizeof(value);
	if (RegQueryValueEx(interface_key, "SubnetMask", NULL, &dwKeyType,
		value, &dwBufLen) != ERROR_SUCCESS) {
		sp_log("Unable to read network mask, doing setup.\n");
		need_setup = 1;
	}
	if ((dwKeyType != REG_MULTI_SZ) || 
	    (strncmp(value, sMask, strlen(sMask)+2) != 0)) {
		need_setup = 1;
	}
	dwBufLen = sizeof(dwVal);
	if (RegQueryValueEx(interface_key, "EnableDHCP", NULL, &dwKeyType,
		(LPBYTE)&dwVal, &dwBufLen) != ERROR_SUCCESS) {
		sp_log("Unable to read DHCP setting, doing setup.\n");
		need_setup = 1;
	}
	if ((dwKeyType != REG_DWORD) || (dwVal != 0x0)) {
		need_setup = 1;
	}
			
	RegCloseKey(interface_key);
	if (!need_setup)
		return(0);
	
	/* 
	 * Write the new values to the registry 
	 */
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, path, 0,
			 KEY_WRITE, &interface_key) != ERROR_SUCCESS) {
		sp_log("Error opening registry key: %s", path);
		return(-1);
	}
	if (RegSetValueEx(interface_key, "IPAddress", 0, REG_MULTI_SZ,
		sIP, strlen(sIP)+2) != ERROR_SUCCESS) {
		sp_log("Changing TAP-Win32 adapter's IP address failed\n");
		return(-1);
	}
	if (RegSetValueEx(interface_key, "SubnetMask", 0, REG_MULTI_SZ,
		sMask, strlen(sMask)+2) != ERROR_SUCCESS) {
		sp_log("Changing TAP-Win32 adapter's IP mask failed\n");
		return(-1);
	}
	dwVal = 0x0;
	if (RegSetValueEx(interface_key, "EnableDHCP", 0, REG_DWORD,
		(LPBYTE)&dwVal, sizeof(dwVal)) != ERROR_SUCCESS) {
		sp_log("Changing TAP-Win32 adapter's DHCP setting failed\n");
		return(-1);
	}
	RegCloseKey(interface_key);

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, ADAPTER_KEY, 0, 
			 KEY_READ, &key) != ERROR_SUCCESS) {
		sp_log("Error opening registry key: %s", ADAPTER_KEY);
		return(-1);
	}
	/* find the adapter with TAP_COMPONENT_ID (tap0801) */
	for (enum_index = 0; ; enum_index++) {
		len = sizeof(value);
		if(RegEnumKeyEx(key, enum_index, value, &len, 
				0, 0, 0, NULL) != ERROR_SUCCESS) {
			RegCloseKey(key);
			return(0); /* silently exit if not found */
		}
		sprintf(path, "%s\\%s", ADAPTER_KEY, value);
		if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, path, 0, KEY_READ, 
				&interface_key) != ERROR_SUCCESS)
			continue;
		dwBufLen = sizeof(value);
		if (RegQueryValueEx(interface_key, "ComponentId", NULL, 
			    &dwKeyType, value, &dwBufLen) != ERROR_SUCCESS) {
			RegCloseKey(interface_key);
			continue;
		}
		RegCloseKey(interface_key);
		if ((dwKeyType != REG_SZ) || 
		    (strncmp(value, TAP_COMPONENT_ID, 
			     strlen(TAP_COMPONENT_ID)) != 0)) {
			continue;
		}
		break;	
	}

#if 0
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, path, 0, KEY_WRITE, 
			&interface_key) != ERROR_SUCCESS) {
		sp_log("Unable to set TAP MTU.\n");
		return(0); /* non-fatal */
	}
	if (RegSetValueEx(interface_key, "MTU", 0, REG_SZ,
			"1400", strlen("1400")) != ERROR_SUCCESS) {
		sp_log("Changing TAP-Win32 MTU failed.\n");
	}
#endif 
	RegCloseKey(interface_key);
	return(0);
}

/* this is from TAP-Win32 driver/macinfo.c */
unsigned char HexStringToDecimalInt (unsigned char p_Character)
{
    unsigned char l_Value = 0;

    if (p_Character >= 'A' && p_Character <= 'F')
        l_Value = (p_Character - 'A') + 10;
    else if (p_Character >= 'a' && p_Character <= 'f')
        l_Value = (p_Character - 'a') + 10;
    else if (p_Character >= '0' && p_Character <= '9')
        l_Value = p_Character - '0';

    return l_Value;
}


/* Convert first 8 bytes of adapter's GID to a MAC address, 
 * of the form: 00:FF:{gid}, in network byte order, ready
 * for use in an Ethernet header */
__u64 gid_to_mac(char *data)
{
        int i;
        unsigned char val;
        __u64 mac = 0;

        for (i=0; i<8; i += 2) {
                val = HexStringToDecimalInt(data[i+1]);
                val |= (HexStringToDecimalInt(data[i]) << 4);
                mac |=  val << (24 - (4*i));
        }

        mac &= 0x00FFFFFFFFFF;
        mac |= 0x00FF00000000;
        return(hton64(mac) >> 16);
}

/* For Windows, use overlapped event notification */
#define TUNREADER_BUF_LEN 2000
void tunreader(void *arg)
{
        DWORD len;
        char buf[TUNREADER_BUF_LEN];
        OVERLAPPED overlapped;
        int status;
	struct tap32_data *tap32d = (struct tap32_data*)arg;
	HANDLE taph;
	int tapfd;

	if (!tap32d) {
		sp_log("tunreader() called with invalid argument!\n");
		return;
	}
	taph = tap32d->hTAP32;
	tapfd = tap32d->tapfd;
        sp_log("tunreader(%p, %d) thread started...\n",
		tap32d->hTAP32, tap32d->tapfd);

        overlapped.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

        while (1) {
                overlapped.Offset = 0;
                overlapped.OffsetHigh = 0;
                ResetEvent(overlapped.hEvent);

                status = ReadFile(taph, buf, TUNREADER_BUF_LEN, 
				  &len, &overlapped);
                if (!status) {
                        if (GetLastError() == ERROR_IO_PENDING) {
                                WaitForSingleObject(overlapped.hEvent,INFINITE);
                                if (!GetOverlappedResult(taph, 
						&overlapped, &len, FALSE)) {
                                        /* there is nothing to send */
                                        continue;
                                }
                        } else {
                                /* other error, don't exit */
                                sp_log("tunreader(): error (%d) reading from " 
					"TAP-Win32 device.\n",
					(int)GetLastError());
				sp_WinError((int)GetLastError());
				Sleep(500); /* prevent storm of messages */
                                continue;
                        }
                }
		/* send data through userspace socketpair */
                send(tapfd, buf, len, 0);
        }
        sp_log("tunreader(%p, %d) thread shutdown.\n", taph, tapfd);
        CloseHandle(taph);
        fflush(stdout);
}


#endif /* WIN32 */
