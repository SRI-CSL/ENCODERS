/*
 * CORE Span
 * (c)2010 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * spanconn.h
 *
 * Data types and function prototypes for managing Span connections.
 */

#ifndef _SPAN_CONN_H_
#define _SPAN_CONN_H_

/* FreeBSD 4.11 has NG_HOOKLEN=15, 7.0 has NG_HOOKLEN=31, so here we just
 * define our own...  */
#define SPAN_NG_HOOKLEN 31

/*
 * Data types.
 */
struct span_conn
{
	int sock;
	int state;
	int type;
	char name[255];
	struct span_conn *next;
	char *data;
	int data_begin;
	int data_end;
	int bytes_in;
	int bytes_out;
	int bytes_dropped;
	struct sockaddr_storage addr; /* for UDP connections */
#ifdef WIN32
	HANDLE hTAP32;
#endif
};

#define SPAN_CONNTYPE_TCP_INCOMING	1 /* TCP listening socket */
#define SPAN_CONNTYPE_TCP		2 /* established or outgoing TCP */
#define SPAN_CONNTYPE_UDP_INCOMING	3 /* UDP listening socket */
#define SPAN_CONNTYPE_UDP		4 /* outgoing UDP connections */
#define SPAN_CONNTYPE_NG_CONTROL	5 /* NetGraph control messages */
#define SPAN_CONNTYPE_NG_DATA		6 /* NetGraph data from emulation */
#define SPAN_CONNTYPE_TAP		7 /* Local virtual interface */

#define SPAN_CONNSTATE_NONE		0
#define SPAN_CONNSTATE_LISTENING	1
#define SPAN_CONNSTATE_CONNWAIT		2
#define SPAN_CONNSTATE_ACKWAIT		3
#define SPAN_CONNSTATE_CONNECTED	4

static const char span_conntype_str[8][8] = { "0", "TCP-IN", "TCP", "UDP-IN", 
					"UDP", "NGC", "NGD" };

extern struct span_conn *conns;

struct span_hdr
{
	unsigned short int type;
	unsigned short int len;	
	char	src[SPAN_NG_HOOKLEN + 1]; /* 32 bytes */
};

#define SH_TYPE_DATA 		1
#define SH_TYPE_OPEN_TCP 	2 /* currently unused */
#define SH_TYPE_OPEN_UDP	3
#define SH_TYPE_OPEN_UDP_ACK	4
#define SH_TYPE_CLOSE		5
#define SH_TYPE_MAP		6
#define SH_TYPE_TAP		7


#define SPAN_TAP_FLAG_CREATE	1
#define SPAN_TAP_FLAG_DELETE	2

#define SPAN_MAP_HASHSIZE 512

struct span_map_entry
{
	unsigned int hash;
	struct span_conn *conn_cache;
	char src[255];
	char dst[255];
	struct span_map_entry *next;
};

extern struct span_map_entry span_conn_map[SPAN_MAP_HASHSIZE];


/*
 * Function prototypes.
 */
struct span_conn *add_span_conn(int, int, int, char *);
struct span_conn *find_span_conn_by_name(char *);
void span_map_init(void);
int span_map(char *, char *);
int span_unmap(char *);
struct span_conn *span_map_lookup(char *);
int span_map_uncache(struct span_conn *);
int span_map_load(char *);
int free_span_conn(struct span_conn *);
void free_span_conns(void);
unsigned int map_hash(char *);
void free_span_conn_map(void);
void dump_span_conn_map(void);

#endif /* _SPAN_CONN_H_ */
