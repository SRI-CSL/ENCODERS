/*
 * CORE Span
 * (c)2008-2010 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * Connect together CORE emulations running on different hosts.
 * Manages a set of local ng_socket nodes and connects them by tunneling data
 * over TCP/UDP sockets.
 *
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#include <errno.h>		/* errno */
#include <signal.h>		/* signal() */
#ifdef WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <process.h>
#include <io.h>
#else
#include <sys/types.h>		/* select() */
#include <sys/stat.h>		/* umask() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select() */
#include <time.h>		/* ctime() */
#include <stdarg.h>		/* va_start() */
#endif
#ifdef FREEBSD
#include <netgraph.h>		/* Ng*()  */
#ifndef NG_PATHLEN
#define NG_PATHLEN NG_PATHSIZ
#endif
#endif

#include "span.h"
#include "spanconn.h"
#include "spantap.h"

/*
 * Function prototypes.
 */
void print_banner(void);
void print_usage(void);
int  select_loop(void);
int  socket_bind(int, int, struct sockaddr *, int, char *);
int  socket_connect(int, struct sockaddr *, int);
int  socket_netgraph(char *, int, int);
int  span_receive(struct span_conn *);
int  span_receive_ack(struct sockaddr *);
int  span_receive_map(char *, char *);
int  span_receive_tap(char *, char *);
int  span_send(char *, int, struct span_conn *);
int  span_send_rmap(char *, char *, char *);
void span_hexdump(char *, int);
void span_debug_print_ngcontrol(char *, char *, int);
#ifdef FREEBSD
int  span_get_config(int, char*, struct ng_mesg *);
int  span_set_config(int, char*, struct ng_mesg *);
#endif
void span_flush_state(void);
int  check_for_control(struct span_conn *);
int  sp_open_log(char *, int);
void sp_close_log();
int  sp_write_pid(char *, pid_t);
void span_terminate(int);
void span_debug(int);
#ifdef WIN32
void sp_WinError(int code);
#endif

/*
 * Globals.
 */
struct span_conn *conns=NULL;
int conn_type = IPPROTO_TCP;
struct span_map_entry span_conn_map[SPAN_MAP_HASHSIZE];


/*
 * Main routine.
 */
int 
main(int argc, char **argv)
{
	int err;
	int control_sock, data_sock;
	char log_filename[255];
	char tap_ipnet[512], tap_dev_name[32], tap_name[32];
	char ipnet[32], *cp, *cp2, *map_str=NULL;
	struct span_conn *conn;
#ifndef WIN32
	pid_t pid;
#else
	WORD wVer;
	WSADATA wsaData;
#endif

	/*
	 * Initializations
	 */
	int n, do_daemon = 0, do_log = 0, do_connect = 0, do_tap = 0, log_opts;
	struct sockaddr_in listen_addr, connect_addr;
	bzero(&connect_addr, sizeof(connect_addr));
	control_sock = data_sock = 0; /* XXX unused, but fixes memory bug */
	signal(SIGINT, span_terminate);
	signal(SIGTERM, span_terminate);
#ifndef SPAN_DEBUG
	signal(SIGSEGV, span_terminate);
#endif
	signal(SIGHUP, span_debug);
	sprintf(log_filename, "%s", SPAN_DEFAULT_LOG);
	log_opts = 0;
	memset(tap_ipnet, 0, sizeof(tap_ipnet));
	sprintf(tap_ipnet, "%s/%s", DEFAULT_TAP_ADDR, DEFAULT_TAP_NET);
	sprintf(tap_dev_name, "%s", DEFAULT_TAP_NAME);

#ifdef WIN32
	/* Initialize Windows sockets, so we can verify addresses, etc. */
	wVer = MAKEWORD(2, 2);
	err = WSAStartup(wVer, &wsaData);
	if (err != 0) {
		sp_log("error initializing WinSock DLL\n");
		exit(1);
	}
#endif
	/*
	 * Parse command-line arguments.
	 */
	argv++, argc--;
	while (argc > 0) {
		if (strcmp(*argv, "-d") == 0) {
			do_daemon = 1;
			do_log = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-c") == 0) {
			do_connect = 1;
			argv++, argc--;
			if (argc==0 || !argv) {
				sp_log("Error: please specify connect"
					" address.\n");
				print_usage();
				exit(1);
			}
			connect_addr.sin_family = AF_INET;
			if (str_to_addr(*argv, SA(&connect_addr)) != 1) {
				sp_log("Error: Invalid connect address.\n");
				exit(1);
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-l") == 0) {
			argv++, argc--;
			do_log = 1;
			if (argc==0 || !argv) {
				sp_log("Error: please specify log file.\n");
				print_usage();
				exit(1);
			} else {
				strncpy(log_filename, *argv, 255);
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-p") == 0) {
			argv++, argc--;
			if (argc==0 || !argv) {
				sp_log("Error: please specify protocol.\n");
				print_usage();
				exit(1);
			} else if (*argv[0] == 't' || *argv[0] == 'T') {
				conn_type = IPPROTO_TCP;
			} else if (*argv[0] == 'u' || *argv[0] == 'U') {
				conn_type = IPPROTO_UDP;
			} else {
				sp_log("Error: invalid protocol.\n");
				print_usage();
				exit(1);
			}			
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-m") == 0) {
			argv++, argc--;
			if (argc==0 || !argv) {
				sp_log("Error: please specify a mapping "
				       "string.\n");
				print_usage();
				exit(1);
			} else {
				map_str = *argv;
				if (!strchr(map_str, '-')) {
					sp_log("Error: Invalid mapping string"
					       ".\n");
					exit(1);
				}
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-t") == 0) {
			do_tap = 1;
			argv++, argc--;
			if (argc > 0 && argv && *argv[0] != '-') {
				/* read number of taps */
				if (sscanf( argv[0], "%d", &do_tap) != 1) {
					sp_log("Error: invalid number of tap"
						" devices.\n");
					print_usage();
					exit(1);
				}
				argv++, argc--;
			}
			continue;
		} else if (strcmp(*argv, "-a") == 0) {
			if (!do_tap) do_tap = 1;
			argv++, argc--;
			if (argc==0 || !argv) {
				sp_log("Error: please specify TAP"
					" address/net.\n");
				print_usage();
				exit(1);
			}
			if (!strchr(*argv, '/')) {
				sp_log("Error: Invalid TAP address/net.\n");
				exit(1);
			}
			memset(tap_ipnet, 0, sizeof(tap_ipnet));
			strncpy(tap_ipnet, *argv, sizeof(tap_ipnet));
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-n") == 0) {
			argv++, argc--;
			if (argc==0 || !argv) {
				sp_log("Error: please specify TAP device name"
					"\n\n");
				print_usage();
				exit(1);
			}
			if (!strncpy(tap_dev_name, *argv,
						sizeof(tap_dev_name))) {
				sp_log("Error: Invalid TAP device name.\n");
				exit(1);
			}
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-k") == 0) {
			sp_log("Preserving the log file.\n");
			log_opts = 1;
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-v") == 0) {
			/* TODO */
			argv++, argc--;
			continue;
		} else if (strcmp(*argv, "-h") == 0) {
			print_usage();
			exit(0);
		}

		/* unknown arguments */
		print_usage();
		exit(1);
	}

	/*
         * Run as daemon.
         */	
#ifndef WIN32
	if (do_daemon) {
		/* check for PID file */
		if (sp_write_pid(SPAN_DEFAULT_PID, 0) < 0)
			exit(1);
		if ((pid = fork()) < 0) {
			sp_log("fork() error: %s\n", strerror(errno));
			exit(1);
		} else if (pid > 0) {
			/* parent process exits here, writing PID to pid file */
			exit(sp_write_pid(SPAN_DEFAULT_PID, pid));
		}
		umask(0); /* change file mode mask */
		if (setsid() < 0) /* obtain a new process group */
			exit(1);
		if (chdir("/") < 0)
			exit(1);
	}
#endif
	if (do_log) { /* replace stdout/stderr/stdin */
		if (sp_open_log(log_filename, log_opts) < 0) {
			fprintf(stderr,
				"Error opening log file '%s' - %s, quitting.\n",
				log_filename, strerror(errno));
			exit(1);
		}
	}

	print_banner();

	/*
	 * Open TCP and UDP sockets and bind to SPAN_PORT.
	 */
	bzero(&listen_addr, sizeof(listen_addr));
	listen_addr.sin_family = AF_INET;
	listen_addr.sin_port = htons(SPAN_PORT);
	listen_addr.sin_addr.s_addr = INADDR_ANY;

	err = socket_bind(SOCK_STREAM, IPPROTO_TCP, SA(&listen_addr),
			SPAN_CONNTYPE_TCP_INCOMING, "TCP");
	if (err < 0) /* fatal error? */
		exit(1);

	err = socket_bind(SOCK_DGRAM, IPPROTO_UDP, SA(&listen_addr),
			SPAN_CONNTYPE_UDP_INCOMING, "UDP");
	if (err < 0)
		exit(1);

#ifdef FREEBSD
	/*
	 * Open a control socket for local messages.
	 */
	if (socket_netgraph("span_ctl", 1, 0) < 0)
		exit(1);
#else
	/*
	 * If running on Linux or Windows, flag for the TAP interface...
	 * Without a TAP interface, Span on these platforms would sit and
	 * do nothing.
	 */
	if (!do_tap) do_tap = 1;
#endif /* FREEBSD */

	/*
	 * Open a local TAP interface for sending data to this host.
	 */
	cp = tap_ipnet;
	for (n=0; n < do_tap; n++) {
		memset(ipnet, 0, sizeof(ipnet));
		cp2 = NULL;
		if (cp) {
			cp2 = strchr(cp, ',');
			if (cp2) {
				strncpy(ipnet, cp, cp2 - cp);
				cp2++;
			} else {
				strncpy(ipnet, cp, sizeof(ipnet));
			}
		}
		cp = cp2;
		snprintf(tap_name, sizeof(tap_name), "%s%d", tap_dev_name, n);
		sp_log("Opening TAP interface %s (%s)\n", tap_name, ipnet);
		if ((data_sock = init_tap(tap_name, ipnet)) < 0) {
			sp_log("Continuing with the TAP interface %s disabled."
				"\n", tap_name);
			continue;
		}
		conn = add_span_conn( data_sock, SPAN_CONNSTATE_LISTENING,
					SPAN_CONNTYPE_TAP, tap_name );
		if (!conn) {
			sp_log("Couldn't save TAP socket state, interface %s "
				"disabled.\n", tap_name);
			continue;
		}
#ifdef WIN32	/* save device the handle (from global) for output */
		conn->hTAP32 = hTAP32;
#endif
	} /* end for */

	/*
         * Make a connection to SPAN_PORT.
	 */
	if (do_connect) {
		connect_addr.sin_family = AF_INET;
		connect_addr.sin_port = htons(SPAN_PORT);
		if (socket_connect(conn_type, SA(&connect_addr), 0) < 0)
			exit(1);
	}

	span_map_init();
	/* add any mapping specified */
	if (map_str)
		span_map_load(map_str);


	select_loop();
	/* NgNameNode(cs, path, fmt, ...); */
	/*ngRecvData(ds, buf, len, hook);*/

	exit(0);
}

/*
 * Print or log a title message.
 */
void
print_banner()
{
#ifndef WIN32
	struct timeval t;
	gettimeofday(&t, NULL);
	sp_log("CORE Span v.%.1f - %s", SPAN_VER, ctime(&t.tv_sec));
#else
	sp_log("CORE Span v.%.1f\n", SPAN_VER);
#endif
}

/*
 * Prints command-line options.
 */
void
print_usage()
{
	print_banner();
	printf("Connect together CORE emulations running on different hosts.");
	printf("\n");
	printf("usage: span [-d] [-c <remote-ip>] [-p tcp|udp] [-m <a>-<b>]"
	       " [-l <log-file>] [-t]\n");
#ifdef WIN32
	printf("\t-d\t\tdaemonize: output to log file\n");
#else
	printf("\t-d\t\tdaemonize:\trun in the background and output to\n");
	printf("\t\t\t\t\tlog file\n");
#endif
	printf("\t-c <remote-ip>\tconnect to remote span process at ");
	printf("<remote-ip>\n");
	printf("\t-p tcp|udp\tconnect using TCP or UDP\n");
	printf("\t-m <a>-<b>,<b>-<a>...\tmanually add connection mappings, ");
	printf("such as:\n");
	printf("\t\t\t\t\ter1n0-core0,core0-192.168.0.7\n");
	printf("\t-l <log-file>\tlog output to specified file\n");
	printf("\t-k keep the log file, don't truncate if it exists\n");
	printf("\t-t [number]\tenable (number) of TAP local virtual "
		"interface(s)\n");
	printf("\t-a <local-ip/net> specify the local TAP (starting) address "
		"such as:\n");
	printf("\t\t\t\t\t%s/%s\n", DEFAULT_TAP_ADDR, DEFAULT_TAP_NET);
	printf("\t\t\tspecify multiple TAP addresses separated by commas\n");
	printf("\t-n name\t\tuse 'name' as local TAP device name, such as "
		"'core' for devices 'core0', 'core1', etc.\n");
	printf("\t-v enable verbose debugging\n");
	printf("\n");
}

/*
 * This is where the program spends all of its time.
 */
int
select_loop()
{
	int max, err, need_control;
	fd_set read_fdset;
	struct timeval to;
	struct span_conn *conn;

	/*
	 * Loop forever. A separate signal handler will 
         * catch CTRL+C or KILL signals.
	 */
	for (;;) {

		/* Set up for select() call */
		max = 0;
		FD_ZERO(&read_fdset);
		for (conn = conns; conn; conn = conn->next) {
			if (conn->sock == 0)
				continue;
			FD_SET((unsigned int)conn->sock, &read_fdset);
			if (conn->sock > max)
				max = conn->sock;
		}
		to.tv_sec = 1;
		to.tv_usec = 0;
		need_control = 0;

		/* Perform select() and dispatch to separate 
                 * span_receive() function if there is any data. 
                 */
		if ((err = select(max+1, &read_fdset, NULL,NULL, &to)) < 0) {
#ifdef WIN32
			if (err != SOCKET_ERROR)
				continue;
			sp_WinError(GetLastError());
#endif
			if (errno == EINTR)
				continue;
			sp_log("select() error(%d): %s\n", 
				errno, strerror(errno));
			return(-errno);
		} else if (err == 0) {
			/* timeout */
		} else  {
			/* Check for data on all our sockets. */
			for (conn = conns; conn; conn = conn->next) {
				if (conn->sock == 0)
					continue;
				if (!FD_ISSET(conn->sock, &read_fdset))
					continue;
				if (span_receive(conn) < 0) {
					/* Free conn and flag for control */
					need_control = check_for_control(conn);
					free_span_conn(conn);
					break; /* exit loop: conn now invalid!*/
				}
			}
#ifdef FREEBSD
			if (need_control) {
				if (socket_netgraph("span_ctl", 1, 0) < 0) {
					sp_log("new control socket needed, but "
					       "unable to open one!\n");
				}
				need_control = 0;
			}
#endif /* FREEBSD */
		/* end if select() */
		}
	/* end for (;;) */
	}

	return(0);
}


/* 
 * Perform socket(), bind(), and listen() calls in one function.
 */
int
socket_bind(type, protocol, addr, span_type, msg)
int type;
int protocol;
struct sockaddr *addr;
int span_type;
char *msg;
{
	int s, addrlen, err;
	char name[255];

	/* open socket */
	if ((s = socket(addr->sa_family, type, protocol)) < 0) {
		sp_log("%s socket() error %d: %s\n", 
			msg, errno, strerror(errno));
		return(-1);
	}

	/* bind socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	if ((err = bind(s, addr, addrlen)) < 0) {
		sp_log("%s bind() error %d: %s\n", msg, errno, strerror(errno));
		closesocket(s);
		return(-1);
	}
	
	/* put socket into listening state if TCP */
	if (type == SOCK_STREAM) {
		if ((err = listen(s, SPAN_MAX_INCOMING)) < 0) {
			sp_log("%s listen() error %d: %s\n ", 
				msg, errno, strerror(errno));
			closesocket(s);
			return(-1);
		}
	}

	/* add socket to our global linked list */
	sp_log("%s socket listening on port %d\n", msg, SPAN_PORT);
	sprintf(name, "span_server_%s", msg);
	if (!add_span_conn(s, SPAN_CONNSTATE_LISTENING, span_type, name)) {
		sp_log("Couldn't save %s socket() state, giving up.\n", msg);
		closesocket(s);
		return(-1);
	}

	return(s);
}

/* 
 * Perform socket() and connect() calls in one function.
 */
int
socket_connect(protocol, addr, flags)
int protocol;
struct sockaddr *addr;
int flags;
{
	int s, addrlen, type, state;
	char name[255];

	sprintf(name, "%u.%u.%u.%u", 
		NIPQUAD(((struct sockaddr_in*)addr)->sin_addr.s_addr));

	if (find_span_conn_by_name(name)) {
		sp_log("Connection to %s already exists.\n", name);
		return(0);
	}
	sp_log("Connecting to %s using %s...\n", name,
		(protocol == IPPROTO_TCP) ? "TCP" : "UDP");

	/* open socket */	
	if ((s = socket(addr->sa_family, (protocol == IPPROTO_TCP) ? 
			SOCK_STREAM : SOCK_DGRAM, protocol)) < 0) {
		sp_log("socket() error %d: %s\n", errno, strerror(errno));
		return(-1);
	}

	/* connect socket */
	addrlen = (addr->sa_family == AF_INET) ? sizeof(struct sockaddr_in) :
						sizeof(struct sockaddr_in6);
	/* else IPv6 set sin6_port */
	if (connect(s, addr, addrlen) < 0) {
		sp_log("connect() error %d: %s\n", errno, strerror(errno));
		return(-1);
	}

	/* add socket to our global linked list */
	if (protocol==IPPROTO_TCP) {
		type = SPAN_CONNTYPE_TCP;
		state = SPAN_CONNSTATE_CONNECTED;
	} else {
		type = SPAN_CONNTYPE_UDP;
		if (flags == SH_TYPE_OPEN_UDP_ACK)
			state = SPAN_CONNSTATE_ACKWAIT;
		else
			state = SPAN_CONNSTATE_CONNWAIT;
	}
	if (!add_span_conn(s, state, type, name)) {
		sp_log("Couldn't save peer connection giving up.\n");
		return(-1);
	}

	/* send an open message for UDP notification */
	if (protocol == IPPROTO_UDP) {
		type = (flags==SH_TYPE_OPEN_UDP_ACK) ? flags : SH_TYPE_OPEN_UDP;
		span_send_control(s, type, name);
	}
	return(s);
}

#ifdef FREEBSD
/*
 * Open Netgraph socket(s) using libnetgraph call.
 */
int
socket_netgraph(name, do_control, do_data)
char *name;
int do_control;
int do_data;
{
	int err, control_sock, data_sock, *cp, *dp;

	if (!name || (strlen(name) < 2))
		return(-1);
	if (!do_control && !do_data)
		return(-1);

	cp = do_control ? &control_sock : NULL;
	dp = do_data ? &data_sock : NULL;

	if ((err = NgMkSockNode(name, cp, dp)) < 0) {
		sp_log("NgMkSockNode() error %d (%d): %s\n", 
			err, errno, strerror(errno));
		return(-1);
	}

	if (do_control) {
		sp_log("Netgraph control socket '%s' opened.\n", name);
		if (!add_span_conn(control_sock, SPAN_CONNSTATE_LISTENING,
				   SPAN_CONNTYPE_NG_CONTROL, name)) {
			sp_log("Couldn't save Netgraph socket() ");
			sp_log("state.\n");
			err = -1;
		}
	}

	if (do_data) {
		sp_log("Netgraph data socket '%s' opened.\n", name);
		if (!add_span_conn(data_sock, SPAN_CONNSTATE_CONNECTED,
				   SPAN_CONNTYPE_NG_DATA, name)) {
			sp_log("Couldn't save Netgraph socket() ");
			sp_log("state.\n");
			err = -1;
		}
	}

	return(err);
}
#endif /* FREEBSD */

/*
 * Receive data from various sources depending on socket type.
 * Handles TCP, UDP, and Netgraph sockets.
 */
int
span_receive(conn)
struct span_conn *conn;
{
	char *bufp, ipstr[16];
	int err, len, sh_len, buflen, offset, new_sock, flags, data_len, type;
	socklen_t addrlen;
	struct sockaddr_in addr;
	struct span_hdr *sh;
#ifdef FREEBSD
	char path[NG_PATHLEN + 1];
	struct ng_mesg *ngm;
#endif /* FREEBSD */

	if (!conn)
		return(-1);
	
	flags = 0;
	addrlen = sizeof(addr);
	bzero(&addr, addrlen);

	switch (conn->type) {
	/* Accept new TCP connections on SPAN_PORT */
	case SPAN_CONNTYPE_TCP_INCOMING:
		new_sock = accept(conn->sock, SA(&addr), &addrlen);
		if (new_sock < 0) {
			sp_log("accept() error(%d): %s\n", 
				errno, strerror(errno));
			return(-1);
		}
		sprintf(ipstr, "%u.%u.%u.%u", NIPQUAD(addr.sin_addr.s_addr));
		conn = add_span_conn(new_sock, SPAN_CONNSTATE_CONNECTED,
				     SPAN_CONNTYPE_TCP, ipstr);
		if (!conn) {
			sp_log("Failed to add a new connection from %s.\n",
				ipstr);
		} else {
			sp_log("Accepted new TCP connection from %s.\n", ipstr);
		}
		break;
	/* Read TCP/UDP data from connected peer */
	/* (the _UDP_INCOMING has never been connect()ed */
	case SPAN_CONNTYPE_TCP:
	case SPAN_CONNTYPE_UDP_INCOMING:
	case SPAN_CONNTYPE_UDP:
		bufp = &conn->data[conn->data_end];
		buflen = (3*SPAN_IF_MTU) - conn->data_end;
		if (conn->type == SPAN_CONNTYPE_TCP)
			len = recv(conn->sock, bufp, buflen, flags);
		else
			len = recvfrom(conn->sock, bufp, buflen, flags, 
					SA(&addr), &addrlen);
		if (len < 0) {
			sp_log("%s() error(%d): %s\n",
				(conn->type == SPAN_CONNTYPE_TCP) ? "recv" : \
				"recvfrom", errno, strerror(errno));
			return(-1);
		} else if (len == 0) {
			sprintf(ipstr, "%u.%u.%u.%u", 
				NIPQUAD(addr.sin_addr.s_addr));
			if (conn->state == SPAN_CONNSTATE_LISTENING)
				return(free_span_conn(
					find_span_conn_by_name(ipstr)));
			else
				return(-1);
		}
#ifdef SPAN_DEBUG
		sp_log("%s: Got %d bytes from %s\n", 
			(conn->type == SPAN_CONNTYPE_TCP) ? "TCP" : "UDP",
			len, conn->name);
		span_hexdump(&conn->data[conn->data_begin], len);
#endif
		/* locate Span header; may have been received already
                 * at some offset. */
		if (conn->data_end > 0) {
			sh = (struct span_hdr*)&conn->data[conn->data_begin];
			/* fix up received length */
			len += conn->data_end - conn->data_begin;
		} else {
			sh = (struct span_hdr*)conn->data;
		}
process_data:
		sh_len = ntohs(sh->len);
		if (sh_len > 3*SPAN_IF_MTU) {
			printf("Warning: large packet of size %d is ", sh_len);
			printf("unsupported, maximum size is %d\n", 
				3*SPAN_IF_MTU);
			conn->data_begin = 0;
			conn->data_end = 0;
			break;
		}
		if (sh_len > len) { /* need more data before sending */
			conn->data_end = conn->data_begin + len;
			break;
		} /* otherwise, handle this chunk of data */
		switch(ntohs(sh->type)) {
		case SH_TYPE_DATA:
			err = span_send(&conn->data[conn->data_begin], 
					sh_len, conn);
			break;
		case SH_TYPE_OPEN_TCP:
			sp_log("Warning: OPEN_TCP unhandled.\n");
			break;
		case SH_TYPE_OPEN_UDP:
			sprintf(ipstr, "%u.%u.%u.%u", 
				NIPQUAD(addr.sin_addr.s_addr));
			type = SH_TYPE_OPEN_UDP_ACK;
			/* address may be included after the header */
			if (sh_len > sizeof(struct span_hdr)) {
				data_len = sh_len - sizeof(struct span_hdr);
				if (data_len > sizeof(ipstr) - 1)
					data_len = sizeof(ipstr) - 1;
				memset(ipstr, 0, sizeof(ipstr));
				memcpy(ipstr, sh+1, data_len);
				if (str_to_addr(ipstr, SA(&addr)) != 1) {
					sp_log("Warning: invalid OPEN_UDP "
						"address\n");
					break;
				}
				sp_log("initiate UDP to %s\n", ipstr);
				type = 0;
			}
			addr.sin_port = htons(SPAN_PORT); /* use UDP_INCOMING */
			new_sock = socket_connect(IPPROTO_UDP, SA(&addr), type);

			if (new_sock > 0 ) {
				sp_log("Accepted new UDP connection from %s.\n",
					ipstr);
			} else {
				sp_log("Failed to add a new connection"
					" from %s.\n", ipstr);
			}
			break;
		case SH_TYPE_OPEN_UDP_ACK:
			/* update connection state */
			span_receive_ack(SA(&addr));
			break;
		case SH_TYPE_CLOSE:
			sprintf(ipstr, "%u.%u.%u.%u", 
				NIPQUAD(addr.sin_addr.s_addr));
			if (conn->state == SPAN_CONNSTATE_LISTENING)
				return(free_span_conn(
					find_span_conn_by_name(ipstr)));
			else
				return(-1);
			break;
		case SH_TYPE_MAP:
			/* remote mapping */
			sprintf(ipstr, "%u.%u.%u.%u", 
				NIPQUAD(addr.sin_addr.s_addr));
			if (conn->state == SPAN_CONNSTATE_LISTENING)
				span_receive_map((char *)sh, ipstr);
			else 
				span_receive_map((char *)sh, conn->name);
			break;
		case SH_TYPE_TAP:
			/* TAP message */
			sprintf(ipstr, "%u.%u.%u.%u", 
				NIPQUAD(addr.sin_addr.s_addr));
			if (conn->state == SPAN_CONNSTATE_LISTENING)
				span_receive_tap((char *)sh, ipstr);
			else 
				span_receive_tap((char *)sh, conn->name);
			break;
		default:
			sp_log("Unknown data received, dropping %d bytes.\n",
				len);
			conn->bytes_dropped += len;
			conn->data_begin = 0;
			conn->data_end = 0;
			break;
		}

		if (sh_len == len) { /* we're done, reset pointers */
			conn->data_begin = 0;
			conn->data_end = 0;
			break;
		}

		/* if this is reached, then (sh_len < len), and we have more
                   data to process
		 */ 
		conn->data_end = conn->data_begin + len;
		conn->data_begin += sh_len;
		len -= sh_len;
		sh = (struct span_hdr*)&conn->data[conn->data_begin];
		sh_len = ntohs(sh->len);
		if (sh_len == 0) {
			printf("Warning: span header with zero length\n");
			break;
		}
		/* look for going past the buffer's end - expensive memmove() */
		if ((conn->data_begin + sh_len) > 3*SPAN_IF_MTU) {
			printf("Warning: performing memmove() data_begin=%d, sh_len=%d\n", conn->data_begin, sh_len); // */
			memmove(conn->data, &conn->data[conn->data_begin], len);
			/*bcopy(&conn->data[conn->data_begin], conn->data, len);*/
			conn->data_begin = 0;
			conn->data_end = len;
		}
		goto process_data;
#ifdef FREEBSD
	/* Netgraph control message */
	case SPAN_CONNTYPE_NG_CONTROL:
	        ngm = (struct ng_mesg*) &conn->data[conn->data_end];
		buflen = (3*SPAN_IF_MTU) - conn->data_end;
		len = NgRecvMsg(conn->sock, ngm, buflen, path);
		if (len == 0) /* socket was closed */
			return(-1);
		conn->bytes_in += len;
		switch(ngm->header.cmd) {
		case NGM_SHUTDOWN:
			sp_log("%s: shutdown message received\n", path);
			break;
		case NGM_TEXT_STATUS:
			sp_log("%s: status request received\n", path);
			break;
		case NGM_TEXT_CONFIG:
			if (!ngm->header.arglen)
				len = span_get_config(conn->sock, path, ngm);
			else
				len = span_set_config(conn->sock, path, ngm);
			if (len > 0)
				conn->bytes_out += len;
#ifdef SPAN_DEBUG
			sp_log("%s: config request received\n", path);
			dump_span_conn_map();
#endif
			break;
		default:
			sp_log("Warning: %s: unknown control message!\n", path);
			span_debug_print_ngcontrol(&conn->data[conn->data_end],
							 path, len);
			break;
		}
		/* NgSendReplyMsg(conn->sock, path, ngm, NULL, NULL); */
		break;
	/* Netgraph data message */
	case SPAN_CONNTYPE_NG_DATA:
		/* make room for and add a span_hdr */
		offset = sizeof(struct span_hdr);
		bufp = &conn->data[offset];
		buflen = (3*SPAN_IF_MTU) - offset;
		sh = (struct span_hdr*) conn->data;
		sh->type = htons(SH_TYPE_DATA);
		/* hook name received into header to avoid extra copy */
		len = NgRecvData(conn->sock, (uint8_t *)bufp, buflen, sh->src);
		if (len == 0) /* socket was closed */
			return(-1);
		len += offset;
		sh->len = htons(len);
		err = span_send(conn->data, len, conn);
		break;
#endif /* FREEBSD */
	/* Data from our local TAP virtual interface */
	case SPAN_CONNTYPE_TAP:
		/* make room for and add a span_hdr */
		offset = sizeof(struct span_hdr);
		bufp = &conn->data[offset];
		buflen = (3*SPAN_IF_MTU) - offset;
		sh = (struct span_hdr*) conn->data;
		sh->type = htons(SH_TYPE_DATA);
		strncpy(sh->src, conn->name, sizeof(sh->src));
#ifdef WIN32
		len = recv(conn->sock, bufp, buflen, flags);
#else
		len = read(conn->sock, bufp, buflen);
#endif
		if (len < 0) {
			sp_log("TAP read() error(%d): %s\n",
				errno, strerror(errno));
			return(-1);
		} else if (len == 0) { /* TAP was closed? */
			sp_log("TAP read()==0, may want to free it.\n");
			/* return(free_span_conn(conn)); */
		}
		len += offset;
		sh->len = htons((short unsigned int)len);
		err = span_send(conn->data, len, conn);
		break;
	default:
		sp_log("Unknown socket activity.\n");
		break;
	}
	return (0);
}


/*
 * Handle an ACK control packet.
 */			
int
span_receive_ack(addr)
struct sockaddr *addr;
{
	char name[16];
	struct span_conn *conn;
	sprintf(name, "%u.%u.%u.%u", 
		NIPQUAD(((struct sockaddr_in*)addr)->sin_addr.s_addr));
	if ((conn = find_span_conn_by_name(name))) {
		/* send ACK in reply to received ACK */
		if (conn->state == SPAN_CONNSTATE_CONNWAIT) {
			span_send_control(conn->sock, SH_TYPE_OPEN_UDP_ACK,
					  name);
		}
		/* else in ACKWAIT, this is the final ACK */
		conn->state = SPAN_CONNSTATE_CONNECTED;
		sp_log("%s is now connected.\n", name);
	} else {
		sp_log("ACK received for unknown connection %s.\n", name);
		return(-1);
	}
	return(0);
}

/*
 * Handle a MAP control packet.
 */			
int
span_receive_map(data, from)
char *data;
char *from;
{
	int err;
	struct span_hdr *sh = (struct span_hdr*)data;
	char *dash, *at, *map_name = &data[sizeof(struct span_hdr)];

	if (strlen(map_name) > 255)
		return(-1);
	/* if map_name contains "foo-bar" then we will map the two items,
	 * but if it just contains "foo" we will map it with sh->src and from */
	dash = strchr(map_name, '-');
	at = strchr(map_name, '@');
	if (!dash) {
		sp_log("Remote mapping message from %s maps %s-%s and %s-%s.\n",
			from, sh->src, map_name, map_name, from);
		err = span_map(sh->src, map_name);
		err += span_map(map_name, from);
	} else {
		*dash = '\0'; dash++; /* make two strings */
		if (at) { /* has '@' -- send a remote mapping message to peer */
			*at = '\0'; at++; /* make third string */
			sp_log("send remote mapping %s-%s to %s\n", 
				map_name, dash, at);
			err = span_send_rmap(at, map_name, dash);
		} else {
			sp_log("Remote mapping message from %s maps %s-%s.\n",
			       from, map_name, dash);
			err = span_map(map_name, dash);
			/* err += span_map(dash, map_name); */
		}
	}
	return(err);
}

/*
 * Handle a TAP control packet.
 */			
int
span_receive_tap(data, from)
char *data;
char *from;
{
	int data_sock;
	struct span_conn *conn;
	/* struct span_hdr *sh = (struct span_hdr*)data; */
	uint32_t *flag = (uint32_t *)&data[sizeof(struct span_hdr)];
	char *tap_name = &data[sizeof(struct span_hdr) + sizeof(uint32_t)];

	if (ntohl(*flag) != SPAN_TAP_FLAG_CREATE && 
	    ntohl(*flag) != SPAN_TAP_FLAG_DELETE)
		return(-1);
	if (strlen(tap_name) > 255)
		return(-1);
	sp_log("TAP %s request from %s for interface '%s'\n", 
		ntohl(*flag) == SPAN_TAP_FLAG_CREATE ? "create" : "delete",
		from, tap_name);

	switch(ntohl(*flag)) {
	case SPAN_TAP_FLAG_CREATE:
		if ((data_sock = init_tap(tap_name, 0)) < 0) {
			sp_log("Error creating TAP device '%s'\n", tap_name);
			return(-1);
		}
		conn = add_span_conn( data_sock, SPAN_CONNSTATE_LISTENING,
					SPAN_CONNTYPE_TAP, tap_name );
		if (!conn) {
			sp_log("Couldn't save TAP socket state, interface %s "
				"disabled.\n", tap_name);
			return(-1);
		}
		break;
	case SPAN_TAP_FLAG_DELETE:
		conn = find_span_conn_by_name(tap_name);
		if (!conn) {
			sp_log("Couldn't locate TAP socket state for '%s'\n",
				tap_name);
			return(-1);
		}
		free_span_conn(conn);
	}
	return(0);
}

/*
 * Send data that has been received out another socket.
 * Uses the source connection's name to map to a destination connection.
 */
int
span_send(buf, len, from)
char *buf;
int len;
struct span_conn *from;
{
	struct span_conn *conn;
	int err, flags=0, alen;
	struct sockaddr_ng;
	struct span_hdr *sh = (struct span_hdr*)buf;
#ifdef WIN32
	DWORD lenin;
	OVERLAPPED overlapped = {0};
#endif

#ifdef SPAN_DEBUG
	sp_log("Performing lookup for src=%s\n", sh->src);
#endif
	/* Find the destination connection from the source name in the
         * span header, which is the hook where the data originated. */
	conn = span_map_lookup(sh->src);

	/* Inbound connection stats are recorded here */
	if (!conn) {
#ifdef SPAN_DEBUG
		sp_log("No connection mapping for %d bytes from conn=%s src=%s",
			len, from->name, sh->src);
		sp_log(", dropping.\n");
#endif
		from->bytes_dropped += len;
		return(-1);
	} else {
		from->bytes_in += len;
#ifdef SPAN_DEBUG
		sp_log("%d bytes -> %s\n", len, conn->name);
#endif
	}

	switch(conn->type) {
#ifdef FREEBSD
	/* Send data to the kernel emulation via Netgraph */
	case SPAN_CONNTYPE_NG_DATA:
		buf += sizeof(struct span_hdr); /* remove span_hdr */
		len -= sizeof(struct span_hdr);
		err = NgSendData(conn->sock, conn->name, (uint8_t *)buf, len);
		break;
#endif /* FREEBSD */
	/* Send data to a connection-less peer via the network */
	case SPAN_CONNTYPE_UDP_INCOMING:
		alen = (conn->addr.ss_family == AF_INET) ? 
			sizeof(struct sockaddr_in) : \
			sizeof(struct sockaddr_in6);
		err = sendto(conn->sock, buf, len, flags, SA(&conn->addr),alen);
		break;
	/* Write data to local virtual interface */
	case SPAN_CONNTYPE_TAP:
		buf += sizeof(struct span_hdr); /* remove span_hdr */
		len -= sizeof(struct span_hdr);
#ifdef WIN32
		if (!WriteFile(conn->hTAP32, buf, len, &lenin, &overlapped))
			err = -1;
#else
		err = write(conn->sock, buf, len);
#endif
		break;
	/* Send data to a connected peer via the network */
	case SPAN_CONNTYPE_TCP:
	default:
		err = send(conn->sock, buf, len, flags);
		break;
	}
	/* Outbound connection stats are recorded here */
	if (err < 0) {
		sp_log("connection='%s' send error(%d): %s\n", 
			conn->name, errno, strerror(errno));
		conn->bytes_dropped += len;
#ifdef FREEBSD
		if (conn->type == SPAN_CONNTYPE_NG_DATA)
			return(-1);
#endif
		/* remove disconnected sockets */
		if (errno == ENOTCONN || errno == ENOTSOCK)
			free_span_conn(conn);
		return(-1);
	} else {
		conn->bytes_out += err;
	}

	return(0);
}


/*
 * Send a control message.
 */
int
span_send_control(sock, code, name)
int sock;
int code;
char *name;
{
	struct span_hdr sh;
	int err, len, flags;

	len = sizeof(struct span_hdr);
	bzero(&sh, len);
	sh.type = htons((unsigned short int)code);
	sh.len = htons((unsigned short int)len);
	strncpy(sh.src, name, sizeof(sh.src));
	/*flags = MSG_NOSIGNAL;*/ /* don't generate SIGPIPE */
	flags = 0;
	/* socket must already be connected, not using sendto() here */
	err = send(sock, (char *)&sh, len, flags);
	
	return(err);
}


/*
 * Send a remote mapping message to a peer
 */
int
span_send_rmap(conn_name, src, dst)
char *conn_name;
char *src;
char *dst;
{
	struct {
		struct span_hdr sh;
		char data[255];
	} msg;
	int err, len, alen, flags;
	struct span_conn *conn;

	conn = find_span_conn_by_name(conn_name);
	if (!conn) {
		sp_log("span_send_rmap(): no connection with name '%s'\n",
			conn_name);
		/* TODO: buffer this and send it later when the connection is
		 *       made; this allows for a remote span to connect at a
		 *       later time, after the emulation startup */
		return(-1);
	}
	alen = (conn->addr.ss_family == AF_INET) ? 
		sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6);

	len = sizeof(msg);
	bzero(&msg, len);
	msg.sh.type = htons(SH_TYPE_MAP);
	strncpy(msg.sh.src, src, sizeof(msg.sh.src));
	strncpy(msg.data, dst, sizeof(msg.data));
	len = sizeof(struct span_hdr) + strlen(dst) + 1;
	msg.sh.len = htons((unsigned short int)len);
	flags = 0;

#if 0
	if (conn->type == SPAN_CONNTYPE_UDP || 
	    conn->type == SPAN_CONNTYPE_UDP_INCOMING)
		err = sendto(conn->sock, (char *)&msg, len, flags, 
				SA(&conn->addr), alen);
	else
#endif
	err = send(conn->sock, (char *)&msg, len, flags);
	return(err);
}

/*
 * Debug
 */
void
span_hexdump(data, len)
char *data;
int len;
{
	int i;
	/* hex dump 16 bytes wide */
	for(i=0; i<len; i++) 
		sp_log("%.2x%s", data[i]&0xFF, (i && !(i % 16)) ? "\n" : " " );
	sp_log("\n");
}

#ifdef FREEBSD
/*
 * Debug
 */
void 
span_debug_print_ngcontrol(buf, path, len)
char *buf;
char *path;
int len;
{
	struct ng_mesg *ngm = (struct ng_mesg*)buf;
	sp_log("(%s=%d)", path, len);
	sp_log("ver=%d, spare=%d arglen=%d flags=0x%x token=0x%x "
		"typecookie=0x%x cmd=0x%x cmdstr=%s\n",
		ngm->header.version,
		ngm->header.spare,
		ngm->header.arglen,
		ngm->header.flags,
		ngm->header.token,
		ngm->header.typecookie,
		ngm->header.cmd,
		ngm->header.cmdstr	);
	span_hexdump(buf, len);
}

/*
 * Reply to a get config message.
 */
int span_get_config(sock, path, ngm)
int sock;
char *path;
struct ng_mesg *ngm;
{
	int r_len;
	char r[NG_TEXTRESPONSE], tmp[NG_TEXTRESPONSE];
	struct span_conn *conn;
#ifdef SPAN_DEBUG
	sp_log("span_get_config()\n");
#endif
	bzero(r, NG_TEXTRESPONSE);

	sprintf(r, "Active connections:\n(sock)\t(state)\t(type)\t(name)\t\t(RX)\t(TX)\t(DROP)\n");
	r_len = strlen(r);

	for (conn = conns; conn; conn=conn->next) {
		bzero(tmp, NG_TEXTRESPONSE);
		sprintf(tmp, "%d\t%d\t%s\t%s\t%s%d\t%d\t%d\n",
			conn->sock, conn->state,
			span_conntype_str[conn->type], conn->name,
			strlen(conn->name) < 8 ? "\t": "",
			conn->bytes_in, conn->bytes_out, conn->bytes_dropped);
		strncat(r, tmp, NG_TEXTRESPONSE);
		r_len += strlen(tmp);
		if (r_len >= NG_TEXTRESPONSE)
			break;
	}

	r_len++; /* extra NULL */
	NgSendReplyMsg(sock, path, ngm, r, r_len);
	return(r_len);
}

/*
 * Handle a set config message.
 */
int span_set_config(sock, path, ngm)
int sock;
char *path;
struct ng_mesg *ngm;
{
	int err=-1;
	char r[NG_TEXTRESPONSE], *dash, *at;
	struct sockaddr_in addr;

#ifdef SPAN_DEBUG
	sp_log("span_set_config()\n");
#endif
	if (ngm->header.arglen < 4)
		goto span_set_config_out;

	bzero(&addr, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(SPAN_PORT);
	bzero(r, NG_TEXTRESPONSE);
	sprintf(r, "OK");

	/* parse config commands */
	if (strncasecmp(ngm->data, "tcp=", 4)==0) {
		sp_log("initiate TCP to %s\n", &ngm->data[4]);
		if (str_to_addr(&ngm->data[4], SA(&addr)) != 1)
			goto span_set_config_out;
		err = socket_connect(IPPROTO_TCP, SA(&addr), 0);
	} else if (strncasecmp(ngm->data, "udp=", 4)==0) {
		sp_log("initiate UDP to %s\n", &ngm->data[4]);
		if (str_to_addr(&ngm->data[4], SA(&addr)) != 1)
			goto span_set_config_out;
		err = socket_connect(IPPROTO_UDP, SA(&addr), 0);
	} else if (strncasecmp(ngm->data, "ng=", 3)==0) {
		sp_log("create new Netgraph socket '%s'\n", &ngm->data[3]);
		err = socket_netgraph(&ngm->data[3], 0, 1);
	} else if (strncasecmp(ngm->data, "map=", 4)==0) {
		dash = strchr(&ngm->data[4], '-');
		if (!dash)
			goto span_set_config_out;
		*dash = '\0'; dash++; /* make two strings */
		err = span_map(&ngm->data[4], dash);
	} else if (strncasecmp(ngm->data, "rmap=", 4)==0) {
		/* rmap=hook1-rhook2@n.n.n.n
		 *      ^     ^      ^
		 *   data[5]  dash   at  */
		dash = strchr(&ngm->data[5], '-');
		at = strchr(&ngm->data[5], '@');
		if (!dash || !at)
			goto span_set_config_out;
		if (str_to_addr(at+1, SA(&addr)) != 1)
			goto span_set_config_out;
		*dash = '\0'; dash++; /* make two strings */
		*at = '\0'; at++; /* make third string */
		sp_log("send remote mapping %s-%s to %s\n", 
			&ngm->data[5], dash, at);
		err = span_send_rmap(at, &ngm->data[5], dash);
	} else if (strncasecmp(ngm->data, "flush", 5)==0) {
		sp_log("Flushing all connection state.\n");
		span_flush_state();
		err = 0;
	}

span_set_config_out:
	if (err < 0)
		sprintf(r, "Error");
	else
		err = strlen(r) + 1; /* return bytes sent */

	NgSendReplyMsg(sock, path, ngm, r, strlen(r)+1);
	return(err);
}
#endif /* FREEBSD */

/*
 * Cleanup all connections as if restarted
 */
void
span_flush_state(void)
{
	struct span_conn *conn, *next;

	/* erase the mapping */	
	free_span_conn_map();

	conn = conns;
	while (conn) {
		next = conn->next;
		switch (conn->type) {
		case SPAN_CONNTYPE_TCP_INCOMING:
		case SPAN_CONNTYPE_UDP_INCOMING:
		case SPAN_CONNTYPE_NG_CONTROL:
			/* leave these alone */
			break;
		default:
			/* close and free all other connections */
			free_span_conn(conn);
			break;
		}
		conn = next;
	}	
}

/*
 * Return 1 if this is the control socket, and print a message.
 */
int check_for_control(struct span_conn *conn)
{
	if (conn && conn->type == SPAN_CONNTYPE_NG_CONTROL) {
		sp_log("Control socket was closed, new one will be created.\n");
		return(1);
	}
	return(0);
}

/*
 * String to address.
 */
int str_to_addr(char *data, struct sockaddr *addr)
{
#ifdef WIN32
        int len = SALEN(addr);
        return(WSAStringToAddress((LPSTR)data, addr->sa_family, NULL,
                        addr, &len)==0);
#else
        return(inet_pton(addr->sa_family, (char*)data, SA2IP(addr)));
#endif
}

/*
 * Print or log messages.
 */
void
sp_log(char *fmt, ...)
{
	va_list ap;
	
	va_start(ap, fmt);
	vfprintf(stdout, fmt, ap);
	va_end(ap);
	fflush(stdout);
}


#ifdef WIN32
void sp_WinError(int code) {
        LPVOID lpMsgBuf;
        FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER|
                FORMAT_MESSAGE_FROM_SYSTEM, NULL, code,
                MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                (LPTSTR) &lpMsgBuf, 0, NULL);
        sp_log("error %d: %s", code, lpMsgBuf);
        LocalFree(lpMsgBuf);
}
#endif

/*
 * Open log file.
 */
int
sp_open_log(filename, opts)
char *filename;
int opts;
{
	if (!freopen("/dev/null", "r", stdin))
		return(-1);

	if (!freopen(filename, (opts == 1) ? "a" : "w", stdout))
		return(-1);

	strncat(filename, ".err", 254);
	if (!freopen(filename, "a", stderr)) /* /dev/null ? */
		return(-1);

	return(0);
}

/*
 * Close log file.
 */
void
sp_close_log()
{
	fflush(stdout);
	fflush(stderr);
	fclose(stdout);
	fclose(stderr);
}

/*
 * Write PID to PID file, unless it already exists.
 */
int
sp_write_pid(filename, pid)
char *filename;
pid_t pid;
{
	char buf[16];
	FILE *fp;
	int len;

	fp = fopen(filename, "r");
	if (fp) {
		len = sizeof(buf);
		bzero(buf, len);
		if (fread(buf, len, 1, fp) == 0)
			fprintf(stderr, "Warning: unable to read PID file.\n");
		buf[strlen(buf) - 1 ] = '\0';
		fprintf(stderr, "span already running (%s), or PID file '%s'\n"
			"needs to be removed.\n", buf, filename);
		fclose(fp);
		return(-1);
	}

	if (pid == 0) /* don't write a file, just check */
		return(0);

	fp = fopen(filename, "w");
	if (!fp) {
		fprintf(stderr, "Error opening PID file '%s' - %s, quitting.\n",
			filename, strerror(errno));
		return(-1);
	} else {
		sprintf(buf, "%d\n", pid);
		len = strlen(buf);
		if (fwrite(buf, len, 1, fp) != 1)
			fprintf(stderr, "Warning: unable to write to PID "
				"file.\n");
		fclose(fp);
	}

	return(0);
}

/*
 * Signal handler for program termination.
 */
void
span_terminate(signal)
int signal;
{

	sp_log("\nSpan shutting down (with signal %d%s).\n", 
		signal, 
		signal==SIGTERM ? " SIGTERM" :
		signal==SIGINT ? " SIGINT" :
		signal==SIGSEGV ? " SIGSEGV" : ""
		);
	free_span_conn_map();
	free_span_conns();
	sp_close_log();
	unlink(SPAN_DEFAULT_PID);
	exit(signal);
}

void
span_debug(signal)
int signal;
{
	struct span_conn *conn;

	sp_log("Active connections:\n(sock)\t(state)\t(type)\t(name)\t\t(RX)"
		"\t(TX)\t(DROP)\n");

	for (conn = conns; conn; conn=conn->next) {
		sp_log("%d\t%d\t%s\t%s\t%s%d\t%d\t%d\n",
			conn->sock, conn->state,
			span_conntype_str[conn->type], conn->name,
			strlen(conn->name) < 8 ? "\t": "",
			conn->bytes_in, conn->bytes_out, conn->bytes_dropped);
	}

	sp_log("Active mappings:\n");
	dump_span_conn_map();

	sp_log("\n");
}

