/*
 * CORE Span
 * (c)2010 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * span.h
 * 
 * Definitions for CORE Span.
 */
#ifndef _SPAN_H_
#define _SPAN_H_

#define SPAN_VER 1.4
#define SPAN_PORT 4039
#define SPAN_MAX_INCOMING 200
#define SPAN_IF_MTU 1600

#ifdef WIN32
typedef unsigned int pid_t;
#define bzero(s, n) memset(s, 0, n)
#define read _read
#define write _write
#define unlink _unlink
#define snprintf _snprintf
#define ENOTCONN WSAENOTCONN
#define ENOTSOCK WSAENOTSOCK

#define SPAN_DEFAULT_LOG "span.log"
#define SPAN_DEFAULT_PID "span.pid"
#else /* WIN32 */
#define closesocket close
#define SPAN_DEFAULT_LOG "/var/log/span.log"
#define SPAN_DEFAULT_PID "/var/run/span.pid"
#endif /* WIN32 */

/* useful sockaddr macros */
#define SA(x) (struct sockaddr *)(x)
#define SA2IP(x) (((struct sockaddr*)x)->sa_family==AF_INET) ? \
        (void*)&((struct sockaddr_in*)x)->sin_addr : \
        (void*)&((struct sockaddr_in6*)x)->sin6_addr
#define SALEN(x) (((struct sockaddr*)x)->sa_family==AF_INET) ? \
        sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6)
#define SAIPLEN(x) (((struct sockaddr*)x)->sa_family==AF_INET) ? 4 : 16
#define NIPQUAD(addr) 	((unsigned char*)&addr)[0] & 0xFF, \
			((unsigned char*)&addr)[1] & 0xFF, \
			((unsigned char*)&addr)[2] & 0xFF, \
			((unsigned char*)&addr)[3] & 0xFF


/*
 * Function declarations
 */
int  span_send_control(int, int, char *);
int  str_to_addr(char *data, struct sockaddr *addr);
void sp_log(char *, ...);


#endif /* _SPAN_H_ */
