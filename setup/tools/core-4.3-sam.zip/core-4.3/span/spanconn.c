/*
 * CORE Span
 * (c)2010 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * spanconn.c
 *
 * Functions for managing Span connections.
 */

#include <stdio.h>		/* printf() */
#include <stdlib.h>		/*  */
#include <string.h>		/* strerror() */
#ifdef WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <sys/types.h>		/* select() */
#include <sys/socket.h>		/* inet_pton() */
#include <sys/time.h>		/* select() */
#include <netinet/in.h>		/* sockaddr_in */
#include <arpa/inet.h>		/* sockaddr_in */
#include <unistd.h>		/* select() */
#endif

#include "span.h"
#include "spanconn.h"

/*
 * Add a new connection to the global linked list.
 */
struct span_conn*
add_span_conn(sock, state, type, name)
int sock;
int state;
int type;
char *name;
{
	struct span_conn *conn;

	if (conns==NULL) {
		conns = conn = malloc(sizeof(struct span_conn));
	} else {
		for (conn = conns; conn->next; conn = conn->next) { }
		conn->next = malloc(sizeof(struct span_conn));
		conn = conn->next;
	}
	if (!conn) {
		sp_log("add_span_conn: malloc() error\n");
		return NULL;
	}

	bzero(conn, sizeof(struct span_conn));
	conn->sock = sock;
	conn->state = state;
	conn->type = type;
	conn->data_begin = 0;
	conn->data_end = 0;
	conn->bytes_in = 0;
	conn->bytes_out = 0;
	conn->bytes_dropped = 0;
	if (name) {
		strncpy(conn->name, name, sizeof(conn->name));
		if (type == SPAN_CONNTYPE_UDP) {
			conn->addr.ss_family = AF_INET;
			((struct sockaddr_in*)&conn->addr)->sin_port = \
							htons(SPAN_PORT);
			str_to_addr(conn->name, SA(&conn->addr));
		}
	}
	conn->next = NULL;
	/* allocate packet data area */
	conn->data = malloc(3*SPAN_IF_MTU);
	if (!conn->data) {
		sp_log("add_span_conn: malloc() error\n");
		free(conn);
		return(NULL);
	} else {
		bzero(conn->data, 3*SPAN_IF_MTU);
	}
	return(conn);
}

/*
 * Search for a connection based on the given name.
 */
struct span_conn*
find_span_conn_by_name(name)
char *name;
{
	struct span_conn *conn;

	if (conns==NULL) /* no connections! */
		return NULL;

	for (conn = conns; conn; conn = conn->next) {
		if (strncmp(name, conn->name, sizeof(conn->name))==0)
			return(conn);
	}

	return NULL;
}

/*
 * Close a span connection
 * This closes a socket a frees the state. In the future, we may want to
 * leave the state and attempt to reconnect or later garbage collect.
 */
int
free_span_conn(conn)
struct span_conn *conn;
{
	struct span_conn *c, *prev;
	/* Since this is called in response to a close message,
         * we do not send a close message of our own here.
         */
	if (!conn)
		return(-1);

	sp_log("Closing connection with %s.\n", conn->name);
	closesocket(conn->sock);
	conn->state = SPAN_CONNSTATE_NONE;
	conn->sock = 0;
	prev = NULL;
	/* invalidate any cached entries of this connection */
	span_map_uncache(conn);	

	/* locate conn in the global conns list */
	for (c = conns; c; prev = c, c = c->next)
		if (conn == c) break;

	/* free and unlink conn */
	if (!c) {
		sp_log("Warning: couldn't free connection state.\n");
		return(-1);
	}
	if (prev)
		prev->next = conn->next;
	else
		conns = conns->next;
	free(conn->data);
	free(conn);

	return(0);
}

/*
 * Empty the connection list.
 */
void 
free_span_conns(void)
{
	struct span_conn *conn, *next;

	for (conn = conns; conn; ) {
		next = conn->next;
		if (conn->state == SPAN_CONNSTATE_CONNECTED)
			span_send_control(conn->sock, SH_TYPE_CLOSE,conn->name);
		closesocket(conn->sock);
		free(conn->data);
		free(conn);
		conn = next;
	}
}


/*
 * Initialize the connection mapping hash table.
 */
void 
span_map_init(void)
{
	bzero(	&span_conn_map[0],
		sizeof(struct span_map_entry) * SPAN_MAP_HASHSIZE );
}

/*
 * Connection mapping is considered used once the hash id has been
 * set, or if it hashes to zero, if the entry->src string is not empty.
 */
#define IS_MAP_ENTRY_USED(bucket, entry) \
	( (bucket && entry->hash) || \
	  (!bucket && (strlen(entry->src)>0)) )

/*
 * Add mapping between source and destination. Source can be the name of a
 * Netgraph node or name of a peer connection. Destination is also a name.
 * Existence of names is not validated.
 */
int
span_map(src, dst)
char *src;
char *dst;
{
	unsigned int bucket, hash;
	struct span_map_entry *entry, *last;

	/* strings must be non-NULL */
	if (!src || !dst)
		return(-1);
	if ((strlen(src) < 2) || (strlen(dst) < 2))
		return(-1);

	sp_log("Adding mapping between '%s' ==> '%s'\n", src, dst);

	hash = map_hash(src);
	bucket = hash % SPAN_MAP_HASHSIZE;
	last = NULL;
	/* locate last entry in chain, detecting duplicates */
	for (entry = &span_conn_map[bucket]; entry; entry=entry->next) {
		last = entry;
		/* update mapping if it already exists */
		if ((entry->hash == hash) && 
		    (strncmp(entry->src, src, 255)==0)) {
			entry->conn_cache = NULL; /* invalidate the cache */
			strncpy(entry->dst, dst, 255);
			return(0);
		}
	}

	if (!last) /* span_conn_map not allocated! */
		return(-1);

	/* first bucket is empty, use it */	
	if ((&span_conn_map[bucket] == last) && (strlen(last->src)==0)) {
		entry = last;
	/* allocate new bucket */
	} else {
		entry = malloc(sizeof (struct span_map_entry));
		if (!entry)
			return(-1);
		last->next = entry;
	}

	/* set the entry */
	bzero(entry, sizeof (struct span_map_entry));
	/* sp_log("hash=0x%x bucket=0x%x entry=%p\n", hash, bucket, entry); */
	entry->hash = hash;
	entry->conn_cache = NULL; /* optimization - set this now? */
	strncpy(entry->src, src, 255);
	strncpy(entry->dst, dst, 255);
	entry->next = NULL;

	return(0);
}


/*
 * Remove mapping between source and destination. 
 */
int
span_unmap(src)
char *src;
{
	unsigned int bucket, hash;
	struct span_map_entry *entry, *last, *next;

	if (!src)
		return(-1);
	if (strlen(src) < 2)
		return(-1);

	sp_log("Removing mapping for '%s'\n", src);

	hash = map_hash(src);
	bucket = hash % SPAN_MAP_HASHSIZE;
	last = NULL;
	for (entry = &span_conn_map[bucket]; entry; entry=entry->next) {
		if ((entry->hash == hash) && 
		    (strncmp(entry->src, src, 255)==0)) {
			next = entry->next;
			bzero(entry, sizeof(struct span_conn));
			if (last) {
				last->next = next;
			} else if (next) {
				memcpy(&span_conn_map[bucket], next,
					sizeof(struct span_conn));
				free(next);
			}
			return(0);
		}
		last = entry;
	}

	/* not found */
	return(-1);
}


/*
 * Find a connection given a source string.
 */
struct span_conn*
span_map_lookup(src)
char *src;
{
	unsigned int bucket, hash;
	struct span_map_entry *entry;
	struct span_conn *conn;

 	hash = map_hash(src);
	bucket = hash % SPAN_MAP_HASHSIZE;

	/* look for matching src
         * we first compare the hash values to avoid many strlen()s */
	for (entry = &span_conn_map[bucket]; entry; entry=entry->next) {
		if ((entry->hash == hash) && 
		    (strncmp(entry->src, src, sizeof entry->src)==0))
			break;
	}

	/* no hash table entry == no map */
	if (!entry)
		return(NULL);

	/* fast path */
	if (entry->conn_cache)
		return(entry->conn_cache);

	/* lookup and cache for next time */
	conn = find_span_conn_by_name(entry->dst);
	entry->conn_cache = conn; /* may be NULL */

	return(conn);
}


/*
 * span_map_lookup() stores a cache of the last used connection for dst
 * this needs to be invalidated when removing the connection
 */
int
span_map_uncache(conn)
struct span_conn *conn;
{
	unsigned int bucket;
	struct span_map_entry *entry;

	if (!conn)
		return(-1);

	/* hash = map_hash(entry->dst);
	bucket = hash % SPAN_MAP_HASHSIZE; */
	for (bucket = 0; bucket < SPAN_MAP_HASHSIZE; bucket++) {
	for (entry = &span_conn_map[bucket]; entry; entry=entry->next) {
		/* could compare hash value here, but we might as well
		 * perform just one comparison
		 */
		if (entry->conn_cache == conn)
			entry->conn_cache = NULL;
	}
	}

	return(0);
}


/*
 * Load mappings from an input string in the format "a-b,b-c,f-g"
 */
int
span_map_load(str)
char *str;
{
	char *p, *p2, *end, src[255], dst[255];
	int count=0;

	p = str;
	end = &str[strlen(str)];

	while(p < end) {
		p2 = strchr(p+1,'-');
		if (!p2) /* no dash character for mapping */
			return(count);
		bzero(src, sizeof(src));
		strncpy(src, p, p2 - p);

		p2++; /* skip the '-' character */
		p = strchr(p2, ',');
		if (!p) /* no more mappings */
			p = end;
		p++;
		bzero(dst, sizeof(dst));
		strncpy(dst, p2, p - p2 - 1);

		span_map(src, dst);
		count++;
	}
	return(count);
}

/*
 * Hash function for mapping - string -> 32-bit number
 */
unsigned int
map_hash(a)
char *a;
{
	unsigned int hash=0;
	unsigned int i;
	/* Bernstein's hash: no collisions with 6 lowercase characters */
	for (i=0; i < strlen(a); i++)
		hash = 33*hash + (unsigned int)a[i];
	/* also (33*hash) == hash+(hash<<5) */
	return(hash);
}

/*
 * Empty any lists in the connection map hash table.
 */
void 
free_span_conn_map(void)
{
	int b;
	struct span_map_entry *entry, *tmp;

	for (b = 0; b < SPAN_MAP_HASHSIZE; b++) {
		entry = &span_conn_map[b];
		while(entry->next) {
			tmp = entry->next;
			entry->next = tmp->next;
			free(tmp);
		}
		bzero(entry, sizeof(struct span_map_entry));
	}
}


/* 
 * debug
 */
void
dump_span_conn_map(void)
{
	int b;
	struct span_map_entry *entry;

	for (b = 0; b < SPAN_MAP_HASHSIZE; b++) {
		for (entry = &span_conn_map[b]; entry; entry=entry->next) {
			if (IS_MAP_ENTRY_USED(b, entry))
			    sp_log("(%d: %s-%s)", b, entry->src, entry->dst);
		}
	}
}
