package edu.bonn.cs.iv.bonnmotion;

public class IndexPair {
	public final int i;
	public final int j;

	public IndexPair(int i, int j) {
		this.i = i;
		this.j = j;
	}
}
