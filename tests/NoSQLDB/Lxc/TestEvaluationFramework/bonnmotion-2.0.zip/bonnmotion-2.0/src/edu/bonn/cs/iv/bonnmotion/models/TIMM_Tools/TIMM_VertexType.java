package edu.bonn.cs.iv.bonnmotion.models.TIMM_Tools;

public enum TIMM_VertexType {
    DOOR, ROOM, STRUCT, DISTANCE
}
